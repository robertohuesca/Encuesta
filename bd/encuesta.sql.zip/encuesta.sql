-- phpMyAdmin SQL Dump
-- version 2.10.2
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tiempo de generación: 13-03-2016 a las 01:44:11
-- Versión del servidor: 5.0.45
-- Versión de PHP: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de datos: `encuesta`
-- 

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `alimentaciones`
-- 

CREATE TABLE `alimentaciones` (
  `ID_ALIMENTACION` int(11) NOT NULL auto_increment,
  `FREC_DESAYUNO` varchar(20) collate utf8_spanish_ci default NULL,
  `FREC_COMIDA` varchar(20) collate utf8_spanish_ci default NULL,
  `FREC_CENA` varchar(20) collate utf8_spanish_ci default NULL,
  `EFEC_ALIMEN` varchar(10) collate utf8_spanish_ci default NULL,
  PRIMARY KEY  (`ID_ALIMENTACION`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `alimentaciones`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `alumnos`
-- 

CREATE TABLE `alumnos` (
  `ID_ALUMNO` int(11) NOT NULL,
  `ID_ESCUELA` int(11) default NULL,
  `ID_GRUPO` int(11) default NULL,
  `ID_STATUS` int(11) default NULL,
  `FOLIO` int(11) default NULL,
  `TRABAJA` tinyint(1) default NULL,
  `TEL_CASA` varchar(15) collate utf8_spanish_ci default NULL,
  `TEL_CELULAR` varchar(15) collate utf8_spanish_ci default NULL,
  `BECA` tinyint(1) default NULL,
  PRIMARY KEY  (`ID_ALUMNO`),
  KEY `FK_REFERENCE_18` (`ID_ESCUELA`),
  KEY `FK_REFERENCE_20` (`ID_GRUPO`),
  KEY `FK_REFERENCE_21` (`ID_STATUS`),
  KEY `FK_REFERENCE_28` (`FOLIO`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- 
-- Volcar la base de datos para la tabla `alumnos`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `amb_socio`
-- 

CREATE TABLE `amb_socio` (
  `ID_AMBIENTE` int(11) NOT NULL auto_increment,
  `BIENES_SERV` varchar(100) collate utf8_spanish_ci default NULL,
  `USO_PER` varchar(50) collate utf8_spanish_ci default NULL,
  `FOCOS` int(11) default NULL,
  `TELEVISORES` int(11) default NULL,
  PRIMARY KEY  (`ID_AMBIENTE`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `amb_socio`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `deportes`
-- 

CREATE TABLE `deportes` (
  `ID_DEPORTE` int(11) NOT NULL auto_increment,
  `FRECUENCIA` varchar(20) collate utf8_spanish_ci default NULL,
  `DEPORTE` varchar(15) collate utf8_spanish_ci default NULL,
  PRIMARY KEY  (`ID_DEPORTE`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `deportes`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `domicilios`
-- 

CREATE TABLE `domicilios` (
  `ID_DOMICILIO` int(11) NOT NULL auto_increment,
  `ID_MUNICIPIO` int(11) default NULL,
  `CALLE` varchar(20) collate utf8_spanish_ci default NULL,
  `COLONIA` varchar(20) collate utf8_spanish_ci default NULL,
  `N_EXTERIOR` varchar(10) collate utf8_spanish_ci default NULL,
  `N_INTERIOR` varchar(10) collate utf8_spanish_ci default NULL,
  `CP` varchar(10) collate utf8_spanish_ci default NULL,
  PRIMARY KEY  (`ID_DOMICILIO`),
  KEY `FK_REFERENCE_25` (`ID_MUNICIPIO`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `domicilios`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `encuestas`
-- 

CREATE TABLE `encuestas` (
  `FOLIO` int(11) NOT NULL,
  `ID_ALIMENTACION` int(11) default NULL,
  `ID_VIVIENDA` int(11) default NULL,
  `ID_SALUD` int(11) default NULL,
  `ID_DEPORTE` int(11) default NULL,
  `ID_AMBIENTE` int(11) default NULL,
  `ID_INTERNET` int(11) default NULL,
  `ID_PARTICIPACION` int(11) default NULL,
  `ID_HABITO` int(11) default NULL,
  `ID_PADRE` int(11) default NULL,
  `ID_MADRE` int(11) default NULL,
  PRIMARY KEY  (`FOLIO`),
  KEY `FK_REFERENCE_12` (`ID_ALIMENTACION`),
  KEY `FK_REFERENCE_15` (`ID_VIVIENDA`),
  KEY `FK_REFERENCE_17` (`ID_SALUD`),
  KEY `FK_REFERENCE_22` (`ID_DEPORTE`),
  KEY `FK_REFERENCE_23` (`ID_AMBIENTE`),
  KEY `FK_REFERENCE_26` (`ID_PADRE`),
  KEY `FK_REFERENCE_27` (`ID_MADRE`),
  KEY `FK_REFERENCE_29` (`ID_HABITO`),
  KEY `FK_REFERENCE_32` (`ID_INTERNET`),
  KEY `FK_REFERENCE_33` (`ID_PARTICIPACION`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- 
-- Volcar la base de datos para la tabla `encuestas`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `enfermedad`
-- 

CREATE TABLE `enfermedad` (
  `ID_ENFERMEDAD` int(11) NOT NULL auto_increment,
  `DESCRIPCION` varchar(25) collate utf8_spanish_ci default NULL,
  PRIMARY KEY  (`ID_ENFERMEDAD`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `enfermedad`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `entidades`
-- 

CREATE TABLE `entidades` (
  `ID_ENTIDAD` int(11) NOT NULL,
  `NOMBRE` varchar(40) collate utf8_spanish_ci default NULL,
  PRIMARY KEY  (`ID_ENTIDAD`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- 
-- Volcar la base de datos para la tabla `entidades`
-- 

INSERT INTO `entidades` VALUES (1, 'Aguascalientes');
INSERT INTO `entidades` VALUES (2, 'Baja California');
INSERT INTO `entidades` VALUES (3, 'Baja California Sur');
INSERT INTO `entidades` VALUES (4, 'Campeche');
INSERT INTO `entidades` VALUES (5, 'Chiapas');
INSERT INTO `entidades` VALUES (6, 'Chihuahua');
INSERT INTO `entidades` VALUES (7, 'Coahuila');
INSERT INTO `entidades` VALUES (8, 'Colima');
INSERT INTO `entidades` VALUES (9, 'Distrito Federal');
INSERT INTO `entidades` VALUES (10, 'Durango');
INSERT INTO `entidades` VALUES (11, 'Estado de México');
INSERT INTO `entidades` VALUES (12, 'Guanajuato');
INSERT INTO `entidades` VALUES (13, 'Guerrero');
INSERT INTO `entidades` VALUES (14, 'Hidalgo');
INSERT INTO `entidades` VALUES (15, 'Jalisco');
INSERT INTO `entidades` VALUES (16, 'Michoacán');
INSERT INTO `entidades` VALUES (17, 'Morelos');
INSERT INTO `entidades` VALUES (18, 'Nayarit');
INSERT INTO `entidades` VALUES (19, 'Nuevo León');
INSERT INTO `entidades` VALUES (20, 'Oaxaca');
INSERT INTO `entidades` VALUES (21, 'Puebla');
INSERT INTO `entidades` VALUES (22, 'Querétaro');
INSERT INTO `entidades` VALUES (23, 'Quintana Roo');
INSERT INTO `entidades` VALUES (24, 'San Luis Potosí');
INSERT INTO `entidades` VALUES (25, 'Sinaloa');
INSERT INTO `entidades` VALUES (26, 'Sonora');
INSERT INTO `entidades` VALUES (27, 'Tabasco');
INSERT INTO `entidades` VALUES (28, 'Tamaulipas');
INSERT INTO `entidades` VALUES (29, 'Tlaxcala');
INSERT INTO `entidades` VALUES (30, 'Veracruz');
INSERT INTO `entidades` VALUES (31, 'Yucatán');
INSERT INTO `entidades` VALUES (32, 'Zacatecas');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `escuelas`
-- 

CREATE TABLE `escuelas` (
  `ID_ESCUELA` int(11) NOT NULL auto_increment,
  `ID_DOMICILIO` int(11) default NULL,
  `NOMBRE` varchar(35) collate utf8_spanish_ci default NULL,
  `DESCRIPCION` varchar(40) collate utf8_spanish_ci default NULL,
  `CICLO_ESCOLAR` varchar(15) collate utf8_spanish_ci default NULL,
  `TURNO` tinyint(1) default NULL,
  `PROMEDIO` double default NULL,
  PRIMARY KEY  (`ID_ESCUELA`),
  KEY `FK_REFERENCE_14` (`ID_DOMICILIO`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `escuelas`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `familiar`
-- 

CREATE TABLE `familiar` (
  `ID_FAMILIAR` int(11) NOT NULL auto_increment,
  `ID_ENFERMEDAD` int(11) default NULL,
  `FOLIO` int(11) default NULL,
  `ID_PARENT` int(11) default NULL,
  `NOMBRE` varchar(15) collate utf8_spanish_ci default NULL,
  `AP_PATERNO` varchar(15) collate utf8_spanish_ci default NULL,
  `AP_MATERNO` varchar(15) collate utf8_spanish_ci default NULL,
  PRIMARY KEY  (`ID_FAMILIAR`),
  KEY `FK_REFERENCE_34` (`ID_ENFERMEDAD`),
  KEY `FK_REFERENCE_35` (`FOLIO`),
  KEY `FK_REFERENCE_36` (`ID_PARENT`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `familiar`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `familiares`
-- 

CREATE TABLE `familiares` (
  `ID_FAMILIAR` int(11) NOT NULL auto_increment,
  `FOLIO` int(11) default NULL,
  `NOMBRE` varchar(20) collate utf8_spanish_ci default NULL,
  `APELLIDOS` varchar(25) collate utf8_spanish_ci default NULL,
  `GENERO` varchar(15) collate utf8_spanish_ci default NULL,
  `EDAD` int(11) default NULL,
  `OCUPACION` varchar(30) collate utf8_spanish_ci default NULL,
  `PARENTESCO` varchar(15) collate utf8_spanish_ci default NULL,
  PRIMARY KEY  (`ID_FAMILIAR`),
  KEY `FK_REFERENCE_37` (`FOLIO`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `familiares`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `grupos`
-- 

CREATE TABLE `grupos` (
  `ID_GRUPO` int(11) NOT NULL auto_increment,
  `GRADO` int(11) default NULL,
  `GRUPO` varchar(1) collate utf8_spanish_ci default NULL,
  PRIMARY KEY  (`ID_GRUPO`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `grupos`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `habitos_consumo`
-- 

CREATE TABLE `habitos_consumo` (
  `ID_HABITO` int(11) NOT NULL auto_increment,
  `FUMAS` tinyint(1) default NULL,
  `CANTIDAD` varchar(10) collate utf8_spanish_ci default NULL,
  `CONSUMES` varchar(100) collate utf8_spanish_ci default NULL,
  `FRECUENCIA` varchar(100) collate utf8_spanish_ci default NULL,
  `ADICCION` tinyint(1) default NULL,
  `ESPECIFICA_ADIC` varchar(50) collate utf8_spanish_ci default NULL,
  `DROGA` tinyint(1) default NULL,
  `ESPECIFICA_DROG` varchar(50) collate utf8_spanish_ci default NULL,
  PRIMARY KEY  (`ID_HABITO`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `habitos_consumo`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `internet`
-- 

CREATE TABLE `internet` (
  `ID_INTERNET` int(11) NOT NULL auto_increment,
  `SABEUSAR` tinyint(1) default NULL,
  `ACCESO` tinyint(1) default NULL,
  `LUGAR_ACCESO` varchar(20) collate utf8_spanish_ci default NULL,
  `UTILIZA_INTERNET` varchar(100) collate utf8_spanish_ci default NULL,
  `CUENTAS` varchar(100) collate utf8_spanish_ci default NULL,
  `UTILIZA_CUENTAS` varchar(100) collate utf8_spanish_ci default NULL,
  PRIMARY KEY  (`ID_INTERNET`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `internet`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `municipios`
-- 

CREATE TABLE `municipios` (
  `ID_MUNICIPIO` int(11) NOT NULL,
  `ID_ENTIDAD` int(11) default NULL,
  `NOMBRE` varchar(40) collate utf8_spanish_ci default NULL,
  PRIMARY KEY  (`ID_MUNICIPIO`),
  KEY `FK_REFERENCE_24` (`ID_ENTIDAD`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- 
-- Volcar la base de datos para la tabla `municipios`
-- 

INSERT INTO `municipios` VALUES (1, 1, 'Aguascalientes');
INSERT INTO `municipios` VALUES (2, 1, 'Asientos');
INSERT INTO `municipios` VALUES (3, 1, 'Calvillo');
INSERT INTO `municipios` VALUES (4, 1, 'Cosío');
INSERT INTO `municipios` VALUES (5, 1, 'El Llano');
INSERT INTO `municipios` VALUES (6, 1, 'Jesús María');
INSERT INTO `municipios` VALUES (7, 1, 'Pabellón de Arteaga');
INSERT INTO `municipios` VALUES (8, 1, 'Rincón de Romos');
INSERT INTO `municipios` VALUES (9, 1, 'San Francisco de los Romo');
INSERT INTO `municipios` VALUES (10, 1, 'San José de Gracia');
INSERT INTO `municipios` VALUES (11, 1, 'Tepezalá');
INSERT INTO `municipios` VALUES (12, 2, 'Ensenada');
INSERT INTO `municipios` VALUES (13, 2, 'Mexicali');
INSERT INTO `municipios` VALUES (14, 2, 'Playas de Rosarito');
INSERT INTO `municipios` VALUES (15, 2, 'Tecate');
INSERT INTO `municipios` VALUES (16, 2, 'Tijuana');
INSERT INTO `municipios` VALUES (17, 3, 'Comondú');
INSERT INTO `municipios` VALUES (18, 3, 'La Paz');
INSERT INTO `municipios` VALUES (19, 3, 'Loreto');
INSERT INTO `municipios` VALUES (20, 3, 'Los Cabos');
INSERT INTO `municipios` VALUES (21, 3, 'Mulegé');
INSERT INTO `municipios` VALUES (22, 4, 'Calakmul');
INSERT INTO `municipios` VALUES (23, 4, 'Calkiní');
INSERT INTO `municipios` VALUES (24, 4, 'Campeche');
INSERT INTO `municipios` VALUES (25, 4, 'Candelaria');
INSERT INTO `municipios` VALUES (26, 4, 'Carmen');
INSERT INTO `municipios` VALUES (27, 4, 'Champotón');
INSERT INTO `municipios` VALUES (28, 4, 'Escárcega');
INSERT INTO `municipios` VALUES (29, 4, 'Hecelchakán');
INSERT INTO `municipios` VALUES (30, 4, 'Hopelchén');
INSERT INTO `municipios` VALUES (31, 4, 'Palizada');
INSERT INTO `municipios` VALUES (32, 4, 'Tenabo');
INSERT INTO `municipios` VALUES (33, 5, 'Acacoyagua');
INSERT INTO `municipios` VALUES (34, 5, 'Acala');
INSERT INTO `municipios` VALUES (35, 5, 'Acapetahua');
INSERT INTO `municipios` VALUES (36, 5, 'Aldama');
INSERT INTO `municipios` VALUES (37, 5, 'Altamirano');
INSERT INTO `municipios` VALUES (38, 5, 'Amatán');
INSERT INTO `municipios` VALUES (39, 5, 'Amatenango de la Frontera');
INSERT INTO `municipios` VALUES (40, 5, 'Amatenango del Valle');
INSERT INTO `municipios` VALUES (41, 5, 'Ángel Albino Corzo');
INSERT INTO `municipios` VALUES (42, 5, 'Arriaga');
INSERT INTO `municipios` VALUES (43, 5, 'Bejucal de Ocampo');
INSERT INTO `municipios` VALUES (44, 5, 'Bella Vista');
INSERT INTO `municipios` VALUES (45, 5, 'Benemérito de las Américas');
INSERT INTO `municipios` VALUES (46, 5, 'Berriozábal');
INSERT INTO `municipios` VALUES (47, 5, 'Bochil');
INSERT INTO `municipios` VALUES (48, 5, 'Cacahoatán');
INSERT INTO `municipios` VALUES (49, 5, 'Chalchihuitán');
INSERT INTO `municipios` VALUES (50, 5, 'Chamula');
INSERT INTO `municipios` VALUES (51, 5, 'Chanal');
INSERT INTO `municipios` VALUES (52, 5, 'Chapultenango');
INSERT INTO `municipios` VALUES (53, 5, 'Catazajá');
INSERT INTO `municipios` VALUES (54, 5, 'Chenalhó');
INSERT INTO `municipios` VALUES (55, 5, 'Chiapa de Corzo');
INSERT INTO `municipios` VALUES (56, 5, 'Chiapilla');
INSERT INTO `municipios` VALUES (57, 5, 'Chicoasén');
INSERT INTO `municipios` VALUES (58, 5, 'Chicomosuelo');
INSERT INTO `municipios` VALUES (59, 5, 'Cintalpa');
INSERT INTO `municipios` VALUES (60, 5, 'Chilón');
INSERT INTO `municipios` VALUES (61, 5, 'Coapilla');
INSERT INTO `municipios` VALUES (62, 5, 'Comitán de Domínguez');
INSERT INTO `municipios` VALUES (63, 5, 'Copainalá');
INSERT INTO `municipios` VALUES (64, 5, 'El Bosque');
INSERT INTO `municipios` VALUES (65, 5, 'El Porvenir');
INSERT INTO `municipios` VALUES (66, 5, 'Escuintla');
INSERT INTO `municipios` VALUES (67, 5, 'Francisco León');
INSERT INTO `municipios` VALUES (68, 5, 'Frontera Comalapa');
INSERT INTO `municipios` VALUES (69, 5, 'Frontera Hidalgo');
INSERT INTO `municipios` VALUES (70, 5, 'Huehuetán');
INSERT INTO `municipios` VALUES (71, 5, 'Huitiupán');
INSERT INTO `municipios` VALUES (72, 5, 'Huixtán');
INSERT INTO `municipios` VALUES (73, 5, 'Huixtla');
INSERT INTO `municipios` VALUES (74, 5, 'Ixhuatán');
INSERT INTO `municipios` VALUES (75, 5, 'Ixtacomitán');
INSERT INTO `municipios` VALUES (76, 5, 'Ixtapa');
INSERT INTO `municipios` VALUES (77, 5, 'Ixtapangajoya');
INSERT INTO `municipios` VALUES (78, 5, 'Jiquipilas');
INSERT INTO `municipios` VALUES (79, 5, 'Jitotol');
INSERT INTO `municipios` VALUES (80, 5, 'Juárez');
INSERT INTO `municipios` VALUES (81, 5, 'La Concordia');
INSERT INTO `municipios` VALUES (82, 5, 'La Grandeza');
INSERT INTO `municipios` VALUES (83, 5, 'La Independencia');
INSERT INTO `municipios` VALUES (84, 5, 'La Libertad');
INSERT INTO `municipios` VALUES (85, 5, 'La Trinitaria');
INSERT INTO `municipios` VALUES (86, 5, 'Larráinzar');
INSERT INTO `municipios` VALUES (87, 5, 'Las Margaritas');
INSERT INTO `municipios` VALUES (88, 5, 'Las Rosas');
INSERT INTO `municipios` VALUES (89, 5, 'Mapastepec');
INSERT INTO `municipios` VALUES (90, 5, 'Maravilla Tenejapa');
INSERT INTO `municipios` VALUES (91, 5, 'Marqués de Comillas');
INSERT INTO `municipios` VALUES (92, 5, 'Mazapa de Madero');
INSERT INTO `municipios` VALUES (93, 5, 'Mazatán');
INSERT INTO `municipios` VALUES (94, 5, 'Metapa');
INSERT INTO `municipios` VALUES (95, 5, 'Mitontic');
INSERT INTO `municipios` VALUES (96, 5, 'Montecristo de Guerrero');
INSERT INTO `municipios` VALUES (97, 5, 'Motozintla');
INSERT INTO `municipios` VALUES (98, 5, 'Nicolás Ruíz');
INSERT INTO `municipios` VALUES (99, 5, 'Ocosingo');
INSERT INTO `municipios` VALUES (100, 5, 'Ocotepec');
INSERT INTO `municipios` VALUES (101, 5, 'Ocozocoautla de Espinosa');
INSERT INTO `municipios` VALUES (102, 5, 'Ostuacán');
INSERT INTO `municipios` VALUES (103, 5, 'Osumacinta');
INSERT INTO `municipios` VALUES (104, 5, 'Oxchuc');
INSERT INTO `municipios` VALUES (105, 5, 'Palenque');
INSERT INTO `municipios` VALUES (106, 5, 'Pantelhó');
INSERT INTO `municipios` VALUES (107, 5, 'Pantepec');
INSERT INTO `municipios` VALUES (108, 5, 'Pichucalco');
INSERT INTO `municipios` VALUES (109, 5, 'Pijijiapan');
INSERT INTO `municipios` VALUES (110, 5, 'Pueblo Nuevo Solistahuacán');
INSERT INTO `municipios` VALUES (111, 5, 'Rayón');
INSERT INTO `municipios` VALUES (112, 5, 'Reforma');
INSERT INTO `municipios` VALUES (113, 5, 'Sabanilla');
INSERT INTO `municipios` VALUES (114, 5, 'Salto de Agua');
INSERT INTO `municipios` VALUES (115, 5, 'San Andrés Duraznal');
INSERT INTO `municipios` VALUES (116, 5, 'San Cristóbal de las Casas');
INSERT INTO `municipios` VALUES (117, 5, 'San Fernando');
INSERT INTO `municipios` VALUES (118, 5, 'San Juan Cancuc');
INSERT INTO `municipios` VALUES (119, 5, 'San Lucas');
INSERT INTO `municipios` VALUES (120, 5, 'Santiago el Pinar');
INSERT INTO `municipios` VALUES (121, 5, 'Siltepec');
INSERT INTO `municipios` VALUES (122, 5, 'Simojovel');
INSERT INTO `municipios` VALUES (123, 5, 'Sitalá');
INSERT INTO `municipios` VALUES (124, 5, 'Socoltenango');
INSERT INTO `municipios` VALUES (125, 5, 'Solosuchiapa');
INSERT INTO `municipios` VALUES (126, 5, 'Soyaló');
INSERT INTO `municipios` VALUES (127, 5, 'Suchiapa');
INSERT INTO `municipios` VALUES (128, 5, 'Suchiate');
INSERT INTO `municipios` VALUES (129, 5, 'Sunuapa');
INSERT INTO `municipios` VALUES (130, 5, 'Tapachula');
INSERT INTO `municipios` VALUES (131, 5, 'Tapalapa');
INSERT INTO `municipios` VALUES (132, 5, 'Tapilula');
INSERT INTO `municipios` VALUES (133, 5, 'Tecpatán');
INSERT INTO `municipios` VALUES (134, 5, 'Tenejapa');
INSERT INTO `municipios` VALUES (135, 5, 'Teopisca');
INSERT INTO `municipios` VALUES (136, 5, 'Tila');
INSERT INTO `municipios` VALUES (137, 5, 'Tonalá');
INSERT INTO `municipios` VALUES (138, 5, 'Totolapa');
INSERT INTO `municipios` VALUES (139, 5, 'Tumbalá');
INSERT INTO `municipios` VALUES (140, 5, 'Tuxtla Chico');
INSERT INTO `municipios` VALUES (141, 5, 'Tuxtla Gutiérrez');
INSERT INTO `municipios` VALUES (142, 5, 'Tuzantán');
INSERT INTO `municipios` VALUES (143, 5, 'Tzimol');
INSERT INTO `municipios` VALUES (144, 5, 'Unión Juárez');
INSERT INTO `municipios` VALUES (145, 5, 'Venustiano Carranza');
INSERT INTO `municipios` VALUES (146, 5, 'Villa Comaltitlán');
INSERT INTO `municipios` VALUES (147, 5, 'Villa Corzo');
INSERT INTO `municipios` VALUES (148, 5, 'Villaflores');
INSERT INTO `municipios` VALUES (149, 5, 'Yajalón');
INSERT INTO `municipios` VALUES (150, 5, 'Zinacantán');
INSERT INTO `municipios` VALUES (151, 6, 'Ahumada');
INSERT INTO `municipios` VALUES (152, 6, 'Aldama');
INSERT INTO `municipios` VALUES (153, 6, 'Allende');
INSERT INTO `municipios` VALUES (154, 6, 'Aquiles Serdán');
INSERT INTO `municipios` VALUES (155, 6, 'Ascensión');
INSERT INTO `municipios` VALUES (156, 6, 'Bachíniva');
INSERT INTO `municipios` VALUES (157, 6, 'Balleza');
INSERT INTO `municipios` VALUES (158, 6, 'Batopilas');
INSERT INTO `municipios` VALUES (159, 6, 'Bocoyna');
INSERT INTO `municipios` VALUES (160, 6, 'Buenaventura');
INSERT INTO `municipios` VALUES (161, 6, 'Camargo');
INSERT INTO `municipios` VALUES (162, 6, 'Carichí');
INSERT INTO `municipios` VALUES (163, 6, 'Casas Grandes');
INSERT INTO `municipios` VALUES (164, 6, 'Chihuahua');
INSERT INTO `municipios` VALUES (165, 6, 'Chínipas');
INSERT INTO `municipios` VALUES (166, 6, 'Coronado');
INSERT INTO `municipios` VALUES (167, 6, 'Coyame del Sotol');
INSERT INTO `municipios` VALUES (168, 6, 'Cuauhtémoc');
INSERT INTO `municipios` VALUES (169, 6, 'Cusihuiriachi');
INSERT INTO `municipios` VALUES (170, 6, 'Delicias');
INSERT INTO `municipios` VALUES (171, 6, 'Dr. Belisario Domínguez');
INSERT INTO `municipios` VALUES (172, 6, 'El Tule');
INSERT INTO `municipios` VALUES (173, 6, 'Galeana');
INSERT INTO `municipios` VALUES (174, 6, 'Gómez Farías');
INSERT INTO `municipios` VALUES (175, 6, 'Gran Morelos');
INSERT INTO `municipios` VALUES (176, 6, 'Guachochi');
INSERT INTO `municipios` VALUES (177, 6, 'Guadalupe D.B.');
INSERT INTO `municipios` VALUES (178, 6, 'Guadalupe y Calvo');
INSERT INTO `municipios` VALUES (179, 6, 'Guazapares');
INSERT INTO `municipios` VALUES (180, 6, 'Guerrero');
INSERT INTO `municipios` VALUES (181, 6, 'Hidalgo del Parral');
INSERT INTO `municipios` VALUES (182, 6, 'Huejoitán');
INSERT INTO `municipios` VALUES (183, 6, 'Ignacio Zaragoza');
INSERT INTO `municipios` VALUES (184, 6, 'Janos');
INSERT INTO `municipios` VALUES (185, 6, 'Jiménez');
INSERT INTO `municipios` VALUES (186, 6, 'Juárez');
INSERT INTO `municipios` VALUES (187, 6, 'Julimes');
INSERT INTO `municipios` VALUES (188, 6, 'La Cruz');
INSERT INTO `municipios` VALUES (189, 6, 'López');
INSERT INTO `municipios` VALUES (190, 6, 'Madera');
INSERT INTO `municipios` VALUES (191, 6, 'Maguarichi');
INSERT INTO `municipios` VALUES (192, 6, 'Manuel Benavides');
INSERT INTO `municipios` VALUES (193, 6, 'Matachí');
INSERT INTO `municipios` VALUES (194, 6, 'Matamoros');
INSERT INTO `municipios` VALUES (195, 6, 'Meoqui');
INSERT INTO `municipios` VALUES (196, 6, 'Morelos');
INSERT INTO `municipios` VALUES (197, 6, 'Moris');
INSERT INTO `municipios` VALUES (198, 6, 'Namiquipa');
INSERT INTO `municipios` VALUES (199, 6, 'Nonoava');
INSERT INTO `municipios` VALUES (200, 6, 'Nuevo Casas Grandes');
INSERT INTO `municipios` VALUES (201, 6, 'Ocampo');
INSERT INTO `municipios` VALUES (202, 6, 'Ojinaga');
INSERT INTO `municipios` VALUES (203, 6, 'Praxedis G. Guerrero');
INSERT INTO `municipios` VALUES (204, 6, 'Riva Palacio');
INSERT INTO `municipios` VALUES (205, 6, 'Rosales');
INSERT INTO `municipios` VALUES (206, 6, 'Rosario');
INSERT INTO `municipios` VALUES (207, 6, 'San Francisco de Borja');
INSERT INTO `municipios` VALUES (208, 6, 'San Francisco de Conchos');
INSERT INTO `municipios` VALUES (209, 6, 'San Francisco del Oro');
INSERT INTO `municipios` VALUES (210, 6, 'Santa Bárabara');
INSERT INTO `municipios` VALUES (211, 6, 'Santa Isabel');
INSERT INTO `municipios` VALUES (212, 6, 'Satevó');
INSERT INTO `municipios` VALUES (213, 6, 'Saucillo');
INSERT INTO `municipios` VALUES (214, 6, 'Temósachi');
INSERT INTO `municipios` VALUES (215, 6, 'Urique');
INSERT INTO `municipios` VALUES (216, 6, 'Uriachi');
INSERT INTO `municipios` VALUES (217, 6, 'Valle de Zaragoza');
INSERT INTO `municipios` VALUES (218, 7, 'Abasolo');
INSERT INTO `municipios` VALUES (219, 7, 'Acuña');
INSERT INTO `municipios` VALUES (220, 7, 'Allende');
INSERT INTO `municipios` VALUES (221, 7, 'Arteaga');
INSERT INTO `municipios` VALUES (222, 7, 'Candela');
INSERT INTO `municipios` VALUES (223, 7, 'Castaños');
INSERT INTO `municipios` VALUES (224, 7, 'Cuatrociénegas');
INSERT INTO `municipios` VALUES (225, 7, 'Escobedo');
INSERT INTO `municipios` VALUES (226, 7, 'Francisco I. Madero');
INSERT INTO `municipios` VALUES (227, 7, 'Frontera');
INSERT INTO `municipios` VALUES (228, 7, 'General Cepeda');
INSERT INTO `municipios` VALUES (229, 7, 'Guerrero');
INSERT INTO `municipios` VALUES (230, 7, 'Hidalgo');
INSERT INTO `municipios` VALUES (231, 7, 'Jiménez');
INSERT INTO `municipios` VALUES (232, 7, 'Juárez');
INSERT INTO `municipios` VALUES (233, 7, 'Lamadrid');
INSERT INTO `municipios` VALUES (234, 7, 'Matamoros');
INSERT INTO `municipios` VALUES (235, 7, 'Monclova');
INSERT INTO `municipios` VALUES (236, 7, 'Morelos');
INSERT INTO `municipios` VALUES (237, 7, 'Múzquiz');
INSERT INTO `municipios` VALUES (238, 7, 'Nadadores');
INSERT INTO `municipios` VALUES (239, 7, 'Nava');
INSERT INTO `municipios` VALUES (240, 7, 'Ocampo');
INSERT INTO `municipios` VALUES (241, 7, 'Parras');
INSERT INTO `municipios` VALUES (242, 7, 'Piedras Negras');
INSERT INTO `municipios` VALUES (243, 7, 'Progreso');
INSERT INTO `municipios` VALUES (244, 7, 'Ramos Arizpe');
INSERT INTO `municipios` VALUES (245, 7, 'Sabinas');
INSERT INTO `municipios` VALUES (246, 7, 'Sacramento');
INSERT INTO `municipios` VALUES (247, 7, 'Saltillo');
INSERT INTO `municipios` VALUES (248, 7, 'San Buenaventura');
INSERT INTO `municipios` VALUES (249, 7, 'San Juan de Sabinas');
INSERT INTO `municipios` VALUES (250, 7, 'San Pedro');
INSERT INTO `municipios` VALUES (251, 7, 'Sierra Mojada');
INSERT INTO `municipios` VALUES (252, 7, 'Torreón');
INSERT INTO `municipios` VALUES (253, 7, 'Viesca');
INSERT INTO `municipios` VALUES (254, 7, 'Villa Unión');
INSERT INTO `municipios` VALUES (255, 7, 'Zaragoza');
INSERT INTO `municipios` VALUES (256, 8, 'Armería');
INSERT INTO `municipios` VALUES (257, 8, 'Colima');
INSERT INTO `municipios` VALUES (258, 8, 'Comala');
INSERT INTO `municipios` VALUES (259, 8, 'Coquimatlán');
INSERT INTO `municipios` VALUES (260, 8, 'Cuauhtémoc');
INSERT INTO `municipios` VALUES (261, 8, 'Ixtlahuacán');
INSERT INTO `municipios` VALUES (262, 8, 'Manzanillo');
INSERT INTO `municipios` VALUES (263, 8, 'Minatitlán');
INSERT INTO `municipios` VALUES (264, 8, 'Tecomán');
INSERT INTO `municipios` VALUES (265, 8, 'Villa de Álvarez');
INSERT INTO `municipios` VALUES (266, 9, 'Álvaro Obregón');
INSERT INTO `municipios` VALUES (267, 9, 'Azcapotzalco');
INSERT INTO `municipios` VALUES (268, 9, 'Benito Juárez');
INSERT INTO `municipios` VALUES (269, 9, 'Coyoacán');
INSERT INTO `municipios` VALUES (270, 9, 'Cuajimalpa de Morelos');
INSERT INTO `municipios` VALUES (271, 9, 'Cuauhtémoc');
INSERT INTO `municipios` VALUES (272, 9, 'Gustavo A. Madero');
INSERT INTO `municipios` VALUES (273, 9, 'Iztacalco');
INSERT INTO `municipios` VALUES (274, 9, 'Iztapalapa');
INSERT INTO `municipios` VALUES (275, 9, 'Magdalena Contreras');
INSERT INTO `municipios` VALUES (276, 9, 'Miguel Hidalgo');
INSERT INTO `municipios` VALUES (277, 9, 'Milpa Alta');
INSERT INTO `municipios` VALUES (278, 9, 'Tláhuac');
INSERT INTO `municipios` VALUES (279, 9, 'Tlalpan');
INSERT INTO `municipios` VALUES (280, 9, 'Venustiano Carranza');
INSERT INTO `municipios` VALUES (281, 9, 'Xochimilco');
INSERT INTO `municipios` VALUES (282, 10, 'Canatlán');
INSERT INTO `municipios` VALUES (283, 10, 'Canelas');
INSERT INTO `municipios` VALUES (284, 10, 'Coneto de Comonfort');
INSERT INTO `municipios` VALUES (285, 10, 'Cuencamé');
INSERT INTO `municipios` VALUES (286, 10, 'Durango');
INSERT INTO `municipios` VALUES (287, 10, 'El Oro');
INSERT INTO `municipios` VALUES (288, 10, 'Gómez Palacio');
INSERT INTO `municipios` VALUES (289, 10, 'Gral. Simón Bolívar');
INSERT INTO `municipios` VALUES (290, 10, 'Guadalupe Victoria');
INSERT INTO `municipios` VALUES (291, 10, 'Guanaceví');
INSERT INTO `municipios` VALUES (292, 10, 'Hidalgo');
INSERT INTO `municipios` VALUES (293, 10, 'Indé');
INSERT INTO `municipios` VALUES (294, 10, 'Lerdo');
INSERT INTO `municipios` VALUES (295, 10, 'Mapimí');
INSERT INTO `municipios` VALUES (296, 10, 'Mezquital');
INSERT INTO `municipios` VALUES (297, 10, 'Nazas');
INSERT INTO `municipios` VALUES (298, 10, 'Nombre de Dios');
INSERT INTO `municipios` VALUES (299, 10, 'Nuevo Ideal');
INSERT INTO `municipios` VALUES (300, 10, 'Ocampo');
INSERT INTO `municipios` VALUES (301, 10, 'Otáez');
INSERT INTO `municipios` VALUES (302, 10, 'Pánuco de Coronado');
INSERT INTO `municipios` VALUES (303, 10, 'Peñón Blanco');
INSERT INTO `municipios` VALUES (304, 10, 'Poanas');
INSERT INTO `municipios` VALUES (305, 10, 'Pueblo Nuevo');
INSERT INTO `municipios` VALUES (306, 10, 'Rodeo');
INSERT INTO `municipios` VALUES (307, 10, 'San Bernardo');
INSERT INTO `municipios` VALUES (308, 10, 'San Dimas');
INSERT INTO `municipios` VALUES (309, 10, 'San Juan de Guadalupe');
INSERT INTO `municipios` VALUES (310, 10, 'San Juan del Río');
INSERT INTO `municipios` VALUES (311, 10, 'San Luis del Cordero');
INSERT INTO `municipios` VALUES (312, 10, 'San Pedro del Gallo');
INSERT INTO `municipios` VALUES (313, 10, 'Santa Clara');
INSERT INTO `municipios` VALUES (314, 10, 'Santiago Papasquiaro');
INSERT INTO `municipios` VALUES (315, 10, 'Súchil');
INSERT INTO `municipios` VALUES (316, 10, 'Tamazula');
INSERT INTO `municipios` VALUES (317, 10, 'Tepehuanes');
INSERT INTO `municipios` VALUES (318, 10, 'Tlahualilo');
INSERT INTO `municipios` VALUES (319, 10, 'Topia');
INSERT INTO `municipios` VALUES (320, 10, 'Vicente Guerrero');
INSERT INTO `municipios` VALUES (321, 12, 'Abasolo');
INSERT INTO `municipios` VALUES (322, 12, 'Acámbaro');
INSERT INTO `municipios` VALUES (323, 12, 'Apaseo el Alto');
INSERT INTO `municipios` VALUES (324, 12, 'Apaseo el Grande');
INSERT INTO `municipios` VALUES (325, 12, 'Atarjea');
INSERT INTO `municipios` VALUES (326, 12, 'Celaya');
INSERT INTO `municipios` VALUES (327, 12, 'Comonfort');
INSERT INTO `municipios` VALUES (328, 12, 'Coroneo');
INSERT INTO `municipios` VALUES (329, 12, 'Cortazar');
INSERT INTO `municipios` VALUES (330, 12, 'Cuerámaro');
INSERT INTO `municipios` VALUES (331, 12, 'Doctor Mora');
INSERT INTO `municipios` VALUES (332, 12, 'Dolores Hidalgo');
INSERT INTO `municipios` VALUES (333, 12, 'Guanajuato');
INSERT INTO `municipios` VALUES (334, 12, 'Huanímaro');
INSERT INTO `municipios` VALUES (335, 12, 'Irapuato');
INSERT INTO `municipios` VALUES (336, 12, 'Jaral del Progreso');
INSERT INTO `municipios` VALUES (337, 12, 'Jerécuaro');
INSERT INTO `municipios` VALUES (338, 12, 'León');
INSERT INTO `municipios` VALUES (339, 12, 'Manuel Doblado');
INSERT INTO `municipios` VALUES (340, 12, 'Moroleón');
INSERT INTO `municipios` VALUES (341, 12, 'Ocampo');
INSERT INTO `municipios` VALUES (342, 12, 'Pénjamo');
INSERT INTO `municipios` VALUES (343, 12, 'Pueblo Nuevo');
INSERT INTO `municipios` VALUES (344, 12, 'Purísima del Rincón');
INSERT INTO `municipios` VALUES (345, 12, 'Romita');
INSERT INTO `municipios` VALUES (346, 12, 'Salamanca');
INSERT INTO `municipios` VALUES (347, 12, 'Salvatierra');
INSERT INTO `municipios` VALUES (348, 12, 'San Diego de la Unión');
INSERT INTO `municipios` VALUES (349, 12, 'San Felipe');
INSERT INTO `municipios` VALUES (350, 12, 'San Francisco del Rincón');
INSERT INTO `municipios` VALUES (351, 12, 'San José Iturbide');
INSERT INTO `municipios` VALUES (352, 12, 'San Luis de la Paz');
INSERT INTO `municipios` VALUES (353, 12, 'San Miguel de Allende');
INSERT INTO `municipios` VALUES (354, 12, 'Santa Catarina');
INSERT INTO `municipios` VALUES (355, 12, 'Santa Cruz de Juventino');
INSERT INTO `municipios` VALUES (356, 12, 'Santiago Maravatío');
INSERT INTO `municipios` VALUES (357, 12, 'Silao');
INSERT INTO `municipios` VALUES (358, 12, 'Tarandacuao');
INSERT INTO `municipios` VALUES (359, 12, 'Tarimoro');
INSERT INTO `municipios` VALUES (360, 12, 'Tierra Blanca');
INSERT INTO `municipios` VALUES (361, 12, 'Uruangato');
INSERT INTO `municipios` VALUES (362, 12, 'Valle de Santiago');
INSERT INTO `municipios` VALUES (363, 12, 'Victoria');
INSERT INTO `municipios` VALUES (364, 12, 'Villagrán');
INSERT INTO `municipios` VALUES (365, 12, 'Xichú');
INSERT INTO `municipios` VALUES (366, 12, 'Yuriria');
INSERT INTO `municipios` VALUES (367, 13, 'Acapulco de Juárez');
INSERT INTO `municipios` VALUES (368, 13, 'Acatepec');
INSERT INTO `municipios` VALUES (369, 13, 'Ahuacuotzingo');
INSERT INTO `municipios` VALUES (370, 13, 'Ajuchitlán del Progreso');
INSERT INTO `municipios` VALUES (371, 13, 'Alcozauca de Guerrero');
INSERT INTO `municipios` VALUES (372, 13, 'Alpoyeca');
INSERT INTO `municipios` VALUES (373, 13, 'Apaxtla de Castrejón');
INSERT INTO `municipios` VALUES (374, 13, 'Arcelia');
INSERT INTO `municipios` VALUES (375, 13, 'Atenango del Río');
INSERT INTO `municipios` VALUES (376, 13, 'Atlamajalcingo del Monte');
INSERT INTO `municipios` VALUES (377, 13, 'Atlixtac');
INSERT INTO `municipios` VALUES (378, 13, 'Atoyac de Álvarez');
INSERT INTO `municipios` VALUES (379, 13, 'Ayutla de los Libres');
INSERT INTO `municipios` VALUES (380, 13, 'Azoyú');
INSERT INTO `municipios` VALUES (381, 13, 'Benito Juárez');
INSERT INTO `municipios` VALUES (382, 13, 'Buenavista de Cuéllar');
INSERT INTO `municipios` VALUES (383, 13, 'Chilapa de Álvarez');
INSERT INTO `municipios` VALUES (384, 13, 'Chilpancingo de los Bravo');
INSERT INTO `municipios` VALUES (385, 13, 'Coahuayutla de José María Izazaga');
INSERT INTO `municipios` VALUES (386, 13, 'Cochoapa el Grande');
INSERT INTO `municipios` VALUES (387, 13, 'Cocula');
INSERT INTO `municipios` VALUES (388, 13, 'Copala');
INSERT INTO `municipios` VALUES (389, 13, 'Copalillo');
INSERT INTO `municipios` VALUES (390, 13, 'Copanatoyac');
INSERT INTO `municipios` VALUES (391, 13, 'Coyuca de Benítez');
INSERT INTO `municipios` VALUES (392, 13, 'Coyuca de Catalán');
INSERT INTO `municipios` VALUES (393, 13, 'Cuajinicuilapa');
INSERT INTO `municipios` VALUES (394, 13, 'Cualác');
INSERT INTO `municipios` VALUES (395, 13, 'Cuautepec');
INSERT INTO `municipios` VALUES (396, 13, 'Cuetzala del Progreso');
INSERT INTO `municipios` VALUES (397, 13, 'Cutzamala de Pinzón');
INSERT INTO `municipios` VALUES (398, 13, 'Eduardo Neri');
INSERT INTO `municipios` VALUES (399, 13, 'Florencio Villarreal');
INSERT INTO `municipios` VALUES (400, 13, 'General Canuto A. Neri');
INSERT INTO `municipios` VALUES (401, 13, 'General Heliodoro Castillo');
INSERT INTO `municipios` VALUES (402, 13, 'Huamuxtitlán');
INSERT INTO `municipios` VALUES (403, 13, 'Huitzuco de los Figueroa');
INSERT INTO `municipios` VALUES (404, 13, 'Iguala de la Independencia');
INSERT INTO `municipios` VALUES (405, 13, 'Igualapa');
INSERT INTO `municipios` VALUES (406, 13, 'Iliatenco');
INSERT INTO `municipios` VALUES (407, 13, 'Ixcateopan de Cuauhtémoc');
INSERT INTO `municipios` VALUES (408, 13, 'José Joaquín de Herrera');
INSERT INTO `municipios` VALUES (409, 13, 'Juan R. Escudero');
INSERT INTO `municipios` VALUES (410, 13, 'Juchitán');
INSERT INTO `municipios` VALUES (411, 13, 'La Unión de Isidoro Montes de Oca');
INSERT INTO `municipios` VALUES (412, 13, 'Leonardo Bravo');
INSERT INTO `municipios` VALUES (413, 13, 'Malinaltepec');
INSERT INTO `municipios` VALUES (414, 13, 'Marquelia');
INSERT INTO `municipios` VALUES (415, 13, 'Mártir de Cuilapan');
INSERT INTO `municipios` VALUES (416, 13, 'Metlatónoc');
INSERT INTO `municipios` VALUES (417, 13, 'Mochitlán');
INSERT INTO `municipios` VALUES (418, 13, 'Olinalá');
INSERT INTO `municipios` VALUES (419, 13, 'Ometepec');
INSERT INTO `municipios` VALUES (420, 13, 'Pedro Ascencio Alquisiras');
INSERT INTO `municipios` VALUES (421, 13, 'Petatlán');
INSERT INTO `municipios` VALUES (422, 13, 'Pilcaya');
INSERT INTO `municipios` VALUES (423, 13, 'Pungarabato');
INSERT INTO `municipios` VALUES (424, 13, 'Quechultenango');
INSERT INTO `municipios` VALUES (425, 13, 'San Luis Acatlán');
INSERT INTO `municipios` VALUES (426, 13, 'San Marcos');
INSERT INTO `municipios` VALUES (427, 13, 'San Miguel Totolapan');
INSERT INTO `municipios` VALUES (428, 13, 'Taxco de Alarcón');
INSERT INTO `municipios` VALUES (429, 13, 'Tecoanapa');
INSERT INTO `municipios` VALUES (430, 13, 'Técpan de Galeana');
INSERT INTO `municipios` VALUES (431, 13, 'Teloloapan');
INSERT INTO `municipios` VALUES (432, 13, 'Tepecoacuilco de Trujano');
INSERT INTO `municipios` VALUES (433, 13, 'Tetipac');
INSERT INTO `municipios` VALUES (434, 13, 'Tixtla de Guerrero');
INSERT INTO `municipios` VALUES (435, 13, 'Tlacoachistlahuaca');
INSERT INTO `municipios` VALUES (436, 13, 'Tlacoapa');
INSERT INTO `municipios` VALUES (437, 13, 'Tlalchapa');
INSERT INTO `municipios` VALUES (438, 13, 'Tlalixtlaquilla de Maldanado');
INSERT INTO `municipios` VALUES (439, 13, 'Tlapa de Comonfort');
INSERT INTO `municipios` VALUES (440, 13, 'Tlapehuala');
INSERT INTO `municipios` VALUES (441, 13, 'Xalpatláhuac');
INSERT INTO `municipios` VALUES (442, 13, 'Xochihuehuetlán');
INSERT INTO `municipios` VALUES (443, 13, 'Xochistlahuaca');
INSERT INTO `municipios` VALUES (444, 13, 'Zapotitlán Tablas');
INSERT INTO `municipios` VALUES (445, 13, 'Zihuatanejo de Azueta');
INSERT INTO `municipios` VALUES (446, 13, 'Zirándaro de los Chávez');
INSERT INTO `municipios` VALUES (447, 13, 'Zitlala');
INSERT INTO `municipios` VALUES (448, 14, 'Acatlán');
INSERT INTO `municipios` VALUES (449, 14, 'Acaxochitlán');
INSERT INTO `municipios` VALUES (450, 14, 'Actopan');
INSERT INTO `municipios` VALUES (451, 14, 'Agua Blanca de Iturbide');
INSERT INTO `municipios` VALUES (452, 14, 'Ajacuba');
INSERT INTO `municipios` VALUES (453, 14, 'Alfajayucan');
INSERT INTO `municipios` VALUES (454, 14, 'Almoloya');
INSERT INTO `municipios` VALUES (455, 14, 'Apan');
INSERT INTO `municipios` VALUES (456, 14, 'Atitalaquia');
INSERT INTO `municipios` VALUES (457, 14, 'Atlapexco');
INSERT INTO `municipios` VALUES (458, 14, 'Atotonilco de Tula');
INSERT INTO `municipios` VALUES (459, 14, 'Atotonilco el Grande');
INSERT INTO `municipios` VALUES (460, 14, 'Calnali');
INSERT INTO `municipios` VALUES (461, 14, 'Chapantongo');
INSERT INTO `municipios` VALUES (462, 14, 'Chapulhuacán');
INSERT INTO `municipios` VALUES (463, 14, 'Cardonal');
INSERT INTO `municipios` VALUES (464, 14, 'Chilcuautla');
INSERT INTO `municipios` VALUES (465, 14, 'Cuautepec de Hinojosa');
INSERT INTO `municipios` VALUES (466, 14, 'El Arenal');
INSERT INTO `municipios` VALUES (467, 14, 'Eloxochitlán');
INSERT INTO `municipios` VALUES (468, 14, 'Emiliano Zapata');
INSERT INTO `municipios` VALUES (469, 14, 'Epazoyucan');
INSERT INTO `municipios` VALUES (470, 14, 'Francisco I. Madero');
INSERT INTO `municipios` VALUES (471, 14, 'Huasca de Ocampo');
INSERT INTO `municipios` VALUES (472, 14, 'Huautla');
INSERT INTO `municipios` VALUES (473, 14, 'Huazalingo');
INSERT INTO `municipios` VALUES (474, 14, 'Huejutla de Reyes');
INSERT INTO `municipios` VALUES (475, 14, 'Huehuetla  ');
INSERT INTO `municipios` VALUES (476, 14, 'Huichapan');
INSERT INTO `municipios` VALUES (477, 14, 'Ixmiquilpan');
INSERT INTO `municipios` VALUES (478, 14, 'Jacala de Ledezma');
INSERT INTO `municipios` VALUES (479, 14, 'Jaltocán');
INSERT INTO `municipios` VALUES (480, 14, 'Juárez Hidalgo');
INSERT INTO `municipios` VALUES (481, 14, 'La Misión');
INSERT INTO `municipios` VALUES (482, 14, 'Lolotla');
INSERT INTO `municipios` VALUES (483, 14, 'Metepec');
INSERT INTO `municipios` VALUES (484, 14, 'Metztitlán');
INSERT INTO `municipios` VALUES (485, 14, 'Mineral de la Reforma');
INSERT INTO `municipios` VALUES (486, 14, 'Mineral del Chico');
INSERT INTO `municipios` VALUES (487, 14, 'Mineral del Monte');
INSERT INTO `municipios` VALUES (488, 14, 'Mixquiahuala de Juárez');
INSERT INTO `municipios` VALUES (489, 14, 'Molango de Escamilla');
INSERT INTO `municipios` VALUES (490, 14, 'Nicolás Flores');
INSERT INTO `municipios` VALUES (491, 14, 'Nopala de Villagrán');
INSERT INTO `municipios` VALUES (492, 14, 'Omitlán de Juárez');
INSERT INTO `municipios` VALUES (493, 14, 'Pachuca de Soto');
INSERT INTO `municipios` VALUES (494, 14, 'Pacula');
INSERT INTO `municipios` VALUES (495, 14, 'Pisaflores');
INSERT INTO `municipios` VALUES (496, 14, 'Progreso de Obregón');
INSERT INTO `municipios` VALUES (497, 14, 'San Agustín Metzquititlán');
INSERT INTO `municipios` VALUES (498, 14, 'San Agustín Tlaxiaca');
INSERT INTO `municipios` VALUES (499, 14, 'San Bartolo Tutotepec');
INSERT INTO `municipios` VALUES (500, 14, 'San Felipe Orizatlán');
INSERT INTO `municipios` VALUES (501, 14, 'San Salvador');
INSERT INTO `municipios` VALUES (502, 14, 'Santiago de Anaya');
INSERT INTO `municipios` VALUES (503, 14, 'Santiago Tulantepec de Lugo Guerrero');
INSERT INTO `municipios` VALUES (504, 14, 'Singuilucan');
INSERT INTO `municipios` VALUES (505, 14, 'Tasquillo');
INSERT INTO `municipios` VALUES (506, 14, 'Tecozautla');
INSERT INTO `municipios` VALUES (507, 14, 'Tenango de Doria');
INSERT INTO `municipios` VALUES (508, 14, 'Tepeapulco');
INSERT INTO `municipios` VALUES (509, 14, 'Tepehuacán de Guerrero');
INSERT INTO `municipios` VALUES (510, 14, 'Tepeji del Río de Ocampo');
INSERT INTO `municipios` VALUES (511, 14, 'Tepetitlán');
INSERT INTO `municipios` VALUES (512, 14, 'Tetepango');
INSERT INTO `municipios` VALUES (513, 14, 'Tezontepec de Aldama');
INSERT INTO `municipios` VALUES (514, 14, 'Tianguistengo');
INSERT INTO `municipios` VALUES (515, 14, 'Tizayuca');
INSERT INTO `municipios` VALUES (516, 14, 'Tlahuelilpan');
INSERT INTO `municipios` VALUES (517, 14, 'Tlahuiltepa');
INSERT INTO `municipios` VALUES (518, 14, 'Tlanalapa');
INSERT INTO `municipios` VALUES (519, 14, 'Tlanchinol');
INSERT INTO `municipios` VALUES (520, 14, 'Tlaxcoapan');
INSERT INTO `municipios` VALUES (521, 14, 'Tolcayuca');
INSERT INTO `municipios` VALUES (522, 14, 'Tula de Allende');
INSERT INTO `municipios` VALUES (523, 14, 'Tulancingo de Bravo');
INSERT INTO `municipios` VALUES (524, 14, 'Villa de Tezontepec');
INSERT INTO `municipios` VALUES (525, 14, 'Xochiatipan');
INSERT INTO `municipios` VALUES (526, 14, 'Xochicoatlán');
INSERT INTO `municipios` VALUES (527, 14, 'Yahualica');
INSERT INTO `municipios` VALUES (528, 14, 'Zacualtipán de Ángeles');
INSERT INTO `municipios` VALUES (529, 14, 'Zapotlán de Juárez');
INSERT INTO `municipios` VALUES (530, 14, 'Zempoala');
INSERT INTO `municipios` VALUES (531, 14, 'Zimapán');
INSERT INTO `municipios` VALUES (532, 15, 'Acatic');
INSERT INTO `municipios` VALUES (533, 15, 'Acatlán de Juárez');
INSERT INTO `municipios` VALUES (534, 15, 'Ahualulco de Mercado');
INSERT INTO `municipios` VALUES (535, 15, 'Amacueca');
INSERT INTO `municipios` VALUES (536, 15, 'Amatitán');
INSERT INTO `municipios` VALUES (537, 15, 'Ameca');
INSERT INTO `municipios` VALUES (538, 15, 'Arandas');
INSERT INTO `municipios` VALUES (539, 15, 'Atemajac de Brizuela');
INSERT INTO `municipios` VALUES (540, 15, 'Atengo');
INSERT INTO `municipios` VALUES (541, 15, 'Atenguillo');
INSERT INTO `municipios` VALUES (542, 15, 'Atotonilco el Alto');
INSERT INTO `municipios` VALUES (543, 15, 'Atoyac');
INSERT INTO `municipios` VALUES (544, 15, 'Autlán de Navarro');
INSERT INTO `municipios` VALUES (545, 15, 'Ayotlán');
INSERT INTO `municipios` VALUES (546, 15, 'Ayutla');
INSERT INTO `municipios` VALUES (547, 15, 'Bolaños');
INSERT INTO `municipios` VALUES (548, 15, 'Cabo Corrientes');
INSERT INTO `municipios` VALUES (549, 15, 'Cañadas de Obregón');
INSERT INTO `municipios` VALUES (550, 15, 'Casimiro Castillo');
INSERT INTO `municipios` VALUES (551, 15, 'Chapala');
INSERT INTO `municipios` VALUES (552, 15, 'Chimaltitán');
INSERT INTO `municipios` VALUES (553, 15, 'Chiquilistlán');
INSERT INTO `municipios` VALUES (554, 15, 'Cihuatlán');
INSERT INTO `municipios` VALUES (555, 15, 'Cocula');
INSERT INTO `municipios` VALUES (556, 15, 'Colotlán');
INSERT INTO `municipios` VALUES (557, 15, 'Concepción de Buenos Aires');
INSERT INTO `municipios` VALUES (558, 15, 'Cuauitlán de García Barragán');
INSERT INTO `municipios` VALUES (559, 15, 'Cuautla');
INSERT INTO `municipios` VALUES (560, 15, 'Cuquío');
INSERT INTO `municipios` VALUES (561, 15, 'Degollado');
INSERT INTO `municipios` VALUES (562, 15, 'Ejutla');
INSERT INTO `municipios` VALUES (563, 15, 'El Arenal');
INSERT INTO `municipios` VALUES (564, 15, 'El Grullo');
INSERT INTO `municipios` VALUES (565, 15, 'El Limón');
INSERT INTO `municipios` VALUES (566, 15, 'El Salto');
INSERT INTO `municipios` VALUES (567, 15, 'Encarnación de Díaz');
INSERT INTO `municipios` VALUES (568, 15, 'Etzatlán');
INSERT INTO `municipios` VALUES (569, 15, 'Gómez Farías');
INSERT INTO `municipios` VALUES (570, 15, 'Guachinango');
INSERT INTO `municipios` VALUES (571, 15, 'Guadalajara');
INSERT INTO `municipios` VALUES (572, 15, 'Hostotipaquillo');
INSERT INTO `municipios` VALUES (573, 15, 'Huejúcar');
INSERT INTO `municipios` VALUES (574, 15, 'Huejuquilla el Alto');
INSERT INTO `municipios` VALUES (575, 15, 'Ixtlahuacán de los Membrillos');
INSERT INTO `municipios` VALUES (576, 15, 'Ixtlahuacán del Río');
INSERT INTO `municipios` VALUES (577, 15, 'Jalostotitlán');
INSERT INTO `municipios` VALUES (578, 15, 'Jamay');
INSERT INTO `municipios` VALUES (579, 15, 'Jesús María');
INSERT INTO `municipios` VALUES (580, 15, 'Jilotlán de los Dolores');
INSERT INTO `municipios` VALUES (581, 15, 'Jocotepec');
INSERT INTO `municipios` VALUES (582, 15, 'Juanacatlán');
INSERT INTO `municipios` VALUES (583, 15, 'Juchitlán');
INSERT INTO `municipios` VALUES (584, 15, 'La Barca');
INSERT INTO `municipios` VALUES (585, 15, 'Lagos de Moreno');
INSERT INTO `municipios` VALUES (586, 15, 'La Manzanilla de la Paz');
INSERT INTO `municipios` VALUES (587, 15, 'La Huerta');
INSERT INTO `municipios` VALUES (588, 15, 'Magdalena');
INSERT INTO `municipios` VALUES (589, 15, 'Mascota');
INSERT INTO `municipios` VALUES (590, 15, 'Mazamitla');
INSERT INTO `municipios` VALUES (591, 15, 'Mexticacán');
INSERT INTO `municipios` VALUES (592, 15, 'Mezquitic');
INSERT INTO `municipios` VALUES (593, 15, 'Mixtlán');
INSERT INTO `municipios` VALUES (594, 15, 'Ojuelos de Jalisco');
INSERT INTO `municipios` VALUES (595, 15, 'Ocotlán ');
INSERT INTO `municipios` VALUES (596, 15, 'Pihuamo');
INSERT INTO `municipios` VALUES (597, 15, 'Poncitlán');
INSERT INTO `municipios` VALUES (598, 15, 'Puerto Vallarta');
INSERT INTO `municipios` VALUES (599, 15, 'Quitupan');
INSERT INTO `municipios` VALUES (600, 15, 'San Cristóbal de la Barranca');
INSERT INTO `municipios` VALUES (601, 15, 'San Diego de Alejandría');
INSERT INTO `municipios` VALUES (602, 15, 'San Gabriel');
INSERT INTO `municipios` VALUES (603, 15, 'San Ignacio Cerro Gordo ');
INSERT INTO `municipios` VALUES (604, 15, 'San Juan de los Lagos');
INSERT INTO `municipios` VALUES (605, 15, 'San Juanito de Escobedo');
INSERT INTO `municipios` VALUES (606, 15, 'San Julián');
INSERT INTO `municipios` VALUES (607, 15, 'San Marcos');
INSERT INTO `municipios` VALUES (608, 15, 'San Martín de Bolaños');
INSERT INTO `municipios` VALUES (609, 15, 'San Martín Hidalgo');
INSERT INTO `municipios` VALUES (610, 15, 'San Miguel el Alto');
INSERT INTO `municipios` VALUES (611, 15, 'San Sebastián del Oeste');
INSERT INTO `municipios` VALUES (612, 15, 'Santa María de los Ángeles');
INSERT INTO `municipios` VALUES (613, 15, 'Santa María del Oro');
INSERT INTO `municipios` VALUES (614, 15, 'Sayula');
INSERT INTO `municipios` VALUES (615, 15, 'Tala');
INSERT INTO `municipios` VALUES (616, 15, 'Talpa de Allende');
INSERT INTO `municipios` VALUES (617, 15, 'Tamazula de Gordiano');
INSERT INTO `municipios` VALUES (618, 15, 'Tapalpa');
INSERT INTO `municipios` VALUES (619, 15, 'Tecalitlán');
INSERT INTO `municipios` VALUES (620, 15, 'Techaluta de Montenegro');
INSERT INTO `municipios` VALUES (621, 15, 'Tecolotlán');
INSERT INTO `municipios` VALUES (622, 15, 'Tenamaxtlán');
INSERT INTO `municipios` VALUES (623, 15, 'Teocaltiche');
INSERT INTO `municipios` VALUES (624, 15, 'Teocuitatlán de Corona');
INSERT INTO `municipios` VALUES (625, 15, 'Tepatitlán de Morelos');
INSERT INTO `municipios` VALUES (626, 15, 'Tequila');
INSERT INTO `municipios` VALUES (627, 15, 'Teuchitlán');
INSERT INTO `municipios` VALUES (628, 15, 'Tizapán el Alto');
INSERT INTO `municipios` VALUES (629, 15, 'Tlajomulco de Zúñiga');
INSERT INTO `municipios` VALUES (630, 15, 'Tlaquepaque');
INSERT INTO `municipios` VALUES (631, 15, 'Tolimán');
INSERT INTO `municipios` VALUES (632, 15, 'Tomatlán');
INSERT INTO `municipios` VALUES (633, 15, 'Tonalá');
INSERT INTO `municipios` VALUES (634, 15, 'Tonaya');
INSERT INTO `municipios` VALUES (635, 15, 'Tonila');
INSERT INTO `municipios` VALUES (636, 15, 'Totatiche');
INSERT INTO `municipios` VALUES (637, 15, 'Tototlán');
INSERT INTO `municipios` VALUES (638, 15, 'Tuxcacuesco');
INSERT INTO `municipios` VALUES (639, 15, 'Tuxcueca');
INSERT INTO `municipios` VALUES (640, 15, 'Tuxpan');
INSERT INTO `municipios` VALUES (641, 15, 'Unión de San Antonio');
INSERT INTO `municipios` VALUES (642, 15, 'Unión de Tula');
INSERT INTO `municipios` VALUES (643, 15, 'Valle de Guadalupe');
INSERT INTO `municipios` VALUES (644, 15, 'Valle de Juárez');
INSERT INTO `municipios` VALUES (645, 15, 'Villa Corona');
INSERT INTO `municipios` VALUES (646, 15, 'Villa Guerrero');
INSERT INTO `municipios` VALUES (647, 15, 'Villa Hidalgo');
INSERT INTO `municipios` VALUES (648, 15, 'Villa Purificación');
INSERT INTO `municipios` VALUES (649, 15, 'Yahualica de González Gallo');
INSERT INTO `municipios` VALUES (650, 15, 'Zacoalco de Torres');
INSERT INTO `municipios` VALUES (651, 15, 'Zapopan');
INSERT INTO `municipios` VALUES (652, 15, 'Zapotiltic');
INSERT INTO `municipios` VALUES (653, 15, 'Zapotitlán de Vadillo');
INSERT INTO `municipios` VALUES (654, 15, 'Zapotlán del Rey');
INSERT INTO `municipios` VALUES (655, 15, 'Zapotlanejo ');
INSERT INTO `municipios` VALUES (656, 15, 'Zapotlán el Grande ');
INSERT INTO `municipios` VALUES (657, 11, 'Acambay');
INSERT INTO `municipios` VALUES (658, 11, 'Acolman');
INSERT INTO `municipios` VALUES (659, 11, 'Aculco');
INSERT INTO `municipios` VALUES (660, 11, 'Almoloya de Alquisiras');
INSERT INTO `municipios` VALUES (661, 11, 'Almoloya de Juárez');
INSERT INTO `municipios` VALUES (662, 11, 'Almoloya del Río');
INSERT INTO `municipios` VALUES (663, 11, 'Amanalco');
INSERT INTO `municipios` VALUES (664, 11, 'Amatepec');
INSERT INTO `municipios` VALUES (665, 11, 'Amecameca');
INSERT INTO `municipios` VALUES (666, 11, 'Apaxco');
INSERT INTO `municipios` VALUES (667, 11, 'Atenco');
INSERT INTO `municipios` VALUES (668, 11, 'Atizapán');
INSERT INTO `municipios` VALUES (669, 11, 'Atizapán de Zaragoza');
INSERT INTO `municipios` VALUES (670, 11, 'Atlacomulco');
INSERT INTO `municipios` VALUES (671, 11, 'Atlautla');
INSERT INTO `municipios` VALUES (672, 11, 'Axapusco');
INSERT INTO `municipios` VALUES (673, 11, 'Ayapango');
INSERT INTO `municipios` VALUES (674, 11, 'Calimaya');
INSERT INTO `municipios` VALUES (675, 11, 'Capulhuac');
INSERT INTO `municipios` VALUES (676, 11, 'Chalco');
INSERT INTO `municipios` VALUES (677, 11, 'Chapa de Mota');
INSERT INTO `municipios` VALUES (678, 11, 'Chapultepec');
INSERT INTO `municipios` VALUES (679, 11, 'Chiautla');
INSERT INTO `municipios` VALUES (680, 11, 'Chicoloapan');
INSERT INTO `municipios` VALUES (681, 11, 'Chiconcuac');
INSERT INTO `municipios` VALUES (682, 11, 'Chimalhuacán');
INSERT INTO `municipios` VALUES (683, 11, 'Coacalco de Berriozábal');
INSERT INTO `municipios` VALUES (684, 11, 'Coatepec Harinas');
INSERT INTO `municipios` VALUES (685, 11, 'Cocotitlán');
INSERT INTO `municipios` VALUES (686, 11, 'Coyotepec');
INSERT INTO `municipios` VALUES (687, 11, 'Cuautitlán');
INSERT INTO `municipios` VALUES (688, 11, 'Cuautitlán Izcalli');
INSERT INTO `municipios` VALUES (689, 11, 'Donato Guerra');
INSERT INTO `municipios` VALUES (690, 11, 'Ecatepec de Morelos');
INSERT INTO `municipios` VALUES (691, 11, 'Ecatzingo');
INSERT INTO `municipios` VALUES (692, 11, 'El Oro');
INSERT INTO `municipios` VALUES (693, 11, 'Huehuetoca');
INSERT INTO `municipios` VALUES (694, 11, 'Hueypoxtla');
INSERT INTO `municipios` VALUES (695, 11, 'Huixquilucan');
INSERT INTO `municipios` VALUES (696, 11, 'Isidro Fabela');
INSERT INTO `municipios` VALUES (697, 11, 'Ixtapaluca');
INSERT INTO `municipios` VALUES (698, 11, 'Ixtapan de la Sal');
INSERT INTO `municipios` VALUES (699, 11, 'Ixtapan del Oro');
INSERT INTO `municipios` VALUES (700, 11, 'Ixtlahuaca');
INSERT INTO `municipios` VALUES (701, 11, 'Jaltenco');
INSERT INTO `municipios` VALUES (702, 11, 'Jilotepec');
INSERT INTO `municipios` VALUES (703, 11, 'Jilotzingo');
INSERT INTO `municipios` VALUES (704, 11, 'Jiquipilco');
INSERT INTO `municipios` VALUES (705, 11, 'Jocotitlán');
INSERT INTO `municipios` VALUES (706, 11, 'Joquicingo');
INSERT INTO `municipios` VALUES (707, 11, 'Juchitepec');
INSERT INTO `municipios` VALUES (708, 11, 'La Paz');
INSERT INTO `municipios` VALUES (709, 11, 'Lerma');
INSERT INTO `municipios` VALUES (710, 11, 'Luvianos');
INSERT INTO `municipios` VALUES (711, 11, 'Malinalco');
INSERT INTO `municipios` VALUES (712, 11, 'Melchor Ocampo');
INSERT INTO `municipios` VALUES (713, 11, 'Metepec');
INSERT INTO `municipios` VALUES (714, 11, 'Mexicaltzingo');
INSERT INTO `municipios` VALUES (715, 11, 'Morelos');
INSERT INTO `municipios` VALUES (716, 11, 'Naucalpan de Juárez');
INSERT INTO `municipios` VALUES (717, 11, 'Nextlalpan');
INSERT INTO `municipios` VALUES (718, 11, 'Nezahualcoyotl');
INSERT INTO `municipios` VALUES (719, 11, 'Nicolás Romero');
INSERT INTO `municipios` VALUES (720, 11, 'Nopaltepec');
INSERT INTO `municipios` VALUES (721, 11, 'Ocoyoacac');
INSERT INTO `municipios` VALUES (722, 11, 'Ocuilan');
INSERT INTO `municipios` VALUES (723, 11, 'Otumba');
INSERT INTO `municipios` VALUES (724, 11, 'Otzoloapan');
INSERT INTO `municipios` VALUES (725, 11, 'Otzolotepec');
INSERT INTO `municipios` VALUES (726, 11, 'Ozumba');
INSERT INTO `municipios` VALUES (727, 11, 'Papalotla');
INSERT INTO `municipios` VALUES (728, 11, 'Polotitlán');
INSERT INTO `municipios` VALUES (729, 11, 'Rayón');
INSERT INTO `municipios` VALUES (730, 11, 'San Antonio la Isla');
INSERT INTO `municipios` VALUES (731, 11, 'San Felipe del Progreso');
INSERT INTO `municipios` VALUES (732, 11, 'San José del Rincón');
INSERT INTO `municipios` VALUES (733, 11, 'San Martín de las Pirámides');
INSERT INTO `municipios` VALUES (734, 11, 'San Mateo Atenco');
INSERT INTO `municipios` VALUES (735, 11, 'San Simón de Guerrero');
INSERT INTO `municipios` VALUES (736, 11, 'Santo Tomás');
INSERT INTO `municipios` VALUES (737, 11, 'Soyaniquilpan de Juárez');
INSERT INTO `municipios` VALUES (738, 11, 'Sultepec');
INSERT INTO `municipios` VALUES (739, 11, 'Tecámac');
INSERT INTO `municipios` VALUES (740, 11, 'Tejupilco');
INSERT INTO `municipios` VALUES (741, 11, 'Temamatla');
INSERT INTO `municipios` VALUES (742, 11, 'Temascalapa');
INSERT INTO `municipios` VALUES (743, 11, 'Temascalcingo');
INSERT INTO `municipios` VALUES (744, 11, 'Temascaltepec');
INSERT INTO `municipios` VALUES (745, 11, 'Temoaya');
INSERT INTO `municipios` VALUES (746, 11, 'Tenancingo');
INSERT INTO `municipios` VALUES (747, 11, 'Tenango del Aire');
INSERT INTO `municipios` VALUES (748, 11, 'Tenango del Valle');
INSERT INTO `municipios` VALUES (749, 11, 'Teoloyucán');
INSERT INTO `municipios` VALUES (750, 11, 'Teotihuacán');
INSERT INTO `municipios` VALUES (751, 11, 'Tepetlaoxtoc');
INSERT INTO `municipios` VALUES (752, 11, 'Tepetlixpa');
INSERT INTO `municipios` VALUES (753, 11, 'Tepotzotlán');
INSERT INTO `municipios` VALUES (754, 11, 'Tequixquiac');
INSERT INTO `municipios` VALUES (755, 11, 'Texcaltitlán');
INSERT INTO `municipios` VALUES (756, 11, 'Texcalyacac');
INSERT INTO `municipios` VALUES (757, 11, 'Texcoco');
INSERT INTO `municipios` VALUES (758, 11, 'Tezoyuca');
INSERT INTO `municipios` VALUES (759, 11, 'Tianguistenco');
INSERT INTO `municipios` VALUES (760, 11, 'Timilpan');
INSERT INTO `municipios` VALUES (761, 11, 'Tlalmanalco');
INSERT INTO `municipios` VALUES (762, 11, 'Tlalnepantla de Baz');
INSERT INTO `municipios` VALUES (763, 11, 'Tlatlaya');
INSERT INTO `municipios` VALUES (764, 11, 'Toluca');
INSERT INTO `municipios` VALUES (765, 11, 'Tonanitla');
INSERT INTO `municipios` VALUES (766, 11, 'Tonatico');
INSERT INTO `municipios` VALUES (767, 11, 'Tultepec');
INSERT INTO `municipios` VALUES (768, 11, 'Tultitlán');
INSERT INTO `municipios` VALUES (769, 11, 'Valle de Bravo');
INSERT INTO `municipios` VALUES (770, 11, 'Valle de Chalco Solidaridad');
INSERT INTO `municipios` VALUES (771, 11, 'Villa de Allende');
INSERT INTO `municipios` VALUES (772, 11, 'Villa del Carbón');
INSERT INTO `municipios` VALUES (773, 11, 'Villa Guerrero');
INSERT INTO `municipios` VALUES (774, 11, 'Villa Victoria');
INSERT INTO `municipios` VALUES (775, 11, 'Xalatlaco');
INSERT INTO `municipios` VALUES (776, 11, 'Xonacatlán');
INSERT INTO `municipios` VALUES (777, 11, 'Zacazonapan');
INSERT INTO `municipios` VALUES (778, 11, 'Zacualpan');
INSERT INTO `municipios` VALUES (779, 11, 'Zinacantepec');
INSERT INTO `municipios` VALUES (780, 11, 'Zumpahuacán');
INSERT INTO `municipios` VALUES (781, 11, 'Zumpango');
INSERT INTO `municipios` VALUES (782, 16, 'Acuitzio');
INSERT INTO `municipios` VALUES (783, 16, 'Aguililla');
INSERT INTO `municipios` VALUES (784, 16, 'Álvaro Obregón');
INSERT INTO `municipios` VALUES (785, 16, 'Angamacutiro');
INSERT INTO `municipios` VALUES (786, 16, 'Angangueo');
INSERT INTO `municipios` VALUES (787, 16, 'Apatzingán');
INSERT INTO `municipios` VALUES (788, 16, 'Aporo');
INSERT INTO `municipios` VALUES (789, 16, 'Aquila');
INSERT INTO `municipios` VALUES (790, 16, 'Ario de Rosales');
INSERT INTO `municipios` VALUES (791, 16, 'Arteaga Riseñas');
INSERT INTO `municipios` VALUES (792, 16, 'Briseñas');
INSERT INTO `municipios` VALUES (793, 16, 'Buenavista');
INSERT INTO `municipios` VALUES (794, 16, 'Carácuaro');
INSERT INTO `municipios` VALUES (795, 16, 'Charapan');
INSERT INTO `municipios` VALUES (796, 16, 'Charo');
INSERT INTO `municipios` VALUES (797, 16, 'Chavinda');
INSERT INTO `municipios` VALUES (798, 16, 'Cherán');
INSERT INTO `municipios` VALUES (799, 16, 'Chilchota');
INSERT INTO `municipios` VALUES (800, 16, 'Chuinicuila');
INSERT INTO `municipios` VALUES (801, 16, 'Chucándiro');
INSERT INTO `municipios` VALUES (802, 16, 'Churintzio');
INSERT INTO `municipios` VALUES (803, 16, 'Churumuco');
INSERT INTO `municipios` VALUES (804, 16, 'Coahuayana');
INSERT INTO `municipios` VALUES (805, 16, 'Coalcomán de Vázquez Pallares');
INSERT INTO `municipios` VALUES (806, 16, 'Coeneo');
INSERT INTO `municipios` VALUES (807, 16, 'Cojumatlán de Régules');
INSERT INTO `municipios` VALUES (808, 16, 'Contepec');
INSERT INTO `municipios` VALUES (809, 16, 'Copándaro');
INSERT INTO `municipios` VALUES (810, 16, 'Cotija');
INSERT INTO `municipios` VALUES (811, 16, 'Cuitzeo');
INSERT INTO `municipios` VALUES (812, 16, 'Escuandureo');
INSERT INTO `municipios` VALUES (813, 16, 'Epitacio Huerta');
INSERT INTO `municipios` VALUES (814, 16, 'Erongarícuaro');
INSERT INTO `municipios` VALUES (815, 16, 'Gabriel Zamora');
INSERT INTO `municipios` VALUES (816, 16, 'Hidalgo');
INSERT INTO `municipios` VALUES (817, 16, 'Huandacareo');
INSERT INTO `municipios` VALUES (818, 16, 'Huaniqueo');
INSERT INTO `municipios` VALUES (819, 16, 'Huetamo');
INSERT INTO `municipios` VALUES (820, 16, 'Huiramba');
INSERT INTO `municipios` VALUES (821, 16, 'Indaparapeo');
INSERT INTO `municipios` VALUES (822, 16, 'Irimbo');
INSERT INTO `municipios` VALUES (823, 16, 'Ixtlán');
INSERT INTO `municipios` VALUES (824, 16, 'Jacona');
INSERT INTO `municipios` VALUES (825, 16, 'Jiménez');
INSERT INTO `municipios` VALUES (826, 16, 'Jiquilpan');
INSERT INTO `municipios` VALUES (827, 16, 'José Sixto Verduzco');
INSERT INTO `municipios` VALUES (828, 16, 'Juárez');
INSERT INTO `municipios` VALUES (829, 16, 'Jungapeo');
INSERT INTO `municipios` VALUES (830, 16, 'La Huacana');
INSERT INTO `municipios` VALUES (831, 16, 'La Piedad');
INSERT INTO `municipios` VALUES (832, 16, 'Lagunillas');
INSERT INTO `municipios` VALUES (833, 16, 'Lázaro Cárdenas');
INSERT INTO `municipios` VALUES (834, 16, 'Los Reyes');
INSERT INTO `municipios` VALUES (835, 16, 'Madero');
INSERT INTO `municipios` VALUES (836, 16, 'Maravatío');
INSERT INTO `municipios` VALUES (837, 16, 'Marcos Castellanos');
INSERT INTO `municipios` VALUES (838, 16, 'Morelia');
INSERT INTO `municipios` VALUES (839, 16, 'Morelos');
INSERT INTO `municipios` VALUES (840, 16, 'Múgica');
INSERT INTO `municipios` VALUES (841, 16, 'Nahuatzen');
INSERT INTO `municipios` VALUES (842, 16, 'Nocupétaro');
INSERT INTO `municipios` VALUES (843, 16, 'Nuevo Parangaricutiro');
INSERT INTO `municipios` VALUES (844, 16, 'Nuevo Urecho');
INSERT INTO `municipios` VALUES (845, 16, 'Numarán');
INSERT INTO `municipios` VALUES (846, 16, 'Ocampo');
INSERT INTO `municipios` VALUES (847, 16, 'Pajacuarán');
INSERT INTO `municipios` VALUES (848, 16, 'Panindícuaro');
INSERT INTO `municipios` VALUES (849, 16, 'Paracho');
INSERT INTO `municipios` VALUES (850, 16, 'Parácuaro');
INSERT INTO `municipios` VALUES (851, 16, 'Pátzcuaro');
INSERT INTO `municipios` VALUES (852, 16, 'Penjamillo');
INSERT INTO `municipios` VALUES (853, 16, 'Peribán');
INSERT INTO `municipios` VALUES (854, 16, 'Purépero');
INSERT INTO `municipios` VALUES (855, 16, 'Puruándiro');
INSERT INTO `municipios` VALUES (856, 16, 'Queréndaro');
INSERT INTO `municipios` VALUES (857, 16, 'Quiroga');
INSERT INTO `municipios` VALUES (858, 16, 'Sahuayo');
INSERT INTO `municipios` VALUES (859, 16, 'Salvador Escalante');
INSERT INTO `municipios` VALUES (860, 16, 'San Lucas');
INSERT INTO `municipios` VALUES (861, 16, 'Santa Ana Maya');
INSERT INTO `municipios` VALUES (862, 16, 'Senguio');
INSERT INTO `municipios` VALUES (863, 16, 'Susupuato');
INSERT INTO `municipios` VALUES (864, 16, 'Tancítaro');
INSERT INTO `municipios` VALUES (865, 16, 'Tangamandapio');
INSERT INTO `municipios` VALUES (866, 16, 'Tangancícuaro');
INSERT INTO `municipios` VALUES (867, 16, 'Tanhuato');
INSERT INTO `municipios` VALUES (868, 16, 'Taretan');
INSERT INTO `municipios` VALUES (869, 16, 'Tarímbaro');
INSERT INTO `municipios` VALUES (870, 16, 'Tepalcatepec');
INSERT INTO `municipios` VALUES (871, 16, 'Tingüindín');
INSERT INTO `municipios` VALUES (872, 16, 'Tingambato');
INSERT INTO `municipios` VALUES (873, 16, 'Tiquicheo de Nicolás Romero');
INSERT INTO `municipios` VALUES (874, 16, 'Tlalpujahua');
INSERT INTO `municipios` VALUES (875, 16, 'Tlazazalca');
INSERT INTO `municipios` VALUES (876, 16, 'Tocumbo');
INSERT INTO `municipios` VALUES (877, 16, 'Tumbiscatío');
INSERT INTO `municipios` VALUES (878, 16, 'Turicato');
INSERT INTO `municipios` VALUES (879, 16, 'Tuxpan');
INSERT INTO `municipios` VALUES (880, 16, 'Tuzantla');
INSERT INTO `municipios` VALUES (881, 16, 'Tzintzuntzan');
INSERT INTO `municipios` VALUES (882, 16, 'Tzitzio');
INSERT INTO `municipios` VALUES (883, 16, 'Uruapan');
INSERT INTO `municipios` VALUES (884, 16, 'Venustiano Carranza');
INSERT INTO `municipios` VALUES (885, 16, 'Villamar');
INSERT INTO `municipios` VALUES (886, 16, 'Vista Hermosa');
INSERT INTO `municipios` VALUES (887, 16, 'Yurécuaro');
INSERT INTO `municipios` VALUES (888, 16, 'Zacapu');
INSERT INTO `municipios` VALUES (889, 16, 'Zamora');
INSERT INTO `municipios` VALUES (890, 16, 'Zináparo');
INSERT INTO `municipios` VALUES (891, 16, 'Zinapécuaro');
INSERT INTO `municipios` VALUES (892, 16, 'Ziracuaretiro');
INSERT INTO `municipios` VALUES (893, 16, 'Zitácuaro');
INSERT INTO `municipios` VALUES (894, 17, 'Amacuzac');
INSERT INTO `municipios` VALUES (895, 17, 'Atlatlahucan');
INSERT INTO `municipios` VALUES (896, 17, 'Axochiapan');
INSERT INTO `municipios` VALUES (897, 17, 'Ayala');
INSERT INTO `municipios` VALUES (898, 17, 'Coatlán del Río');
INSERT INTO `municipios` VALUES (899, 17, 'Cuautla');
INSERT INTO `municipios` VALUES (900, 17, 'Cuernavaca');
INSERT INTO `municipios` VALUES (901, 17, 'Emiliano Zapata');
INSERT INTO `municipios` VALUES (902, 17, 'Huitzilac');
INSERT INTO `municipios` VALUES (903, 17, 'Jantetelco');
INSERT INTO `municipios` VALUES (904, 17, 'Jiutepec');
INSERT INTO `municipios` VALUES (905, 17, 'Jojutla');
INSERT INTO `municipios` VALUES (906, 17, 'Jonacatepec');
INSERT INTO `municipios` VALUES (907, 17, 'Mazatepec');
INSERT INTO `municipios` VALUES (908, 17, 'Miacatlán');
INSERT INTO `municipios` VALUES (909, 17, 'Ocuituco');
INSERT INTO `municipios` VALUES (910, 17, 'Puente de Ixtla');
INSERT INTO `municipios` VALUES (911, 17, 'Temixco');
INSERT INTO `municipios` VALUES (912, 17, 'Temoac');
INSERT INTO `municipios` VALUES (913, 17, 'Tepalcingo');
INSERT INTO `municipios` VALUES (914, 17, 'Tepoztlán');
INSERT INTO `municipios` VALUES (915, 17, 'Tetecala');
INSERT INTO `municipios` VALUES (916, 17, 'Tetela del Volcán');
INSERT INTO `municipios` VALUES (917, 17, 'Tlalnepantla');
INSERT INTO `municipios` VALUES (918, 17, 'Tlaltizapán de Zapata');
INSERT INTO `municipios` VALUES (919, 17, 'Tlaquiltenango');
INSERT INTO `municipios` VALUES (920, 17, 'Tlayacapan');
INSERT INTO `municipios` VALUES (921, 17, 'Totolapan');
INSERT INTO `municipios` VALUES (922, 17, 'Xochitepec');
INSERT INTO `municipios` VALUES (923, 17, 'Yautepec de Zaragoza');
INSERT INTO `municipios` VALUES (924, 17, 'Yecapixtla');
INSERT INTO `municipios` VALUES (925, 17, 'Zacatepec de Hidalgo');
INSERT INTO `municipios` VALUES (926, 17, 'Zacualpan de Amilpas');
INSERT INTO `municipios` VALUES (927, 18, 'Acaponeta');
INSERT INTO `municipios` VALUES (928, 18, 'Ahuacatlán');
INSERT INTO `municipios` VALUES (929, 18, 'Amatlán de Cañas');
INSERT INTO `municipios` VALUES (930, 18, 'Bahía de Banderas');
INSERT INTO `municipios` VALUES (931, 18, 'Compostela');
INSERT INTO `municipios` VALUES (932, 18, 'El Nayar');
INSERT INTO `municipios` VALUES (933, 18, 'Huajicori');
INSERT INTO `municipios` VALUES (934, 18, 'Ixtlán del Río');
INSERT INTO `municipios` VALUES (935, 18, 'Jala');
INSERT INTO `municipios` VALUES (936, 18, 'La Yesca');
INSERT INTO `municipios` VALUES (937, 18, 'Rosamorada');
INSERT INTO `municipios` VALUES (938, 18, 'Ruíz');
INSERT INTO `municipios` VALUES (939, 18, 'San Blas');
INSERT INTO `municipios` VALUES (940, 18, 'San Pedro Lagunillas');
INSERT INTO `municipios` VALUES (941, 18, 'Santa María del Oro');
INSERT INTO `municipios` VALUES (942, 18, 'Santiago Ixcuintla');
INSERT INTO `municipios` VALUES (943, 18, 'Tecuala');
INSERT INTO `municipios` VALUES (944, 18, 'Tepic');
INSERT INTO `municipios` VALUES (945, 18, 'Tuxpan');
INSERT INTO `municipios` VALUES (946, 18, 'Xalisco');
INSERT INTO `municipios` VALUES (947, 19, 'Abasolo');
INSERT INTO `municipios` VALUES (948, 19, 'Agualeguas');
INSERT INTO `municipios` VALUES (949, 19, 'Allende');
INSERT INTO `municipios` VALUES (950, 19, 'Anáhuac');
INSERT INTO `municipios` VALUES (951, 19, 'Apodaca');
INSERT INTO `municipios` VALUES (952, 19, 'Aramberri');
INSERT INTO `municipios` VALUES (953, 19, 'Bustamante');
INSERT INTO `municipios` VALUES (954, 19, 'Cadereyta Jiménez');
INSERT INTO `municipios` VALUES (955, 19, 'Cerralvo');
INSERT INTO `municipios` VALUES (956, 19, 'China');
INSERT INTO `municipios` VALUES (957, 19, 'Ciénega de Flores');
INSERT INTO `municipios` VALUES (958, 19, 'Doctor Arroyo');
INSERT INTO `municipios` VALUES (959, 19, 'Doctor Coss');
INSERT INTO `municipios` VALUES (960, 19, 'Doctor González');
INSERT INTO `municipios` VALUES (961, 19, 'El Carmen');
INSERT INTO `municipios` VALUES (962, 19, 'Galeana');
INSERT INTO `municipios` VALUES (963, 19, 'García');
INSERT INTO `municipios` VALUES (964, 19, 'General Bravo');
INSERT INTO `municipios` VALUES (965, 19, 'General Escobedo');
INSERT INTO `municipios` VALUES (966, 19, 'General Terán');
INSERT INTO `municipios` VALUES (967, 19, 'General Treviño');
INSERT INTO `municipios` VALUES (968, 19, 'General Zaragoza');
INSERT INTO `municipios` VALUES (969, 19, 'General Zuazua');
INSERT INTO `municipios` VALUES (970, 19, 'Guadalupe');
INSERT INTO `municipios` VALUES (971, 19, 'Hidalgo');
INSERT INTO `municipios` VALUES (972, 19, 'Higueras');
INSERT INTO `municipios` VALUES (973, 19, 'Hualahuises');
INSERT INTO `municipios` VALUES (974, 19, 'Iturbide');
INSERT INTO `municipios` VALUES (975, 19, 'Juárez');
INSERT INTO `municipios` VALUES (976, 19, 'Lampazos de Naranjo');
INSERT INTO `municipios` VALUES (977, 19, 'Linares');
INSERT INTO `municipios` VALUES (978, 19, 'Los Aldamas');
INSERT INTO `municipios` VALUES (979, 19, 'Los Herreras');
INSERT INTO `municipios` VALUES (980, 19, 'Los Ramones');
INSERT INTO `municipios` VALUES (981, 19, 'Marín');
INSERT INTO `municipios` VALUES (982, 19, 'Melchor Ocampo');
INSERT INTO `municipios` VALUES (983, 19, 'Mier y Noriega');
INSERT INTO `municipios` VALUES (984, 19, 'Mina');
INSERT INTO `municipios` VALUES (985, 19, 'Montemorelos');
INSERT INTO `municipios` VALUES (986, 19, 'Monterrey');
INSERT INTO `municipios` VALUES (987, 19, 'Parás');
INSERT INTO `municipios` VALUES (988, 19, 'Pesquería');
INSERT INTO `municipios` VALUES (989, 19, 'Rayones');
INSERT INTO `municipios` VALUES (990, 19, 'Sabinas Hidalgo');
INSERT INTO `municipios` VALUES (991, 19, 'Salinas Victoria');
INSERT INTO `municipios` VALUES (992, 19, 'San Nicolás de los Garza');
INSERT INTO `municipios` VALUES (993, 19, 'San Pedro Garza García');
INSERT INTO `municipios` VALUES (994, 19, 'Santa Catarina');
INSERT INTO `municipios` VALUES (995, 19, 'Santiago');
INSERT INTO `municipios` VALUES (996, 19, 'Vallecillo');
INSERT INTO `municipios` VALUES (997, 19, 'Villaldama');
INSERT INTO `municipios` VALUES (998, 20, 'Abejones');
INSERT INTO `municipios` VALUES (999, 20, 'Acatlán de Pérez Figueroa');
INSERT INTO `municipios` VALUES (1000, 20, 'Ánimas Trujano');
INSERT INTO `municipios` VALUES (1001, 20, 'Asunción Cacalotepec');
INSERT INTO `municipios` VALUES (1002, 20, 'Asunción Cuyotepeji');
INSERT INTO `municipios` VALUES (1003, 20, 'Asunción Ixtaltepec');
INSERT INTO `municipios` VALUES (1004, 20, 'Asunción Nochixtlán');
INSERT INTO `municipios` VALUES (1005, 20, 'Asunción Ocotlán');
INSERT INTO `municipios` VALUES (1006, 20, 'Asunción Tlacolulita');
INSERT INTO `municipios` VALUES (1007, 20, 'Ayoquezco de Aldama');
INSERT INTO `municipios` VALUES (1008, 20, 'Ayotzintepec');
INSERT INTO `municipios` VALUES (1009, 20, 'Calihualá');
INSERT INTO `municipios` VALUES (1010, 20, 'Candelaria Loxicha');
INSERT INTO `municipios` VALUES (1011, 20, 'Capulalpam de Méndez');
INSERT INTO `municipios` VALUES (1012, 20, 'Chahuites');
INSERT INTO `municipios` VALUES (1013, 20, 'Chalcatongo de Hidalgo');
INSERT INTO `municipios` VALUES (1014, 20, 'Chiquihuitlán de Benito Juárez');
INSERT INTO `municipios` VALUES (1015, 20, 'Ciénega de Zimatlán');
INSERT INTO `municipios` VALUES (1016, 20, 'Ciudad Ixtepec');
INSERT INTO `municipios` VALUES (1017, 20, 'Coatecas Altas');
INSERT INTO `municipios` VALUES (1018, 20, 'Coicoyán de las Flores');
INSERT INTO `municipios` VALUES (1019, 20, 'Concepción Buenavista');
INSERT INTO `municipios` VALUES (1020, 20, 'Concepción Pápalo');
INSERT INTO `municipios` VALUES (1021, 20, 'Constancia del Rosario');
INSERT INTO `municipios` VALUES (1022, 20, 'Cosolapa');
INSERT INTO `municipios` VALUES (1023, 20, 'Cosoltepec');
INSERT INTO `municipios` VALUES (1024, 20, 'Cuilapam de Guerrero');
INSERT INTO `municipios` VALUES (1025, 20, 'Cuyamecalco Villa de Zaragoza');
INSERT INTO `municipios` VALUES (1026, 20, 'El Barrio de la Soledad');
INSERT INTO `municipios` VALUES (1027, 20, 'El Espinal');
INSERT INTO `municipios` VALUES (1028, 20, 'Eloxochitlán de Flores Magón');
INSERT INTO `municipios` VALUES (1029, 20, 'Fresnillo de Trujano');
INSERT INTO `municipios` VALUES (1030, 20, 'Guadalupe de Ramírez');
INSERT INTO `municipios` VALUES (1031, 20, 'Guadalupe Etla');
INSERT INTO `municipios` VALUES (1032, 20, 'Guelatao de Juárez');
INSERT INTO `municipios` VALUES (1033, 20, 'Guevea de Humboldt');
INSERT INTO `municipios` VALUES (1034, 20, 'Heróica Ciudad de Ejutla de Crespo');
INSERT INTO `municipios` VALUES (1035, 20, 'Heróica Ciudad de Huajuapan de León');
INSERT INTO `municipios` VALUES (1036, 20, 'Heróica Ciudad de Tlaxiaco');
INSERT INTO `municipios` VALUES (1037, 20, 'Huautepec');
INSERT INTO `municipios` VALUES (1038, 20, 'Huautla de Jiménez');
INSERT INTO `municipios` VALUES (1039, 20, 'Ixpantepec Nieves');
INSERT INTO `municipios` VALUES (1040, 20, 'Ixtlán de Juárez');
INSERT INTO `municipios` VALUES (1041, 20, 'Juchitán de Zaragoza');
INSERT INTO `municipios` VALUES (1042, 20, 'La Compañía');
INSERT INTO `municipios` VALUES (1043, 20, 'La Pe');
INSERT INTO `municipios` VALUES (1044, 20, 'La Reforma');
INSERT INTO `municipios` VALUES (1045, 20, 'La Trinidad Vista Hermosa');
INSERT INTO `municipios` VALUES (1046, 20, 'Loma Bonita');
INSERT INTO `municipios` VALUES (1047, 20, 'Magdalena Apasco');
INSERT INTO `municipios` VALUES (1048, 20, 'Magdalena Jaltepec');
INSERT INTO `municipios` VALUES (1049, 20, 'Magdalena Mixtepec');
INSERT INTO `municipios` VALUES (1050, 20, 'Magdalena Ocotlán');
INSERT INTO `municipios` VALUES (1051, 20, 'Magdalena Peñasco');
INSERT INTO `municipios` VALUES (1052, 20, 'Magdalena Teitipac');
INSERT INTO `municipios` VALUES (1053, 20, 'Magdalena Tequisistlán');
INSERT INTO `municipios` VALUES (1054, 20, 'Magdalena Tlacotepec');
INSERT INTO `municipios` VALUES (1055, 20, 'Magdalena Yodocono de Porfirio Díaz');
INSERT INTO `municipios` VALUES (1056, 20, 'Magdalena Zahuatlán');
INSERT INTO `municipios` VALUES (1057, 20, 'Mariscala de Juárez');
INSERT INTO `municipios` VALUES (1058, 20, 'Mártires de Tacubaya');
INSERT INTO `municipios` VALUES (1059, 20, 'Matías Romero Avendaño');
INSERT INTO `municipios` VALUES (1060, 20, 'Mazatlán Villa de Flores');
INSERT INTO `municipios` VALUES (1061, 20, 'Mesones Hidalgo');
INSERT INTO `municipios` VALUES (1062, 20, 'Miahuatlán de Porfirio Díaz');
INSERT INTO `municipios` VALUES (1063, 20, 'Mixistlán de la Reforma');
INSERT INTO `municipios` VALUES (1064, 20, 'Monjas');
INSERT INTO `municipios` VALUES (1065, 20, 'Natividad');
INSERT INTO `municipios` VALUES (1066, 20, 'Nazareno Etla');
INSERT INTO `municipios` VALUES (1067, 20, 'Nejapa de Madero');
INSERT INTO `municipios` VALUES (1068, 20, 'Nuevo Zoquiapam');
INSERT INTO `municipios` VALUES (1069, 20, 'Oaxaca de Juárez');
INSERT INTO `municipios` VALUES (1070, 20, 'Ocotlán de Morelos');
INSERT INTO `municipios` VALUES (1071, 20, 'Pinotepa de Don Luis');
INSERT INTO `municipios` VALUES (1072, 20, 'Pluma Hidalgo');
INSERT INTO `municipios` VALUES (1073, 20, 'Putla Villa de Guerrero');
INSERT INTO `municipios` VALUES (1074, 20, 'Reforma de Pineda');
INSERT INTO `municipios` VALUES (1075, 20, 'Reyes Etla');
INSERT INTO `municipios` VALUES (1076, 20, 'Rojas de Cuauhtémoc');
INSERT INTO `municipios` VALUES (1077, 20, 'Salina Cruz');
INSERT INTO `municipios` VALUES (1078, 20, 'San Agustín Amatengo');
INSERT INTO `municipios` VALUES (1079, 20, 'San Agustín Atenango');
INSERT INTO `municipios` VALUES (1080, 20, 'San Agustín Chayuco');
INSERT INTO `municipios` VALUES (1081, 20, 'San Agustín de las Juntas');
INSERT INTO `municipios` VALUES (1082, 20, 'San Agustín Etla');
INSERT INTO `municipios` VALUES (1083, 20, 'San Agustín Loxicha');
INSERT INTO `municipios` VALUES (1084, 20, 'San Agustín Tlacotepec');
INSERT INTO `municipios` VALUES (1085, 20, 'San Agustín Yatareni');
INSERT INTO `municipios` VALUES (1086, 20, 'San Andrés Cabecera Nueva');
INSERT INTO `municipios` VALUES (1087, 20, 'San Andrés Dinicuiti');
INSERT INTO `municipios` VALUES (1088, 20, 'San Andrés Huaxpaltepec');
INSERT INTO `municipios` VALUES (1089, 20, 'San Andrés Huayapam');
INSERT INTO `municipios` VALUES (1090, 20, 'San Andrés Ixtlahuaca');
INSERT INTO `municipios` VALUES (1091, 20, 'San Andrés Lagunas');
INSERT INTO `municipios` VALUES (1092, 20, 'San Andrés Nuxiño');
INSERT INTO `municipios` VALUES (1093, 20, 'San Andrés Paxtlán');
INSERT INTO `municipios` VALUES (1094, 20, 'San Andrés Sinaxtla');
INSERT INTO `municipios` VALUES (1095, 20, 'San Andrés Solaga');
INSERT INTO `municipios` VALUES (1096, 20, 'San Andrés Teotilalpam');
INSERT INTO `municipios` VALUES (1097, 20, 'San Andrés Tepetlapa');
INSERT INTO `municipios` VALUES (1098, 20, 'San Andrés Yaa');
INSERT INTO `municipios` VALUES (1099, 20, 'San Andrés Zabache');
INSERT INTO `municipios` VALUES (1100, 20, 'San Andrés Zautla');
INSERT INTO `municipios` VALUES (1101, 20, 'San Antonino Castillo Velasco');
INSERT INTO `municipios` VALUES (1102, 20, 'San Antonino el Alto');
INSERT INTO `municipios` VALUES (1103, 20, 'San Antonino Monteverde');
INSERT INTO `municipios` VALUES (1104, 20, 'San Antonio Acutla');
INSERT INTO `municipios` VALUES (1105, 20, 'San Antonio de la Cal');
INSERT INTO `municipios` VALUES (1106, 20, 'San Antonio Huitepec');
INSERT INTO `municipios` VALUES (1107, 20, 'San Antonio Nanahuatipam');
INSERT INTO `municipios` VALUES (1108, 20, 'San Antonio Sinicahua');
INSERT INTO `municipios` VALUES (1109, 20, 'San Antonio Tepetlapa');
INSERT INTO `municipios` VALUES (1110, 20, 'San Baltazar Chichicápam');
INSERT INTO `municipios` VALUES (1111, 20, 'San Baltazar Loxicha');
INSERT INTO `municipios` VALUES (1112, 20, 'San Baltazar Yatzachi el Bajo');
INSERT INTO `municipios` VALUES (1113, 20, 'San Bartolo Coyotepec');
INSERT INTO `municipios` VALUES (1114, 20, 'San Bartolo Soyaltepec');
INSERT INTO `municipios` VALUES (1115, 20, 'San Bartolo Yautepec');
INSERT INTO `municipios` VALUES (1116, 20, 'San Bartolomé Ayautla');
INSERT INTO `municipios` VALUES (1117, 20, 'San Bartolomé Loxicha');
INSERT INTO `municipios` VALUES (1118, 20, 'San Bartolomé Quialana');
INSERT INTO `municipios` VALUES (1119, 20, 'San Bartolomé Yucuañe');
INSERT INTO `municipios` VALUES (1120, 20, 'San Bartolomé Zoogocho');
INSERT INTO `municipios` VALUES (1121, 20, 'San Bernardo Mixtepec');
INSERT INTO `municipios` VALUES (1122, 20, 'San Blas Atempa');
INSERT INTO `municipios` VALUES (1123, 20, 'San Carlos Yautepec');
INSERT INTO `municipios` VALUES (1124, 20, 'San Cristóbal Amatlán');
INSERT INTO `municipios` VALUES (1125, 20, 'San Cristóbal Amoltepec');
INSERT INTO `municipios` VALUES (1126, 20, 'San Cristóbal Lachirioag');
INSERT INTO `municipios` VALUES (1127, 20, 'San Cristóbal Suchixtlahuaca');
INSERT INTO `municipios` VALUES (1128, 20, 'San Dionisio del Mar');
INSERT INTO `municipios` VALUES (1129, 20, 'San Dionisio Ocotepec');
INSERT INTO `municipios` VALUES (1130, 20, 'San Dionisio Ocotlán');
INSERT INTO `municipios` VALUES (1131, 20, 'San Esteban Atatlahuca');
INSERT INTO `municipios` VALUES (1132, 20, 'San Felipe Jalapa de Díaz');
INSERT INTO `municipios` VALUES (1133, 20, 'San Felipe Tejalapam');
INSERT INTO `municipios` VALUES (1134, 20, 'San Felipe Usila');
INSERT INTO `municipios` VALUES (1135, 20, 'San Francisco Cahuacuá');
INSERT INTO `municipios` VALUES (1136, 20, 'San Francisco Cajonos');
INSERT INTO `municipios` VALUES (1137, 20, 'San Francisco Chapulapa');
INSERT INTO `municipios` VALUES (1138, 20, 'San Francisco Chindua');
INSERT INTO `municipios` VALUES (1139, 20, 'San Francisco del Mar');
INSERT INTO `municipios` VALUES (1140, 20, 'San Francisco Huehuetlán');
INSERT INTO `municipios` VALUES (1141, 20, 'San Francisco Ixhuatán');
INSERT INTO `municipios` VALUES (1142, 20, 'San Francisco Jaltepetongo');
INSERT INTO `municipios` VALUES (1143, 20, 'San Francisco Lachigoló');
INSERT INTO `municipios` VALUES (1144, 20, 'San Francisco Logueche');
INSERT INTO `municipios` VALUES (1145, 20, 'San Francisco Nuxaño');
INSERT INTO `municipios` VALUES (1146, 20, 'San Francisco Ozolotepec');
INSERT INTO `municipios` VALUES (1147, 20, 'San Francisco Sola');
INSERT INTO `municipios` VALUES (1148, 20, 'San Francisco Telixtlahuaca');
INSERT INTO `municipios` VALUES (1149, 20, 'San Francisco Teopan');
INSERT INTO `municipios` VALUES (1150, 20, 'San Francisco Tlapancingo');
INSERT INTO `municipios` VALUES (1151, 20, 'San Gabriel Mixtepec');
INSERT INTO `municipios` VALUES (1152, 20, 'San Ildefonso Amatlán');
INSERT INTO `municipios` VALUES (1153, 20, 'San Ildefonso Sola');
INSERT INTO `municipios` VALUES (1154, 20, 'San Ildefonso Villa Alta');
INSERT INTO `municipios` VALUES (1155, 20, 'San Jacinto Amilpas');
INSERT INTO `municipios` VALUES (1156, 20, 'San Jacinto Tlacotepec');
INSERT INTO `municipios` VALUES (1157, 20, 'San Jerónimo Coatlán');
INSERT INTO `municipios` VALUES (1158, 20, 'San Jerónimo Silacayoapilla');
INSERT INTO `municipios` VALUES (1159, 20, 'San Jerónimo Sosola');
INSERT INTO `municipios` VALUES (1160, 20, 'San Jerónimo Taviche');
INSERT INTO `municipios` VALUES (1161, 20, 'San Jerónimo Tecoatl');
INSERT INTO `municipios` VALUES (1162, 20, 'San Jerónimo Tlacochahuaya');
INSERT INTO `municipios` VALUES (1163, 20, 'San Jorge Nuchita');
INSERT INTO `municipios` VALUES (1164, 20, 'San José Ayuquila');
INSERT INTO `municipios` VALUES (1165, 20, 'San José Chiltepec');
INSERT INTO `municipios` VALUES (1166, 20, 'San José del Peñasco');
INSERT INTO `municipios` VALUES (1167, 20, 'San José del Progreso');
INSERT INTO `municipios` VALUES (1168, 20, 'San José Estancia Grande');
INSERT INTO `municipios` VALUES (1169, 20, 'San José Independencia');
INSERT INTO `municipios` VALUES (1170, 20, 'San José Lachiguiri');
INSERT INTO `municipios` VALUES (1171, 20, 'San José Tenango');
INSERT INTO `municipios` VALUES (1172, 20, 'San Juan Achiutla');
INSERT INTO `municipios` VALUES (1173, 20, 'San Juan Atepec');
INSERT INTO `municipios` VALUES (1174, 20, 'San Juan Bautista Atatlahuca');
INSERT INTO `municipios` VALUES (1175, 20, 'San Juan Bautista Coixtlahuaca');
INSERT INTO `municipios` VALUES (1176, 20, 'San Juan Bautista Cuicatlán');
INSERT INTO `municipios` VALUES (1177, 20, 'San Juan Bautista Guelache');
INSERT INTO `municipios` VALUES (1178, 20, 'San Juan Bautista Jayacatlán');
INSERT INTO `municipios` VALUES (1179, 20, 'San Juan Bautista Lo de Soto');
INSERT INTO `municipios` VALUES (1180, 20, 'San Juan Bautista Suchitepec');
INSERT INTO `municipios` VALUES (1181, 20, 'San Juan Bautista Tlacoatzintepec');
INSERT INTO `municipios` VALUES (1182, 20, 'San Juan Bautista Tlachichilco');
INSERT INTO `municipios` VALUES (1183, 20, 'San Juan Bautista Tuxtepec');
INSERT INTO `municipios` VALUES (1184, 20, 'San Juan Bautista Valle Nacional');
INSERT INTO `municipios` VALUES (1185, 20, 'San Juan Cacahuatepec');
INSERT INTO `municipios` VALUES (1186, 20, 'San Juan Chicomezúchil');
INSERT INTO `municipios` VALUES (1187, 20, 'San Juan Chilateca');
INSERT INTO `municipios` VALUES (1188, 20, 'San Juan Cieneguilla');
INSERT INTO `municipios` VALUES (1189, 20, 'San Juan Coatzóspam');
INSERT INTO `municipios` VALUES (1190, 20, 'San Juan Colorado');
INSERT INTO `municipios` VALUES (1191, 20, 'San Juan Comaltepec');
INSERT INTO `municipios` VALUES (1192, 20, 'San Juan Cotzocón');
INSERT INTO `municipios` VALUES (1193, 20, 'San Juan del Estado');
INSERT INTO `municipios` VALUES (1194, 20, 'San Juan de los Cués');
INSERT INTO `municipios` VALUES (1195, 20, 'San Juan del Río');
INSERT INTO `municipios` VALUES (1196, 20, 'San Juan Diuxi');
INSERT INTO `municipios` VALUES (1197, 20, 'San Juan Evangelista Analco');
INSERT INTO `municipios` VALUES (1198, 20, 'San Juan Guelavia');
INSERT INTO `municipios` VALUES (1199, 20, 'San Juan Guichicovi');
INSERT INTO `municipios` VALUES (1200, 20, 'San Juan Ihualtepec');
INSERT INTO `municipios` VALUES (1201, 20, 'San Juan Juquila Mixes');
INSERT INTO `municipios` VALUES (1202, 20, 'San Juan Juquila Vijanos');
INSERT INTO `municipios` VALUES (1203, 20, 'San Juan Lachao');
INSERT INTO `municipios` VALUES (1204, 20, 'San Juan Lachigalla');
INSERT INTO `municipios` VALUES (1205, 20, 'San Juan Lajarcia');
INSERT INTO `municipios` VALUES (1206, 20, 'San Juan Lalana');
INSERT INTO `municipios` VALUES (1207, 20, 'San Juan Mazatlán');
INSERT INTO `municipios` VALUES (1208, 20, 'San Juan Mixtepec, distrito 08');
INSERT INTO `municipios` VALUES (1209, 20, 'San Juan Mixtepec, distrito 26');
INSERT INTO `municipios` VALUES (1210, 20, 'San Juan Ñumi');
INSERT INTO `municipios` VALUES (1211, 20, 'San Juan Ozolotepec');
INSERT INTO `municipios` VALUES (1212, 20, 'San Juan Petlapa');
INSERT INTO `municipios` VALUES (1213, 20, 'San Juan Quiahije');
INSERT INTO `municipios` VALUES (1214, 20, 'San Juan Quiotepec');
INSERT INTO `municipios` VALUES (1215, 20, 'San Juan Sayultepec');
INSERT INTO `municipios` VALUES (1216, 20, 'San Juan Tabaá');
INSERT INTO `municipios` VALUES (1217, 20, 'San Juan Tamazola');
INSERT INTO `municipios` VALUES (1218, 20, 'San Juan Teita');
INSERT INTO `municipios` VALUES (1219, 20, 'San Juan Teitipac');
INSERT INTO `municipios` VALUES (1220, 20, 'San Juan Tepeuxila');
INSERT INTO `municipios` VALUES (1221, 20, 'San Juan Teposcolula');
INSERT INTO `municipios` VALUES (1222, 20, 'San Juan Yaeé');
INSERT INTO `municipios` VALUES (1223, 20, 'San Juan Yatzona');
INSERT INTO `municipios` VALUES (1224, 20, 'San Juan Yucuita');
INSERT INTO `municipios` VALUES (1225, 20, 'San Lorenzo');
INSERT INTO `municipios` VALUES (1226, 20, 'San Lorenzo Albarradas');
INSERT INTO `municipios` VALUES (1227, 20, 'San Lorenzo Cacaotepec');
INSERT INTO `municipios` VALUES (1228, 20, 'San Lorenzo Cuaunecuiltitla');
INSERT INTO `municipios` VALUES (1229, 20, 'San Lorenzo Texmelucan');
INSERT INTO `municipios` VALUES (1230, 20, 'San Lorenzo Victoria');
INSERT INTO `municipios` VALUES (1231, 20, 'San Lucas Camotlán');
INSERT INTO `municipios` VALUES (1232, 20, 'San Lucas Ojitlán');
INSERT INTO `municipios` VALUES (1233, 20, 'San Lucas Quiaviní');
INSERT INTO `municipios` VALUES (1234, 20, 'San Lucas Zoquiápam');
INSERT INTO `municipios` VALUES (1235, 20, 'San Luis Amatlán');
INSERT INTO `municipios` VALUES (1236, 20, 'San Marcial Ozolotepec');
INSERT INTO `municipios` VALUES (1237, 20, 'San Marcos Arteaga');
INSERT INTO `municipios` VALUES (1238, 20, 'San Martín de los Cansecos');
INSERT INTO `municipios` VALUES (1239, 20, 'San Martín Huamelúlpam');
INSERT INTO `municipios` VALUES (1240, 20, 'San Martín Itunyoso');
INSERT INTO `municipios` VALUES (1241, 20, 'San Martín Lachilá');
INSERT INTO `municipios` VALUES (1242, 20, 'San Martín Peras');
INSERT INTO `municipios` VALUES (1243, 20, 'San Martín Tilcajete');
INSERT INTO `municipios` VALUES (1244, 20, 'San Martín Toxpalan');
INSERT INTO `municipios` VALUES (1245, 20, 'San Martín Zacatepec');
INSERT INTO `municipios` VALUES (1246, 20, 'San Mateo Cajonos');
INSERT INTO `municipios` VALUES (1247, 20, 'San Mateo del Mar');
INSERT INTO `municipios` VALUES (1248, 20, 'San Mateo Etlatongo');
INSERT INTO `municipios` VALUES (1249, 20, 'San Mateo Nejápam');
INSERT INTO `municipios` VALUES (1250, 20, 'San Mateo Peñasco');
INSERT INTO `municipios` VALUES (1251, 20, 'San Mateo Piñas');
INSERT INTO `municipios` VALUES (1252, 20, 'San Mateo Río Hondo');
INSERT INTO `municipios` VALUES (1253, 20, 'San Mateo Sindihui');
INSERT INTO `municipios` VALUES (1254, 20, 'San Mateo Tlapiltepec');
INSERT INTO `municipios` VALUES (1255, 20, 'San Mateo Yoloxochitlán');
INSERT INTO `municipios` VALUES (1256, 20, 'San Melchor Betaza');
INSERT INTO `municipios` VALUES (1257, 20, 'San Miguel Achiutla');
INSERT INTO `municipios` VALUES (1258, 20, 'San Miguel Ahuehuetitlán');
INSERT INTO `municipios` VALUES (1259, 20, 'San Miguel Aloápam');
INSERT INTO `municipios` VALUES (1260, 20, 'San Miguel Amatitlán');
INSERT INTO `municipios` VALUES (1261, 20, 'San Miguel Amatlán');
INSERT INTO `municipios` VALUES (1262, 20, 'San Miguel Coatlán');
INSERT INTO `municipios` VALUES (1263, 20, 'San Miguel Chicahua');
INSERT INTO `municipios` VALUES (1264, 20, 'San Miguel Chimalapa');
INSERT INTO `municipios` VALUES (1265, 20, 'San Miguel del Puerto');
INSERT INTO `municipios` VALUES (1266, 20, 'San Miguel del Río');
INSERT INTO `municipios` VALUES (1267, 20, 'San Miguel Ejutla');
INSERT INTO `municipios` VALUES (1268, 20, 'San Miguel el Grande');
INSERT INTO `municipios` VALUES (1269, 20, 'San Miguel Huautla');
INSERT INTO `municipios` VALUES (1270, 20, 'San Miguel Mixtepec');
INSERT INTO `municipios` VALUES (1271, 20, 'San Miguel Panixtlahuaca');
INSERT INTO `municipios` VALUES (1272, 20, 'San Miguel Peras');
INSERT INTO `municipios` VALUES (1273, 20, 'San Miguel Piedras');
INSERT INTO `municipios` VALUES (1274, 20, 'San Miguel Quetzaltepec');
INSERT INTO `municipios` VALUES (1275, 20, 'San Miguel Santa Flor');
INSERT INTO `municipios` VALUES (1276, 20, 'San Miguel Soyaltepec');
INSERT INTO `municipios` VALUES (1277, 20, 'San Miguel Suchixtepec');
INSERT INTO `municipios` VALUES (1278, 20, 'San Miguel Tecomatlán');
INSERT INTO `municipios` VALUES (1279, 20, 'San Miguel Tenango');
INSERT INTO `municipios` VALUES (1280, 20, 'San Miguel Tequixtepec');
INSERT INTO `municipios` VALUES (1281, 20, 'San Miguel Tilquiápam');
INSERT INTO `municipios` VALUES (1282, 20, 'San Miguel Tlacamama');
INSERT INTO `municipios` VALUES (1283, 20, 'San Miguel Tlacotepec');
INSERT INTO `municipios` VALUES (1284, 20, 'San Miguel Tulancingo');
INSERT INTO `municipios` VALUES (1285, 20, 'San Miguel Yotao');
INSERT INTO `municipios` VALUES (1286, 20, 'San Nicolás');
INSERT INTO `municipios` VALUES (1287, 20, 'San Nicolás Hidalgo');
INSERT INTO `municipios` VALUES (1288, 20, 'San Pablo Coatlán');
INSERT INTO `municipios` VALUES (1289, 20, 'San Pablo Cuatro Venados');
INSERT INTO `municipios` VALUES (1290, 20, 'San Pablo Etla');
INSERT INTO `municipios` VALUES (1291, 20, 'San Pablo Huitzo');
INSERT INTO `municipios` VALUES (1292, 20, 'San Pablo Huixtepec');
INSERT INTO `municipios` VALUES (1293, 20, 'San Pablo Macuiltianguis');
INSERT INTO `municipios` VALUES (1294, 20, 'San Pablo Tijaltepec');
INSERT INTO `municipios` VALUES (1295, 20, 'San Pablo Villa de Mitla');
INSERT INTO `municipios` VALUES (1296, 20, 'San Pablo Yaganiza');
INSERT INTO `municipios` VALUES (1297, 20, 'San Pedro Amuzgos');
INSERT INTO `municipios` VALUES (1298, 20, 'San Pedro Apóstol');
INSERT INTO `municipios` VALUES (1299, 20, 'San Pedro Atoyac');
INSERT INTO `municipios` VALUES (1300, 20, 'San Pedro Cajonos');
INSERT INTO `municipios` VALUES (1301, 20, 'San Pedro Comitancillo');
INSERT INTO `municipios` VALUES (1302, 20, 'San Pedro Cocaltepec Cántaros');
INSERT INTO `municipios` VALUES (1303, 20, 'San Pedro el Alto');
INSERT INTO `municipios` VALUES (1304, 20, 'San Pedro Huamelula');
INSERT INTO `municipios` VALUES (1305, 20, 'San Pedro Huilotepec');
INSERT INTO `municipios` VALUES (1306, 20, 'San Pedro Ixcatlán');
INSERT INTO `municipios` VALUES (1307, 20, 'San Pedro Ixtlahuaca');
INSERT INTO `municipios` VALUES (1308, 20, 'San Pedro Jaltepetongo');
INSERT INTO `municipios` VALUES (1309, 20, 'San Pedro Jicayán');
INSERT INTO `municipios` VALUES (1310, 20, 'San Pedro Jocotipac');
INSERT INTO `municipios` VALUES (1311, 20, 'San Pedro Juchatengo');
INSERT INTO `municipios` VALUES (1312, 20, 'San Pedro Mártir');
INSERT INTO `municipios` VALUES (1313, 20, 'San Pedro Mártir Quiechapa');
INSERT INTO `municipios` VALUES (1314, 20, 'San Pedro Mártir Yucuxaco');
INSERT INTO `municipios` VALUES (1315, 20, 'San Pedro Mixtepec, distrito 22');
INSERT INTO `municipios` VALUES (1316, 20, 'San Pedro Mixtepec, distrito 26');
INSERT INTO `municipios` VALUES (1317, 20, 'San Pedro Molinos');
INSERT INTO `municipios` VALUES (1318, 20, 'San Pedro Nopala');
INSERT INTO `municipios` VALUES (1319, 20, 'San Pedro Ocopetatillo');
INSERT INTO `municipios` VALUES (1320, 20, 'San Pedro Ocotepec');
INSERT INTO `municipios` VALUES (1321, 20, 'San Pedro Pochutla');
INSERT INTO `municipios` VALUES (1322, 20, 'San Pedro Quiatoni');
INSERT INTO `municipios` VALUES (1323, 20, 'San Pedro Sochiápam');
INSERT INTO `municipios` VALUES (1324, 20, 'San Pedro Tapanatepec');
INSERT INTO `municipios` VALUES (1325, 20, 'San Pedro Taviche');
INSERT INTO `municipios` VALUES (1326, 20, 'San Pedro Teozacoalco');
INSERT INTO `municipios` VALUES (1327, 20, 'San Pedro Teutila');
INSERT INTO `municipios` VALUES (1328, 20, 'San Pedro Tidaá');
INSERT INTO `municipios` VALUES (1329, 20, 'San Pedro Topiltepec');
INSERT INTO `municipios` VALUES (1330, 20, 'San Pedro Totolápam');
INSERT INTO `municipios` VALUES (1331, 20, 'San Pedro y San Pablo Ayutla');
INSERT INTO `municipios` VALUES (1332, 20, 'San Pedro y San Pablo Teposcolula');
INSERT INTO `municipios` VALUES (1333, 20, 'San Pedro y San Pablo Tequixtepec');
INSERT INTO `municipios` VALUES (1334, 20, 'San Pedro Yaneri');
INSERT INTO `municipios` VALUES (1335, 20, 'San Pedro Yólox');
INSERT INTO `municipios` VALUES (1336, 20, 'San Pedro Yucunama');
INSERT INTO `municipios` VALUES (1337, 20, 'San Raymundo Jalpan');
INSERT INTO `municipios` VALUES (1338, 20, 'San Sebastián Abasolo');
INSERT INTO `municipios` VALUES (1339, 20, 'San Sebastián Coatlán');
INSERT INTO `municipios` VALUES (1340, 20, 'San Sebastián Ixcapa');
INSERT INTO `municipios` VALUES (1341, 20, 'San Sebastián Nicananduta');
INSERT INTO `municipios` VALUES (1342, 20, 'San Sebastián Río Hondo');
INSERT INTO `municipios` VALUES (1343, 20, 'San Sebastián Tecomaxtlahuaca');
INSERT INTO `municipios` VALUES (1344, 20, 'San Sebastián Teitipac');
INSERT INTO `municipios` VALUES (1345, 20, 'San Sebastián Tutla');
INSERT INTO `municipios` VALUES (1346, 20, 'San Simón Almolongas');
INSERT INTO `municipios` VALUES (1347, 20, 'San Simón Zahuatlán  ');
INSERT INTO `municipios` VALUES (1348, 20, 'Santa Ana');
INSERT INTO `municipios` VALUES (1349, 20, 'Santa Ana Ateixtlahuaca');
INSERT INTO `municipios` VALUES (1350, 20, 'Santa Ana Cuauhtémoc');
INSERT INTO `municipios` VALUES (1351, 20, 'Santa Ana del Valle');
INSERT INTO `municipios` VALUES (1352, 20, 'Santa Ana Tavela');
INSERT INTO `municipios` VALUES (1353, 20, 'Santa Ana Tlapacoyan');
INSERT INTO `municipios` VALUES (1354, 20, 'Santa Ana Yareni');
INSERT INTO `municipios` VALUES (1355, 20, 'Santa Ana Zegache');
INSERT INTO `municipios` VALUES (1356, 20, 'Santa Catalina Quieri');
INSERT INTO `municipios` VALUES (1357, 20, 'Santa Catarina Cuixtla');
INSERT INTO `municipios` VALUES (1358, 20, 'Santa Catarina Ixtepeji');
INSERT INTO `municipios` VALUES (1359, 20, 'Santa Catarina Juquila');
INSERT INTO `municipios` VALUES (1360, 20, 'Santa Catarina Lachatao');
INSERT INTO `municipios` VALUES (1361, 20, 'Santa Catarina Loxicha');
INSERT INTO `municipios` VALUES (1362, 20, 'Santa Catarina Mechoacán');
INSERT INTO `municipios` VALUES (1363, 20, 'Santa Catarina Minas');
INSERT INTO `municipios` VALUES (1364, 20, 'Santa Catarina Quiané');
INSERT INTO `municipios` VALUES (1365, 20, 'Santa Catarina Quioquitani');
INSERT INTO `municipios` VALUES (1366, 20, 'Santa CatarinaTayata');
INSERT INTO `municipios` VALUES (1367, 20, 'Santa Catarina Ticuá');
INSERT INTO `municipios` VALUES (1368, 20, 'Santa Catarina Yosonotú');
INSERT INTO `municipios` VALUES (1369, 20, 'Santa Catarina Zapoquila');
INSERT INTO `municipios` VALUES (1370, 20, 'Santa Cruz Acatepec');
INSERT INTO `municipios` VALUES (1371, 20, 'Santa Cruz Amilpas');
INSERT INTO `municipios` VALUES (1372, 20, 'Santa Cruz de Bravo');
INSERT INTO `municipios` VALUES (1373, 20, 'Santa Cruz Itundujia');
INSERT INTO `municipios` VALUES (1374, 20, 'Santa Cruz Mixtepec');
INSERT INTO `municipios` VALUES (1375, 20, 'Santa Cruz Nundaco');
INSERT INTO `municipios` VALUES (1376, 20, 'Santa Cruz Papalutla');
INSERT INTO `municipios` VALUES (1377, 20, 'Santa Cruz Tacache de Mina');
INSERT INTO `municipios` VALUES (1378, 20, 'Santa Cruz Tacahua');
INSERT INTO `municipios` VALUES (1379, 20, 'Santa Cruz Tayata');
INSERT INTO `municipios` VALUES (1380, 20, 'Santa Cruz Xitla');
INSERT INTO `municipios` VALUES (1381, 20, 'Santa Cruz Xoxocotlán');
INSERT INTO `municipios` VALUES (1382, 20, 'Santa Cruz Zenzontepec');
INSERT INTO `municipios` VALUES (1383, 20, 'Santa Gertrudis');
INSERT INTO `municipios` VALUES (1384, 20, 'Santa Inés del Monte');
INSERT INTO `municipios` VALUES (1385, 20, 'Santa Inés de Zaragoza');
INSERT INTO `municipios` VALUES (1386, 20, 'Santa Inés Yatzeche');
INSERT INTO `municipios` VALUES (1387, 20, 'Santa Lucía del Camino');
INSERT INTO `municipios` VALUES (1388, 20, 'Santa Lucía Miahuatlán');
INSERT INTO `municipios` VALUES (1389, 20, 'Santa Lucía Monteverde');
INSERT INTO `municipios` VALUES (1390, 20, 'Santa Lucía Ocotlán');
INSERT INTO `municipios` VALUES (1391, 20, 'Santa Magdalena Jicotlán');
INSERT INTO `municipios` VALUES (1392, 20, 'Santa María Alotepec');
INSERT INTO `municipios` VALUES (1393, 20, 'Santa María Apazco');
INSERT INTO `municipios` VALUES (1394, 20, 'Santa María Atzompa');
INSERT INTO `municipios` VALUES (1395, 20, 'Santa María Camotlán');
INSERT INTO `municipios` VALUES (1396, 20, 'Santa María Chachoápam');
INSERT INTO `municipios` VALUES (1397, 20, 'Santa María Chilchotla');
INSERT INTO `municipios` VALUES (1398, 20, 'Santa María Chimalapa');
INSERT INTO `municipios` VALUES (1399, 20, 'Santa María Colotepec');
INSERT INTO `municipios` VALUES (1400, 20, 'Santa María Cortijo');
INSERT INTO `municipios` VALUES (1401, 20, 'Santa María Coyotepec');
INSERT INTO `municipios` VALUES (1402, 20, 'Santa María del Rosario');
INSERT INTO `municipios` VALUES (1403, 20, 'Santa María del Tule');
INSERT INTO `municipios` VALUES (1404, 20, 'Santa María Ecatepec');
INSERT INTO `municipios` VALUES (1405, 20, 'Santa María Guelacé');
INSERT INTO `municipios` VALUES (1406, 20, 'Santa María Guienagati');
INSERT INTO `municipios` VALUES (1407, 20, 'Santa María Huatulco');
INSERT INTO `municipios` VALUES (1408, 20, 'Santa María Huazolotitlán');
INSERT INTO `municipios` VALUES (1409, 20, 'Santa María Ipalapa');
INSERT INTO `municipios` VALUES (1410, 20, 'Santa María Ixcatlán');
INSERT INTO `municipios` VALUES (1411, 20, 'Santa María Jacatepec');
INSERT INTO `municipios` VALUES (1412, 20, 'Santa María Jalapa del Marqués');
INSERT INTO `municipios` VALUES (1413, 20, 'Santa María Jaltianguis');
INSERT INTO `municipios` VALUES (1414, 20, 'Santa María la Asunción');
INSERT INTO `municipios` VALUES (1415, 20, 'Santa María Lachixío');
INSERT INTO `municipios` VALUES (1416, 20, 'Santa María Mixtequilla');
INSERT INTO `municipios` VALUES (1417, 20, 'Santa María Nativitas');
INSERT INTO `municipios` VALUES (1418, 20, 'Santa María Nduayaco');
INSERT INTO `municipios` VALUES (1419, 20, 'Santa María Ozolotepec');
INSERT INTO `municipios` VALUES (1420, 20, 'Santa María Pápalo');
INSERT INTO `municipios` VALUES (1421, 20, 'Santa María Peñoles');
INSERT INTO `municipios` VALUES (1422, 20, 'Santa María Petapa');
INSERT INTO `municipios` VALUES (1423, 20, 'Santa María Quiegolani');
INSERT INTO `municipios` VALUES (1424, 20, 'Santa María Sola');
INSERT INTO `municipios` VALUES (1425, 20, 'Santa María Tataltepec');
INSERT INTO `municipios` VALUES (1426, 20, 'Santa María Tecomavaca');
INSERT INTO `municipios` VALUES (1427, 20, 'Santa María Temaxcalapa');
INSERT INTO `municipios` VALUES (1428, 20, 'Santa María Temaxcaltepec');
INSERT INTO `municipios` VALUES (1429, 20, 'Santa María Teopoxco');
INSERT INTO `municipios` VALUES (1430, 20, 'Santa María Tepantlali');
INSERT INTO `municipios` VALUES (1431, 20, 'Santa María Texcatitlán');
INSERT INTO `municipios` VALUES (1432, 20, 'Santa María Tlahuitoltepec');
INSERT INTO `municipios` VALUES (1433, 20, 'Santa María Tlalixtac');
INSERT INTO `municipios` VALUES (1434, 20, 'Santa María Tonameca');
INSERT INTO `municipios` VALUES (1435, 20, 'Santa María Totolapilla');
INSERT INTO `municipios` VALUES (1436, 20, 'Santa María Xadani');
INSERT INTO `municipios` VALUES (1437, 20, 'Santa María Yalina');
INSERT INTO `municipios` VALUES (1438, 20, 'Santa María Yavesía');
INSERT INTO `municipios` VALUES (1439, 20, 'Santa María Yolotepec');
INSERT INTO `municipios` VALUES (1440, 20, 'Santa María Yosoyua');
INSERT INTO `municipios` VALUES (1441, 20, 'Santa María Yucuhiti');
INSERT INTO `municipios` VALUES (1442, 20, 'Santa María Zacatepec');
INSERT INTO `municipios` VALUES (1443, 20, 'Santa María Zaniza');
INSERT INTO `municipios` VALUES (1444, 20, 'Santa María Zoquitlán');
INSERT INTO `municipios` VALUES (1445, 20, 'Santiago Amoltepec');
INSERT INTO `municipios` VALUES (1446, 20, 'Santiago Apoala');
INSERT INTO `municipios` VALUES (1447, 20, 'Santiago Apóstol');
INSERT INTO `municipios` VALUES (1448, 20, 'Santiago Astata');
INSERT INTO `municipios` VALUES (1449, 20, 'Santiago Atitlán');
INSERT INTO `municipios` VALUES (1450, 20, 'Santiago Ayuquililla');
INSERT INTO `municipios` VALUES (1451, 20, 'Santiago Cacaloxtepec');
INSERT INTO `municipios` VALUES (1452, 20, 'Santiago Camotlán');
INSERT INTO `municipios` VALUES (1453, 20, 'Santiago Chazumba');
INSERT INTO `municipios` VALUES (1454, 20, 'Santiago Choápam');
INSERT INTO `municipios` VALUES (1455, 20, 'Santiago Comaltepec');
INSERT INTO `municipios` VALUES (1456, 20, 'Santiago del Río');
INSERT INTO `municipios` VALUES (1457, 20, 'Santiago Huajolotitlán');
INSERT INTO `municipios` VALUES (1458, 20, 'Santiago Huauclilla');
INSERT INTO `municipios` VALUES (1459, 20, 'Santiago Ihuitlán Plumas');
INSERT INTO `municipios` VALUES (1460, 20, 'Santiago Ixcuintepec');
INSERT INTO `municipios` VALUES (1461, 20, 'Santiago Ixtayutla');
INSERT INTO `municipios` VALUES (1462, 20, 'Santiago Jamiltepec');
INSERT INTO `municipios` VALUES (1463, 20, 'Santiago Jocotepec');
INSERT INTO `municipios` VALUES (1464, 20, 'Santiago Juxtlahuaca');
INSERT INTO `municipios` VALUES (1465, 20, 'Santiago Lachiguiri');
INSERT INTO `municipios` VALUES (1466, 20, 'Santiago Lalopa');
INSERT INTO `municipios` VALUES (1467, 20, 'Santiago Laollaga');
INSERT INTO `municipios` VALUES (1468, 20, 'Santiago Laxopa');
INSERT INTO `municipios` VALUES (1469, 20, 'Santiago Llano Grande');
INSERT INTO `municipios` VALUES (1470, 20, 'Santiago Matatlán');
INSERT INTO `municipios` VALUES (1471, 20, 'Santiago Miltepec');
INSERT INTO `municipios` VALUES (1472, 20, 'Santiago Minas');
INSERT INTO `municipios` VALUES (1473, 20, 'Santiago Nacaltepec');
INSERT INTO `municipios` VALUES (1474, 20, 'Santiago Nejapilla');
INSERT INTO `municipios` VALUES (1475, 20, 'Santiago Niltepec');
INSERT INTO `municipios` VALUES (1476, 20, 'Santiago Nundiche');
INSERT INTO `municipios` VALUES (1477, 20, 'Santiago Nuyoó');
INSERT INTO `municipios` VALUES (1478, 20, 'Santiago Pinotepa Nacional');
INSERT INTO `municipios` VALUES (1479, 20, 'Santiago Suchilquitongo');
INSERT INTO `municipios` VALUES (1480, 20, 'Santiago Tamazola');
INSERT INTO `municipios` VALUES (1481, 20, 'Santiago Tapextla');
INSERT INTO `municipios` VALUES (1482, 20, 'Santiago Tenango');
INSERT INTO `municipios` VALUES (1483, 20, 'Santiago Tepetlapa');
INSERT INTO `municipios` VALUES (1484, 20, 'Santiago Tetepec');
INSERT INTO `municipios` VALUES (1485, 20, 'Santiago Texcalcingo');
INSERT INTO `municipios` VALUES (1486, 20, 'Santiago Textitlán');
INSERT INTO `municipios` VALUES (1487, 20, 'Santiago Tilantongo');
INSERT INTO `municipios` VALUES (1488, 20, 'Santiago Tillo');
INSERT INTO `municipios` VALUES (1489, 20, 'Santiago Tlazoyaltepec');
INSERT INTO `municipios` VALUES (1490, 20, 'Santiago Xanica');
INSERT INTO `municipios` VALUES (1491, 20, 'Santiago Xiacuí');
INSERT INTO `municipios` VALUES (1492, 20, 'Santiago Yaitepec');
INSERT INTO `municipios` VALUES (1493, 20, 'Santiago Yaveo');
INSERT INTO `municipios` VALUES (1494, 20, 'Santiago Yolomécatl');
INSERT INTO `municipios` VALUES (1495, 20, 'Santiago Yosondúa');
INSERT INTO `municipios` VALUES (1496, 20, 'Santiago Yucuyachi');
INSERT INTO `municipios` VALUES (1497, 20, 'Santiago Zacatepec');
INSERT INTO `municipios` VALUES (1498, 20, 'Santiago Zoochila');
INSERT INTO `municipios` VALUES (1499, 20, 'Santo Domingo Albarradas');
INSERT INTO `municipios` VALUES (1500, 20, 'Santo Domingo Armenta');
INSERT INTO `municipios` VALUES (1501, 20, 'Santo Domingo Chihuitán');
INSERT INTO `municipios` VALUES (1502, 20, 'Santo Domingo de Morelos');
INSERT INTO `municipios` VALUES (1503, 20, 'Santo Domingo Ingenio');
INSERT INTO `municipios` VALUES (1504, 20, 'Santo Domingo Ixcatlán');
INSERT INTO `municipios` VALUES (1505, 20, 'Santo Domingo Nuxaá');
INSERT INTO `municipios` VALUES (1506, 20, 'Santo Domingo Ozolotepec');
INSERT INTO `municipios` VALUES (1507, 20, 'Santo Domingo Petapa');
INSERT INTO `municipios` VALUES (1508, 20, 'Santo Domingo Roayaga');
INSERT INTO `municipios` VALUES (1509, 20, 'Santo Domingo Tehuantepec');
INSERT INTO `municipios` VALUES (1510, 20, 'Santo Domingo Teojomulco');
INSERT INTO `municipios` VALUES (1511, 20, 'Santo Domingo Tepuxtepec');
INSERT INTO `municipios` VALUES (1512, 20, 'Santo Domingo Tlatayapam');
INSERT INTO `municipios` VALUES (1513, 20, 'Santo Domingo Tomaltepec');
INSERT INTO `municipios` VALUES (1514, 20, 'Santo Domingo Tonalá');
INSERT INTO `municipios` VALUES (1515, 20, 'Santo Domingo Tonaltepec');
INSERT INTO `municipios` VALUES (1516, 20, 'Santo Domingo Xagacía');
INSERT INTO `municipios` VALUES (1517, 20, 'Santo Domingo Yanhuitlán');
INSERT INTO `municipios` VALUES (1518, 20, 'Santo Domingo Yodohino');
INSERT INTO `municipios` VALUES (1519, 20, 'Santo Domingo Zanatepec');
INSERT INTO `municipios` VALUES (1520, 20, 'Santo Tomás Jalieza');
INSERT INTO `municipios` VALUES (1521, 20, 'Santo Tomás Mazaltepec');
INSERT INTO `municipios` VALUES (1522, 20, 'Santo Tomás Ocotepec');
INSERT INTO `municipios` VALUES (1523, 20, 'Santo Tomás Tamazulapan');
INSERT INTO `municipios` VALUES (1524, 20, 'Santos Reyes Nopala');
INSERT INTO `municipios` VALUES (1525, 20, 'Santos Reyes Pápalo');
INSERT INTO `municipios` VALUES (1526, 20, 'Santos Reyes Tepejillo');
INSERT INTO `municipios` VALUES (1527, 20, 'Santos Reyes Yucuná');
INSERT INTO `municipios` VALUES (1528, 20, 'San Vicente Coatlán');
INSERT INTO `municipios` VALUES (1529, 20, 'San Vicente Lachixío');
INSERT INTO `municipios` VALUES (1530, 20, 'San Vicente Nuñú');
INSERT INTO `municipios` VALUES (1531, 20, 'Silacayoápam');
INSERT INTO `municipios` VALUES (1532, 20, 'Sitio de Xitlapehua');
INSERT INTO `municipios` VALUES (1533, 20, 'Soledad Etla');
INSERT INTO `municipios` VALUES (1534, 20, 'Tamazulápam del Espíritu Santo');
INSERT INTO `municipios` VALUES (1535, 20, 'Tanetze de Zaragoza');
INSERT INTO `municipios` VALUES (1536, 20, 'Taniche');
INSERT INTO `municipios` VALUES (1537, 20, 'Tataltepec de Valdés');
INSERT INTO `municipios` VALUES (1538, 20, 'Teococuilco de Marcos Pérez');
INSERT INTO `municipios` VALUES (1539, 20, 'Teotitlán de Flores Magón');
INSERT INTO `municipios` VALUES (1540, 20, 'Teotitlán del Valle');
INSERT INTO `municipios` VALUES (1541, 20, 'Teotongo');
INSERT INTO `municipios` VALUES (1542, 20, 'Tepelmeme Villa de Morelos');
INSERT INTO `municipios` VALUES (1543, 20, 'Tezoatlán de Segura y Luna');
INSERT INTO `municipios` VALUES (1544, 20, 'Tlacolula de Matamoros');
INSERT INTO `municipios` VALUES (1545, 20, 'Tlacotepec Plumas');
INSERT INTO `municipios` VALUES (1546, 20, 'Tlalixtac de Cabrera');
INSERT INTO `municipios` VALUES (1547, 20, 'Totontepec Villa de Morelos');
INSERT INTO `municipios` VALUES (1548, 20, 'Trinidad Zaáchila');
INSERT INTO `municipios` VALUES (1549, 20, 'Unión Hidalgo');
INSERT INTO `municipios` VALUES (1550, 20, 'Valerio Trujano');
INSERT INTO `municipios` VALUES (1551, 20, 'Villa de Chilapa de Díaz');
INSERT INTO `municipios` VALUES (1552, 20, 'Villa de Etla');
INSERT INTO `municipios` VALUES (1553, 20, 'Villa de Tamazulápam del Progreso');
INSERT INTO `municipios` VALUES (1554, 20, 'Villa de Tututepec de Melchor Ocampo');
INSERT INTO `municipios` VALUES (1555, 20, 'Villa de Zaáchila');
INSERT INTO `municipios` VALUES (1556, 20, 'Villa Díaz Ordaz');
INSERT INTO `municipios` VALUES (1557, 20, 'Villa Hidalgo');
INSERT INTO `municipios` VALUES (1558, 20, 'Villa Sola de Vega');
INSERT INTO `municipios` VALUES (1559, 20, 'Villa Talea de Castro');
INSERT INTO `municipios` VALUES (1560, 20, 'Villa Tejupam de la Unión');
INSERT INTO `municipios` VALUES (1561, 20, 'Yaxe');
INSERT INTO `municipios` VALUES (1562, 20, 'Yogana');
INSERT INTO `municipios` VALUES (1563, 20, 'Yutanduchi de Guerrero');
INSERT INTO `municipios` VALUES (1564, 20, 'Zapotitlán del Río');
INSERT INTO `municipios` VALUES (1565, 20, 'Zapotitlán Lagunas');
INSERT INTO `municipios` VALUES (1566, 20, 'Zapotitlán Palmas');
INSERT INTO `municipios` VALUES (1567, 20, 'Zimatlán de Álvarez');
INSERT INTO `municipios` VALUES (1568, 21, 'Acajete');
INSERT INTO `municipios` VALUES (1569, 21, 'Acateno');
INSERT INTO `municipios` VALUES (1570, 21, 'Acatlán');
INSERT INTO `municipios` VALUES (1571, 21, 'Acatzingo');
INSERT INTO `municipios` VALUES (1572, 21, 'Acteopan');
INSERT INTO `municipios` VALUES (1573, 21, 'Ahuacatlán');
INSERT INTO `municipios` VALUES (1574, 21, 'Ahuatlán');
INSERT INTO `municipios` VALUES (1575, 21, 'Ahuazotepec');
INSERT INTO `municipios` VALUES (1576, 21, 'Ahuehuetitla');
INSERT INTO `municipios` VALUES (1577, 21, 'Ajalpan');
INSERT INTO `municipios` VALUES (1578, 21, 'Albino Zertuche');
INSERT INTO `municipios` VALUES (1579, 21, 'Aljojuca');
INSERT INTO `municipios` VALUES (1580, 21, 'Altepexi');
INSERT INTO `municipios` VALUES (1581, 21, 'Amixtlán');
INSERT INTO `municipios` VALUES (1582, 21, 'Amozoc');
INSERT INTO `municipios` VALUES (1583, 21, 'Aquixtla');
INSERT INTO `municipios` VALUES (1584, 21, 'Atempan');
INSERT INTO `municipios` VALUES (1585, 21, 'Atexcal');
INSERT INTO `municipios` VALUES (1586, 21, 'Atlequizayan');
INSERT INTO `municipios` VALUES (1587, 21, 'Atlixco');
INSERT INTO `municipios` VALUES (1588, 21, 'Atoyatempan');
INSERT INTO `municipios` VALUES (1589, 21, 'Atzala');
INSERT INTO `municipios` VALUES (1590, 21, 'Atzitzihuacán');
INSERT INTO `municipios` VALUES (1591, 21, 'Atzitzintla');
INSERT INTO `municipios` VALUES (1592, 21, 'Axutla');
INSERT INTO `municipios` VALUES (1593, 21, 'Ayotoxco de Guerrero');
INSERT INTO `municipios` VALUES (1594, 21, 'Calpan');
INSERT INTO `municipios` VALUES (1595, 21, 'Caltepec');
INSERT INTO `municipios` VALUES (1596, 21, 'Camocuautla');
INSERT INTO `municipios` VALUES (1597, 21, 'Cañada Morelos');
INSERT INTO `municipios` VALUES (1598, 21, 'Caxhuacan');
INSERT INTO `municipios` VALUES (1599, 21, 'Chalchicomula de Sesma');
INSERT INTO `municipios` VALUES (1600, 21, 'Chapulco');
INSERT INTO `municipios` VALUES (1601, 21, 'Chiautla');
INSERT INTO `municipios` VALUES (1602, 21, 'Chiautzingo');
INSERT INTO `municipios` VALUES (1603, 21, 'Chichiquila');
INSERT INTO `municipios` VALUES (1604, 21, 'Chiconcuautla');
INSERT INTO `municipios` VALUES (1605, 21, 'Chietla');
INSERT INTO `municipios` VALUES (1606, 21, 'Chigmecatitlán');
INSERT INTO `municipios` VALUES (1607, 21, 'Chignahuapan');
INSERT INTO `municipios` VALUES (1608, 21, 'Chignautla');
INSERT INTO `municipios` VALUES (1609, 21, 'Chila');
INSERT INTO `municipios` VALUES (1610, 21, 'Chila de la Sal');
INSERT INTO `municipios` VALUES (1611, 21, 'Chilchotla');
INSERT INTO `municipios` VALUES (1612, 21, 'Chinantla');
INSERT INTO `municipios` VALUES (1613, 21, 'Coatepec');
INSERT INTO `municipios` VALUES (1614, 21, 'Coatzingo');
INSERT INTO `municipios` VALUES (1615, 21, 'Cohetzala');
INSERT INTO `municipios` VALUES (1616, 21, 'Cohuecan');
INSERT INTO `municipios` VALUES (1617, 21, 'Coronango');
INSERT INTO `municipios` VALUES (1618, 21, 'Coxcatlán');
INSERT INTO `municipios` VALUES (1619, 21, 'Coyomeapan');
INSERT INTO `municipios` VALUES (1620, 21, 'Coyotepec');
INSERT INTO `municipios` VALUES (1621, 21, 'Cuapiaxtla de Madero');
INSERT INTO `municipios` VALUES (1622, 21, 'Cuautempan');
INSERT INTO `municipios` VALUES (1623, 21, 'Cuautinchán');
INSERT INTO `municipios` VALUES (1624, 21, 'Cuautlancingo');
INSERT INTO `municipios` VALUES (1625, 21, 'Cuayuca de Andradre');
INSERT INTO `municipios` VALUES (1626, 21, 'Cuetzalan del Progreso');
INSERT INTO `municipios` VALUES (1627, 21, 'Cuyoaco');
INSERT INTO `municipios` VALUES (1628, 21, 'Domingo Arenas');
INSERT INTO `municipios` VALUES (1629, 21, 'Eloxochitlán');
INSERT INTO `municipios` VALUES (1630, 21, 'Epatlán');
INSERT INTO `municipios` VALUES (1631, 21, 'Esperanza');
INSERT INTO `municipios` VALUES (1632, 21, 'Francisco Z. Mena');
INSERT INTO `municipios` VALUES (1633, 21, 'General Felipe Ángeles');
INSERT INTO `municipios` VALUES (1634, 21, 'Guadalupe');
INSERT INTO `municipios` VALUES (1635, 21, 'Guadalupe Victoria');
INSERT INTO `municipios` VALUES (1636, 21, 'Hermenegildo Galeana');
INSERT INTO `municipios` VALUES (1637, 21, 'Honey');
INSERT INTO `municipios` VALUES (1638, 21, 'Huaquechula');
INSERT INTO `municipios` VALUES (1639, 21, 'Huatlatlauca');
INSERT INTO `municipios` VALUES (1640, 21, 'Huauchinango');
INSERT INTO `municipios` VALUES (1641, 21, 'Huehuetla');
INSERT INTO `municipios` VALUES (1642, 21, 'Huehuetlán el Chico');
INSERT INTO `municipios` VALUES (1643, 21, 'Huehuetlán el Grande');
INSERT INTO `municipios` VALUES (1644, 21, 'Huejotzingo');
INSERT INTO `municipios` VALUES (1645, 21, 'Hueyapan');
INSERT INTO `municipios` VALUES (1646, 21, 'Hueytamalco');
INSERT INTO `municipios` VALUES (1647, 21, 'Hueytlalpan');
INSERT INTO `municipios` VALUES (1648, 21, 'Huitzilán de Serdán');
INSERT INTO `municipios` VALUES (1649, 21, 'Huitziltepec');
INSERT INTO `municipios` VALUES (1650, 21, 'Ixcamilpa de Guerrero');
INSERT INTO `municipios` VALUES (1651, 21, 'Ixcaquixtla');
INSERT INTO `municipios` VALUES (1652, 21, 'Ixtacamaxtitlán');
INSERT INTO `municipios` VALUES (1653, 21, 'Ixtepec');
INSERT INTO `municipios` VALUES (1654, 21, 'Izúcar de Matamoros');
INSERT INTO `municipios` VALUES (1655, 21, 'Jalpan');
INSERT INTO `municipios` VALUES (1656, 21, 'Jolalpan');
INSERT INTO `municipios` VALUES (1657, 21, 'Jonotla');
INSERT INTO `municipios` VALUES (1658, 21, 'Jopala');
INSERT INTO `municipios` VALUES (1659, 21, 'Juan C. Bonilla');
INSERT INTO `municipios` VALUES (1660, 21, 'Juan Galindo');
INSERT INTO `municipios` VALUES (1661, 21, 'Juan N. Méndez');
INSERT INTO `municipios` VALUES (1662, 21, 'Lafragua');
INSERT INTO `municipios` VALUES (1663, 21, 'Libres');
INSERT INTO `municipios` VALUES (1664, 21, 'Los Reyes de Juárez');
INSERT INTO `municipios` VALUES (1665, 21, 'Magdalena Tlatlauquitepec');
INSERT INTO `municipios` VALUES (1666, 21, 'Mazapiltepec de Juárez');
INSERT INTO `municipios` VALUES (1667, 21, 'Mixtla');
INSERT INTO `municipios` VALUES (1668, 21, 'Molcaxac');
INSERT INTO `municipios` VALUES (1669, 21, 'Naupan');
INSERT INTO `municipios` VALUES (1670, 21, 'Nauzontla');
INSERT INTO `municipios` VALUES (1671, 21, 'Nealtican');
INSERT INTO `municipios` VALUES (1672, 21, 'Nicolás Bravo');
INSERT INTO `municipios` VALUES (1673, 21, 'Nopalucan');
INSERT INTO `municipios` VALUES (1674, 21, 'Ocotepec');
INSERT INTO `municipios` VALUES (1675, 21, 'Ocoyucan');
INSERT INTO `municipios` VALUES (1676, 21, 'Olintla');
INSERT INTO `municipios` VALUES (1677, 21, 'Oriental');
INSERT INTO `municipios` VALUES (1678, 21, 'Pahuatlán');
INSERT INTO `municipios` VALUES (1679, 21, 'Palmar de Bravo');
INSERT INTO `municipios` VALUES (1680, 21, 'Pantepec');
INSERT INTO `municipios` VALUES (1681, 21, 'Petlalcingo');
INSERT INTO `municipios` VALUES (1682, 21, 'Piaxtla');
INSERT INTO `municipios` VALUES (1683, 21, 'Puebla de Zaragoza');
INSERT INTO `municipios` VALUES (1684, 21, 'Quecholac');
INSERT INTO `municipios` VALUES (1685, 21, 'Quimixtlán');
INSERT INTO `municipios` VALUES (1686, 21, 'Rafael Lara Grajales');
INSERT INTO `municipios` VALUES (1687, 21, 'San Andrés Cholula');
INSERT INTO `municipios` VALUES (1688, 21, 'San Antonio Cañada');
INSERT INTO `municipios` VALUES (1689, 21, 'San Diego La Meza Tochimiltzingo');
INSERT INTO `municipios` VALUES (1690, 21, 'San Felipe Teotlalcingo');
INSERT INTO `municipios` VALUES (1691, 21, 'San Felipe Tepatlán');
INSERT INTO `municipios` VALUES (1692, 21, 'San Gabriel Chilac');
INSERT INTO `municipios` VALUES (1693, 21, 'San Gregorio Atzompa');
INSERT INTO `municipios` VALUES (1694, 21, 'San Jerónimo Tecuanipan');
INSERT INTO `municipios` VALUES (1695, 21, 'San Jerónimo Xayacatlán');
INSERT INTO `municipios` VALUES (1696, 21, 'San José Chiapa');
INSERT INTO `municipios` VALUES (1697, 21, 'San José Miahuatlán');
INSERT INTO `municipios` VALUES (1698, 21, 'San Juan Atenco');
INSERT INTO `municipios` VALUES (1699, 21, 'San Juan Atzompa');
INSERT INTO `municipios` VALUES (1700, 21, 'San Martín Texmelucan');
INSERT INTO `municipios` VALUES (1701, 21, 'San Martín Totoltepec');
INSERT INTO `municipios` VALUES (1702, 21, 'San Matías Tlalancaleca');
INSERT INTO `municipios` VALUES (1703, 21, 'San Miguel Ixtitlán');
INSERT INTO `municipios` VALUES (1704, 21, 'San Miguel Xoxtla');
INSERT INTO `municipios` VALUES (1705, 21, 'San Nicolás Buenos Aires');
INSERT INTO `municipios` VALUES (1706, 21, 'San Nicolás de los Ranchos');
INSERT INTO `municipios` VALUES (1707, 21, 'San Pablo Anicano');
INSERT INTO `municipios` VALUES (1708, 21, 'San Pedro Cholula');
INSERT INTO `municipios` VALUES (1709, 21, 'San Pedro Yeloixtlahuaca');
INSERT INTO `municipios` VALUES (1710, 21, 'San Salvador el Seco');
INSERT INTO `municipios` VALUES (1711, 21, 'San Salvador el Verde');
INSERT INTO `municipios` VALUES (1712, 21, 'San Salvador Huixcolotla');
INSERT INTO `municipios` VALUES (1713, 21, 'San Sebastián Tlacotepec');
INSERT INTO `municipios` VALUES (1714, 21, 'Santa Catarina Tlaltempan');
INSERT INTO `municipios` VALUES (1715, 21, 'San Inés Ahuatempan');
INSERT INTO `municipios` VALUES (1716, 21, 'Santa Isabel Cholula');
INSERT INTO `municipios` VALUES (1717, 21, 'Santiago Miahuatlán ');
INSERT INTO `municipios` VALUES (1718, 21, 'Santo Tomás Hueyotlipan');
INSERT INTO `municipios` VALUES (1719, 21, 'Soltepec');
INSERT INTO `municipios` VALUES (1720, 21, 'Tecali de Herrera');
INSERT INTO `municipios` VALUES (1721, 21, 'Tecamachalco');
INSERT INTO `municipios` VALUES (1722, 21, 'Tecomatlán');
INSERT INTO `municipios` VALUES (1723, 21, 'Tehuacán');
INSERT INTO `municipios` VALUES (1724, 21, 'Tehuitzingo');
INSERT INTO `municipios` VALUES (1725, 21, 'Tenampulco');
INSERT INTO `municipios` VALUES (1726, 21, 'Teopantlán');
INSERT INTO `municipios` VALUES (1727, 21, 'Teotlalco');
INSERT INTO `municipios` VALUES (1728, 21, 'Tepanco de López');
INSERT INTO `municipios` VALUES (1729, 21, 'Tepango de Rodríguez');
INSERT INTO `municipios` VALUES (1730, 21, 'Tepatlaxco de Hidalgo');
INSERT INTO `municipios` VALUES (1731, 21, 'Tepeaca');
INSERT INTO `municipios` VALUES (1732, 21, 'Tepemaxalco');
INSERT INTO `municipios` VALUES (1733, 21, 'Tepeojuma');
INSERT INTO `municipios` VALUES (1734, 21, 'Tepetzintla');
INSERT INTO `municipios` VALUES (1735, 21, 'Tepexco');
INSERT INTO `municipios` VALUES (1736, 21, 'Tepexi de Rodríguez');
INSERT INTO `municipios` VALUES (1737, 21, 'Tepeyahualco');
INSERT INTO `municipios` VALUES (1738, 21, 'Tepeyahualco de Cuauhtémoc');
INSERT INTO `municipios` VALUES (1739, 21, 'Tetela de Ocampo');
INSERT INTO `municipios` VALUES (1740, 21, 'Teteles de Ávila Castillo');
INSERT INTO `municipios` VALUES (1741, 21, 'Teziutlán');
INSERT INTO `municipios` VALUES (1742, 21, 'Tianguismanalco');
INSERT INTO `municipios` VALUES (1743, 21, 'Tilapa');
INSERT INTO `municipios` VALUES (1744, 21, 'Tlacotepec de Benito Juárez');
INSERT INTO `municipios` VALUES (1745, 21, 'Tlacuilotepec');
INSERT INTO `municipios` VALUES (1746, 21, 'Tlachichuca');
INSERT INTO `municipios` VALUES (1747, 21, 'Tlahuapan');
INSERT INTO `municipios` VALUES (1748, 21, 'Tlaltenango');
INSERT INTO `municipios` VALUES (1749, 21, 'Tlanepantla');
INSERT INTO `municipios` VALUES (1750, 21, 'Tlaola');
INSERT INTO `municipios` VALUES (1751, 21, 'Tlapacoya');
INSERT INTO `municipios` VALUES (1752, 21, 'Tlapanalá');
INSERT INTO `municipios` VALUES (1753, 21, 'Tlatlauquitepec');
INSERT INTO `municipios` VALUES (1754, 21, 'Tlaxco');
INSERT INTO `municipios` VALUES (1755, 21, 'Tochimilco');
INSERT INTO `municipios` VALUES (1756, 21, 'Tochtepec');
INSERT INTO `municipios` VALUES (1757, 21, 'Totoltepec de Guerrero');
INSERT INTO `municipios` VALUES (1758, 21, 'Tulcingo');
INSERT INTO `municipios` VALUES (1759, 21, 'Tuzamapan de Galeana');
INSERT INTO `municipios` VALUES (1760, 21, 'Tzicatlacoyan');
INSERT INTO `municipios` VALUES (1761, 21, 'Venustiano Carranza');
INSERT INTO `municipios` VALUES (1762, 21, 'Vicente Guerrero');
INSERT INTO `municipios` VALUES (1763, 21, 'Xayacatlán de Bravo');
INSERT INTO `municipios` VALUES (1764, 21, 'Xicotepec');
INSERT INTO `municipios` VALUES (1765, 21, 'Xicotlán');
INSERT INTO `municipios` VALUES (1766, 21, 'Xiutetelco');
INSERT INTO `municipios` VALUES (1767, 21, 'Xochiapulco');
INSERT INTO `municipios` VALUES (1768, 21, 'Xochiltepec');
INSERT INTO `municipios` VALUES (1769, 21, 'Xochitlán de Vicente Suárez');
INSERT INTO `municipios` VALUES (1770, 21, 'Xochitlán Todos Santos');
INSERT INTO `municipios` VALUES (1771, 21, 'Yaonahuac');
INSERT INTO `municipios` VALUES (1772, 21, 'Yehualtepec');
INSERT INTO `municipios` VALUES (1773, 21, 'Zacapala');
INSERT INTO `municipios` VALUES (1774, 21, 'Zacapoaxtla');
INSERT INTO `municipios` VALUES (1775, 21, 'Zacatlán');
INSERT INTO `municipios` VALUES (1776, 21, 'Zapotitlán');
INSERT INTO `municipios` VALUES (1777, 21, 'Zapotitlán de Méndez');
INSERT INTO `municipios` VALUES (1778, 21, 'Zaragoza');
INSERT INTO `municipios` VALUES (1779, 21, 'Zautla');
INSERT INTO `municipios` VALUES (1780, 21, 'Zihuateutla');
INSERT INTO `municipios` VALUES (1781, 21, 'Zinacatepec');
INSERT INTO `municipios` VALUES (1782, 21, 'Zongozotla');
INSERT INTO `municipios` VALUES (1783, 21, 'Zoquiapan');
INSERT INTO `municipios` VALUES (1784, 21, 'Zoquitlán');
INSERT INTO `municipios` VALUES (1785, 22, 'Amealco de Bonfil');
INSERT INTO `municipios` VALUES (1786, 22, 'Arroyo Seco');
INSERT INTO `municipios` VALUES (1787, 22, 'Cadereyta de Montes');
INSERT INTO `municipios` VALUES (1788, 22, 'Colón');
INSERT INTO `municipios` VALUES (1789, 22, 'Corregidora');
INSERT INTO `municipios` VALUES (1790, 22, 'El Marqués');
INSERT INTO `municipios` VALUES (1791, 22, 'Ezequiel Montes');
INSERT INTO `municipios` VALUES (1792, 22, 'Huimilpan');
INSERT INTO `municipios` VALUES (1793, 22, 'Jalpan de Serra');
INSERT INTO `municipios` VALUES (1794, 22, 'Landa de Matamoros');
INSERT INTO `municipios` VALUES (1795, 22, 'Pedro Escobedo');
INSERT INTO `municipios` VALUES (1796, 22, 'Peñamiller');
INSERT INTO `municipios` VALUES (1797, 22, 'Pinal de Amoles');
INSERT INTO `municipios` VALUES (1798, 22, 'Querétaro');
INSERT INTO `municipios` VALUES (1799, 22, 'San Joaquín');
INSERT INTO `municipios` VALUES (1800, 22, 'San Juan del Río');
INSERT INTO `municipios` VALUES (1801, 22, 'Tequisquiapan');
INSERT INTO `municipios` VALUES (1802, 22, 'Tolimán');
INSERT INTO `municipios` VALUES (1803, 23, 'Benito Juárez');
INSERT INTO `municipios` VALUES (1804, 23, 'Cozumel');
INSERT INTO `municipios` VALUES (1805, 23, 'Felipe Carrillo Puerto');
INSERT INTO `municipios` VALUES (1806, 23, 'Isla Mujeres');
INSERT INTO `municipios` VALUES (1807, 23, 'José María Morelos');
INSERT INTO `municipios` VALUES (1808, 23, 'Lázaro Cárdenas');
INSERT INTO `municipios` VALUES (1809, 23, 'Othon P. Blanco');
INSERT INTO `municipios` VALUES (1810, 23, 'Solidaridad');
INSERT INTO `municipios` VALUES (1811, 23, 'Tulum');
INSERT INTO `municipios` VALUES (1812, 24, 'Ahualulco');
INSERT INTO `municipios` VALUES (1813, 24, 'Alaquines');
INSERT INTO `municipios` VALUES (1814, 24, 'Aquismón');
INSERT INTO `municipios` VALUES (1815, 24, 'Armadillo de los Infante');
INSERT INTO `municipios` VALUES (1816, 24, 'Axtla de Terrazas');
INSERT INTO `municipios` VALUES (1817, 24, 'Cárdenas');
INSERT INTO `municipios` VALUES (1818, 24, 'Catorce');
INSERT INTO `municipios` VALUES (1819, 24, 'Cedral');
INSERT INTO `municipios` VALUES (1820, 24, 'Cerritos');
INSERT INTO `municipios` VALUES (1821, 24, 'Cerro de San Pedro');
INSERT INTO `municipios` VALUES (1822, 24, 'Charcas');
INSERT INTO `municipios` VALUES (1823, 24, 'Ciudad del Maíz');
INSERT INTO `municipios` VALUES (1824, 24, 'Ciudad Fernández');
INSERT INTO `municipios` VALUES (1825, 24, 'Ciudad Valles');
INSERT INTO `municipios` VALUES (1826, 24, 'Coxcatlán');
INSERT INTO `municipios` VALUES (1827, 24, 'Ebano');
INSERT INTO `municipios` VALUES (1828, 24, 'El Naranjo');
INSERT INTO `municipios` VALUES (1829, 24, 'Guadalcázar');
INSERT INTO `municipios` VALUES (1830, 24, 'Huehuetlán');
INSERT INTO `municipios` VALUES (1831, 24, 'Lagunillas');
INSERT INTO `municipios` VALUES (1832, 24, 'Matehuala');
INSERT INTO `municipios` VALUES (1833, 24, 'Matlapa');
INSERT INTO `municipios` VALUES (1834, 24, 'Mexquitic de Carmona');
INSERT INTO `municipios` VALUES (1835, 24, 'Moctezuma');
INSERT INTO `municipios` VALUES (1836, 24, 'Rayón');
INSERT INTO `municipios` VALUES (1837, 24, 'Rioverde');
INSERT INTO `municipios` VALUES (1838, 24, 'Salinas');
INSERT INTO `municipios` VALUES (1839, 24, 'San Antonio');
INSERT INTO `municipios` VALUES (1840, 24, 'San Ciro de Acosta');
INSERT INTO `municipios` VALUES (1841, 24, 'San Luis Potosí');
INSERT INTO `municipios` VALUES (1842, 24, 'San Martín Chalchicuautla');
INSERT INTO `municipios` VALUES (1843, 24, 'San Nicolás Tolentino');
INSERT INTO `municipios` VALUES (1844, 24, 'Santa Catarina');
INSERT INTO `municipios` VALUES (1845, 24, 'Santa María del Río');
INSERT INTO `municipios` VALUES (1846, 24, 'Santo Domingo');
INSERT INTO `municipios` VALUES (1847, 24, 'San Vicente Tancuayalab');
INSERT INTO `municipios` VALUES (1848, 24, 'Soledad de Graciano Sánchez');
INSERT INTO `municipios` VALUES (1849, 24, 'Tamasopo');
INSERT INTO `municipios` VALUES (1850, 24, 'Tamazunchale');
INSERT INTO `municipios` VALUES (1851, 24, 'Tampacán');
INSERT INTO `municipios` VALUES (1852, 24, 'Tampamolón Corona');
INSERT INTO `municipios` VALUES (1853, 24, 'Tamuín');
INSERT INTO `municipios` VALUES (1854, 24, 'Tancanhuitz de Santos');
INSERT INTO `municipios` VALUES (1855, 24, 'Tanlajás');
INSERT INTO `municipios` VALUES (1856, 24, 'Tanquián de Escobedo');
INSERT INTO `municipios` VALUES (1857, 24, 'Tierra Nueva');
INSERT INTO `municipios` VALUES (1858, 24, 'Vanegas');
INSERT INTO `municipios` VALUES (1859, 24, 'Venado');
INSERT INTO `municipios` VALUES (1860, 24, 'Villa de Arriaga');
INSERT INTO `municipios` VALUES (1861, 24, 'Villa de Arista');
INSERT INTO `municipios` VALUES (1862, 24, 'Villa de Guadalupe');
INSERT INTO `municipios` VALUES (1863, 24, 'Villa de la Paz');
INSERT INTO `municipios` VALUES (1864, 24, 'Villa de Ramos');
INSERT INTO `municipios` VALUES (1865, 24, 'Villa de Reyes');
INSERT INTO `municipios` VALUES (1866, 24, 'Villa Hidalgo');
INSERT INTO `municipios` VALUES (1867, 24, 'Villa Juárez');
INSERT INTO `municipios` VALUES (1868, 24, 'Xilitla');
INSERT INTO `municipios` VALUES (1869, 24, 'Zaragoza');
INSERT INTO `municipios` VALUES (1870, 25, 'Ahome');
INSERT INTO `municipios` VALUES (1871, 25, 'Angostura');
INSERT INTO `municipios` VALUES (1872, 25, 'Badiraguato');
INSERT INTO `municipios` VALUES (1873, 25, 'Choix');
INSERT INTO `municipios` VALUES (1874, 25, 'Concordia');
INSERT INTO `municipios` VALUES (1875, 25, 'Cosalá');
INSERT INTO `municipios` VALUES (1876, 25, 'Culiacán');
INSERT INTO `municipios` VALUES (1877, 25, 'El Fuerte');
INSERT INTO `municipios` VALUES (1878, 25, 'Elota');
INSERT INTO `municipios` VALUES (1879, 25, 'El Rosario');
INSERT INTO `municipios` VALUES (1880, 25, 'Escuinapa');
INSERT INTO `municipios` VALUES (1881, 25, 'Guasave');
INSERT INTO `municipios` VALUES (1882, 25, 'Mazatlán');
INSERT INTO `municipios` VALUES (1883, 25, 'Mocorito');
INSERT INTO `municipios` VALUES (1884, 25, 'Navolato');
INSERT INTO `municipios` VALUES (1885, 25, 'Salvador Alvarado');
INSERT INTO `municipios` VALUES (1886, 25, 'San Ignacio');
INSERT INTO `municipios` VALUES (1887, 25, 'Sinaloa de Leyva');
INSERT INTO `municipios` VALUES (1888, 26, 'Aconchi');
INSERT INTO `municipios` VALUES (1889, 26, 'Agua Prieta');
INSERT INTO `municipios` VALUES (1890, 26, 'Alamos');
INSERT INTO `municipios` VALUES (1891, 26, 'Altar');
INSERT INTO `municipios` VALUES (1892, 26, 'Arivechi');
INSERT INTO `municipios` VALUES (1893, 26, 'Arizpe');
INSERT INTO `municipios` VALUES (1894, 26, 'Atil');
INSERT INTO `municipios` VALUES (1895, 26, 'Bacadéhuachi');
INSERT INTO `municipios` VALUES (1896, 26, 'Bacanora');
INSERT INTO `municipios` VALUES (1897, 26, 'Bacerac');
INSERT INTO `municipios` VALUES (1898, 26, 'Bacoachi');
INSERT INTO `municipios` VALUES (1899, 26, 'Bácum');
INSERT INTO `municipios` VALUES (1900, 26, 'Banámichi');
INSERT INTO `municipios` VALUES (1901, 26, 'Baviácora');
INSERT INTO `municipios` VALUES (1902, 26, 'Bavíspe');
INSERT INTO `municipios` VALUES (1903, 26, 'Benito Juárez');
INSERT INTO `municipios` VALUES (1904, 26, 'Benjamín Hill');
INSERT INTO `municipios` VALUES (1905, 26, 'Caborca');
INSERT INTO `municipios` VALUES (1906, 26, 'Cajeme');
INSERT INTO `municipios` VALUES (1907, 26, 'Cananea');
INSERT INTO `municipios` VALUES (1908, 26, 'Carbó');
INSERT INTO `municipios` VALUES (1909, 26, 'Cocurpe');
INSERT INTO `municipios` VALUES (1910, 26, 'Cumpas');
INSERT INTO `municipios` VALUES (1911, 26, 'Divisaderos');
INSERT INTO `municipios` VALUES (1912, 26, 'Empalme');
INSERT INTO `municipios` VALUES (1913, 26, 'Etchojoa');
INSERT INTO `municipios` VALUES (1914, 26, 'Fronteras');
INSERT INTO `municipios` VALUES (1915, 26, 'General Plutarco Elías Calles');
INSERT INTO `municipios` VALUES (1916, 26, 'Granados');
INSERT INTO `municipios` VALUES (1917, 26, 'Guaymas');
INSERT INTO `municipios` VALUES (1918, 26, 'Hermosillo');
INSERT INTO `municipios` VALUES (1919, 26, 'Huachinera');
INSERT INTO `municipios` VALUES (1920, 26, 'Huásabas');
INSERT INTO `municipios` VALUES (1921, 26, 'Huatabampo');
INSERT INTO `municipios` VALUES (1922, 26, 'Huépac');
INSERT INTO `municipios` VALUES (1923, 26, 'Imuris');
INSERT INTO `municipios` VALUES (1924, 26, 'La Colorada');
INSERT INTO `municipios` VALUES (1925, 26, 'Magdalena');
INSERT INTO `municipios` VALUES (1926, 26, 'Mazatán');
INSERT INTO `municipios` VALUES (1927, 26, 'Moctezuma');
INSERT INTO `municipios` VALUES (1928, 26, 'Naco');
INSERT INTO `municipios` VALUES (1929, 26, 'Nácori Chico');
INSERT INTO `municipios` VALUES (1930, 26, 'Nacozari de García');
INSERT INTO `municipios` VALUES (1931, 26, 'Navojoa');
INSERT INTO `municipios` VALUES (1932, 26, 'Nogales');
INSERT INTO `municipios` VALUES (1933, 26, 'Onavas');
INSERT INTO `municipios` VALUES (1934, 26, 'Opodepe');
INSERT INTO `municipios` VALUES (1935, 26, 'Oquitoa');
INSERT INTO `municipios` VALUES (1936, 26, 'Pitiquito');
INSERT INTO `municipios` VALUES (1937, 26, 'Puerto Peñasco');
INSERT INTO `municipios` VALUES (1938, 26, 'Quiriego');
INSERT INTO `municipios` VALUES (1939, 26, 'Rayón');
INSERT INTO `municipios` VALUES (1940, 26, 'Rosario');
INSERT INTO `municipios` VALUES (1941, 26, 'Sahuaripa');
INSERT INTO `municipios` VALUES (1942, 26, 'San Felipe de Jesús');
INSERT INTO `municipios` VALUES (1943, 26, 'San Ignacio Río Muerto');
INSERT INTO `municipios` VALUES (1944, 26, 'San Javier');
INSERT INTO `municipios` VALUES (1945, 26, 'San Luis Río Colorado');
INSERT INTO `municipios` VALUES (1946, 26, 'San Miguel de Horcasitas');
INSERT INTO `municipios` VALUES (1947, 26, 'San Pedro de la Cueva');
INSERT INTO `municipios` VALUES (1948, 26, 'Santa Ana');
INSERT INTO `municipios` VALUES (1949, 26, 'Santa Cruz');
INSERT INTO `municipios` VALUES (1950, 26, 'Sáric');
INSERT INTO `municipios` VALUES (1951, 26, 'Soyopa');
INSERT INTO `municipios` VALUES (1952, 26, 'Suaqui Grande');
INSERT INTO `municipios` VALUES (1953, 26, 'Tepache');
INSERT INTO `municipios` VALUES (1954, 26, 'Trincheras');
INSERT INTO `municipios` VALUES (1955, 26, 'Tubutama');
INSERT INTO `municipios` VALUES (1956, 26, 'Ures');
INSERT INTO `municipios` VALUES (1957, 26, 'Villa Hidalgo');
INSERT INTO `municipios` VALUES (1958, 26, 'Villa Pesqueira');
INSERT INTO `municipios` VALUES (1959, 26, 'Yécora');
INSERT INTO `municipios` VALUES (1960, 27, 'Balancán');
INSERT INTO `municipios` VALUES (1961, 27, 'Cárdenas');
INSERT INTO `municipios` VALUES (1962, 27, 'Centla');
INSERT INTO `municipios` VALUES (1963, 27, 'Centro');
INSERT INTO `municipios` VALUES (1964, 27, 'Comalcalco');
INSERT INTO `municipios` VALUES (1965, 27, 'Cunduacán');
INSERT INTO `municipios` VALUES (1966, 27, 'Emiliano Zapata');
INSERT INTO `municipios` VALUES (1967, 27, 'Huimanguillo');
INSERT INTO `municipios` VALUES (1968, 27, 'Jalapa');
INSERT INTO `municipios` VALUES (1969, 27, 'Jalpa de Méndez');
INSERT INTO `municipios` VALUES (1970, 27, 'Jonuta');
INSERT INTO `municipios` VALUES (1971, 27, 'Macuspana');
INSERT INTO `municipios` VALUES (1972, 27, 'Nacajuca');
INSERT INTO `municipios` VALUES (1973, 27, 'Paraíso');
INSERT INTO `municipios` VALUES (1974, 27, 'Tacotalpa');
INSERT INTO `municipios` VALUES (1975, 27, 'Teapa');
INSERT INTO `municipios` VALUES (1976, 27, 'Tenosique');
INSERT INTO `municipios` VALUES (1977, 28, 'Abasolo');
INSERT INTO `municipios` VALUES (1978, 28, 'Aldama');
INSERT INTO `municipios` VALUES (1979, 28, 'Altamira');
INSERT INTO `municipios` VALUES (1980, 28, 'Antiguo Morelos');
INSERT INTO `municipios` VALUES (1981, 28, 'Burgos');
INSERT INTO `municipios` VALUES (1982, 28, 'Bustamante');
INSERT INTO `municipios` VALUES (1983, 28, 'Camargo');
INSERT INTO `municipios` VALUES (1984, 28, 'Casas');
INSERT INTO `municipios` VALUES (1985, 28, 'Ciudad Madero');
INSERT INTO `municipios` VALUES (1986, 28, 'Cruillas');
INSERT INTO `municipios` VALUES (1987, 28, 'Gómez Farías');
INSERT INTO `municipios` VALUES (1988, 28, 'González');
INSERT INTO `municipios` VALUES (1989, 28, 'Güemez');
INSERT INTO `municipios` VALUES (1990, 28, 'Guerrero');
INSERT INTO `municipios` VALUES (1991, 28, 'Gustavo Díaz Ordaz');
INSERT INTO `municipios` VALUES (1992, 28, 'Hidalgo');
INSERT INTO `municipios` VALUES (1993, 28, 'Jaumave');
INSERT INTO `municipios` VALUES (1994, 28, 'Jiménez');
INSERT INTO `municipios` VALUES (1995, 28, 'Llera');
INSERT INTO `municipios` VALUES (1996, 28, 'Mainero');
INSERT INTO `municipios` VALUES (1997, 28, 'Mante');
INSERT INTO `municipios` VALUES (1998, 28, 'Matamoros');
INSERT INTO `municipios` VALUES (1999, 28, 'Méndez');
INSERT INTO `municipios` VALUES (2000, 28, 'Mier');
INSERT INTO `municipios` VALUES (2001, 28, 'Miguel Alemán');
INSERT INTO `municipios` VALUES (2002, 28, 'Miquihuana');
INSERT INTO `municipios` VALUES (2003, 28, 'Nuevo Laredo');
INSERT INTO `municipios` VALUES (2004, 28, 'Nuevo Morelos');
INSERT INTO `municipios` VALUES (2005, 28, 'Ocampo');
INSERT INTO `municipios` VALUES (2006, 28, 'Padilla');
INSERT INTO `municipios` VALUES (2007, 28, 'Palmillas');
INSERT INTO `municipios` VALUES (2008, 28, 'Reynosa');
INSERT INTO `municipios` VALUES (2009, 28, 'Río Bravo');
INSERT INTO `municipios` VALUES (2010, 28, 'San Carlos');
INSERT INTO `municipios` VALUES (2011, 28, 'San Fernando');
INSERT INTO `municipios` VALUES (2012, 28, 'San Nicolás');
INSERT INTO `municipios` VALUES (2013, 28, 'Soto La Marina');
INSERT INTO `municipios` VALUES (2014, 28, 'Tampico');
INSERT INTO `municipios` VALUES (2015, 28, 'Tula');
INSERT INTO `municipios` VALUES (2016, 28, 'Valle Hermoso');
INSERT INTO `municipios` VALUES (2017, 28, 'Victoria');
INSERT INTO `municipios` VALUES (2018, 28, 'Villagrán');
INSERT INTO `municipios` VALUES (2019, 28, 'Xicotencatl');
INSERT INTO `municipios` VALUES (2020, 29, 'Acuamanala de Miguel Hidalgo');
INSERT INTO `municipios` VALUES (2021, 29, 'Altzayanca');
INSERT INTO `municipios` VALUES (2022, 29, 'Amaxac de Guerrero');
INSERT INTO `municipios` VALUES (2023, 29, 'Apetatitlán de Antonio Carvajal');
INSERT INTO `municipios` VALUES (2024, 29, 'Atlangatepec');
INSERT INTO `municipios` VALUES (2025, 29, 'Apizaco');
INSERT INTO `municipios` VALUES (2026, 29, 'Benito Juárez');
INSERT INTO `municipios` VALUES (2027, 29, 'Calpulalpan');
INSERT INTO `municipios` VALUES (2028, 29, 'Chiautempan');
INSERT INTO `municipios` VALUES (2029, 29, 'Contla de Juan Cuamatzi');
INSERT INTO `municipios` VALUES (2030, 29, 'Cuapiaxtla');
INSERT INTO `municipios` VALUES (2031, 29, 'Cuaxomulco');
INSERT INTO `municipios` VALUES (2032, 29, 'El Carmen Tequexquitla');
INSERT INTO `municipios` VALUES (2033, 29, 'Emiliano Zapata');
INSERT INTO `municipios` VALUES (2034, 29, 'Españita');
INSERT INTO `municipios` VALUES (2035, 29, 'Huamantla');
INSERT INTO `municipios` VALUES (2036, 29, 'Hueyotlipan');
INSERT INTO `municipios` VALUES (2037, 29, 'Ixtacuixtla de Mariano Matamoros');
INSERT INTO `municipios` VALUES (2038, 29, 'Ixtenco');
INSERT INTO `municipios` VALUES (2039, 29, 'La Magdalena Tlaltelulco');
INSERT INTO `municipios` VALUES (2040, 29, 'Lázaro Cárdenas');
INSERT INTO `municipios` VALUES (2041, 29, 'Mazatecochco de José María Morelos');
INSERT INTO `municipios` VALUES (2042, 29, 'Muñoz de Domingo Arenas');
INSERT INTO `municipios` VALUES (2043, 29, 'Nanacamilpa de Mariano Arista');
INSERT INTO `municipios` VALUES (2044, 29, 'Nativitas');
INSERT INTO `municipios` VALUES (2045, 29, 'Panotla');
INSERT INTO `municipios` VALUES (2046, 29, 'Papalotla de Xicohténcatl');
INSERT INTO `municipios` VALUES (2047, 29, 'Sanctorum de Lázaro Cárdenas');
INSERT INTO `municipios` VALUES (2048, 29, 'San Damián Texoloc');
INSERT INTO `municipios` VALUES (2049, 29, 'San Francisco Tetlanohcan');
INSERT INTO `municipios` VALUES (2050, 29, 'San Jerónimo Zacualpan');
INSERT INTO `municipios` VALUES (2051, 29, 'San José Teacalco');
INSERT INTO `municipios` VALUES (2052, 29, 'San Juan Huactzinco');
INSERT INTO `municipios` VALUES (2053, 29, 'San Lorenzo Axocomanitla');
INSERT INTO `municipios` VALUES (2054, 29, 'San Lucas Tecopilco');
INSERT INTO `municipios` VALUES (2055, 29, 'San Pablo del Monte');
INSERT INTO `municipios` VALUES (2056, 29, 'Santa Ana Nopalucan');
INSERT INTO `municipios` VALUES (2057, 29, 'Santa Apolonia Teacalco');
INSERT INTO `municipios` VALUES (2058, 29, 'Santa Catarina Ayometla');
INSERT INTO `municipios` VALUES (2059, 29, 'Santa Cruz Quilehtla');
INSERT INTO `municipios` VALUES (2060, 29, 'Santa Cruz Tlaxcala');
INSERT INTO `municipios` VALUES (2061, 29, 'Santa Isabel Xiloxoxtla');
INSERT INTO `municipios` VALUES (2062, 29, 'Tenancingo');
INSERT INTO `municipios` VALUES (2063, 29, 'Teolocholco');
INSERT INTO `municipios` VALUES (2064, 29, 'Tepetitla de Lardizábal');
INSERT INTO `municipios` VALUES (2065, 29, 'Tepeyanco');
INSERT INTO `municipios` VALUES (2066, 29, 'Terrenate');
INSERT INTO `municipios` VALUES (2067, 29, 'Tetla de la Solidaridad');
INSERT INTO `municipios` VALUES (2068, 29, 'Tetlatlahuca');
INSERT INTO `municipios` VALUES (2069, 29, 'Tlaxcala');
INSERT INTO `municipios` VALUES (2070, 29, 'Tlaxco');
INSERT INTO `municipios` VALUES (2071, 29, 'Tocatlán');
INSERT INTO `municipios` VALUES (2072, 29, 'Totolac');
INSERT INTO `municipios` VALUES (2073, 29, 'Tzompantepec');
INSERT INTO `municipios` VALUES (2074, 29, 'Xaloztoc');
INSERT INTO `municipios` VALUES (2075, 29, 'Xaltocan');
INSERT INTO `municipios` VALUES (2076, 29, 'Xicohtzinco');
INSERT INTO `municipios` VALUES (2077, 29, 'Yauhquemecan');
INSERT INTO `municipios` VALUES (2078, 29, 'Zacatelco');
INSERT INTO `municipios` VALUES (2079, 29, 'Zitlaltepec de Trinidad Sánchez Santos');
INSERT INTO `municipios` VALUES (2080, 30, 'Acajete');
INSERT INTO `municipios` VALUES (2081, 30, 'Acatlán');
INSERT INTO `municipios` VALUES (2082, 30, 'Acayucan');
INSERT INTO `municipios` VALUES (2083, 30, 'Actopan');
INSERT INTO `municipios` VALUES (2084, 30, 'Acula');
INSERT INTO `municipios` VALUES (2085, 30, 'Acultzingo');
INSERT INTO `municipios` VALUES (2086, 30, 'Agua Dulce');
INSERT INTO `municipios` VALUES (2087, 30, 'Álamo Temapache');
INSERT INTO `municipios` VALUES (2088, 30, 'Alpatláhuac');
INSERT INTO `municipios` VALUES (2089, 30, 'Alto Lucero de Gutiérrez Barrios');
INSERT INTO `municipios` VALUES (2090, 30, 'Altotonga');
INSERT INTO `municipios` VALUES (2091, 30, 'Alvarado');
INSERT INTO `municipios` VALUES (2092, 30, 'Amatitlán');
INSERT INTO `municipios` VALUES (2093, 30, 'Amatlán de los Reyes');
INSERT INTO `municipios` VALUES (2094, 30, 'Ángel R. Cabada');
INSERT INTO `municipios` VALUES (2095, 30, 'Apazapan');
INSERT INTO `municipios` VALUES (2096, 30, 'Aquila');
INSERT INTO `municipios` VALUES (2097, 30, 'Astacinga');
INSERT INTO `municipios` VALUES (2098, 30, 'Atlahuilco');
INSERT INTO `municipios` VALUES (2099, 30, 'Atoyac');
INSERT INTO `municipios` VALUES (2100, 30, 'Atzacan');
INSERT INTO `municipios` VALUES (2101, 30, 'Atzalan');
INSERT INTO `municipios` VALUES (2102, 30, 'Ayahualulco');
INSERT INTO `municipios` VALUES (2103, 30, 'Banderilla');
INSERT INTO `municipios` VALUES (2104, 30, 'Benito Juárez');
INSERT INTO `municipios` VALUES (2105, 30, 'Boca del Río');
INSERT INTO `municipios` VALUES (2106, 30, 'Calcahualco');
INSERT INTO `municipios` VALUES (2107, 30, 'Camarón de Tejeda');
INSERT INTO `municipios` VALUES (2108, 30, 'Camerino Z. Mendoza');
INSERT INTO `municipios` VALUES (2109, 30, 'Carlos A. Carrillo');
INSERT INTO `municipios` VALUES (2110, 30, 'Carrillo Puerto');
INSERT INTO `municipios` VALUES (2111, 30, 'Castillo de Teayo');
INSERT INTO `municipios` VALUES (2112, 30, 'Catemaco');
INSERT INTO `municipios` VALUES (2113, 30, 'Cazones de Herrera');
INSERT INTO `municipios` VALUES (2114, 30, 'Cerro Azul');
INSERT INTO `municipios` VALUES (2115, 30, 'Chacaltianguis');
INSERT INTO `municipios` VALUES (2116, 30, 'Chalma');
INSERT INTO `municipios` VALUES (2117, 30, 'Chiconamel');
INSERT INTO `municipios` VALUES (2118, 30, 'Chiconquiaco');
INSERT INTO `municipios` VALUES (2119, 30, 'Chicontepec');
INSERT INTO `municipios` VALUES (2120, 30, 'Chinameca');
INSERT INTO `municipios` VALUES (2121, 30, 'Chinampa de Gorostiza');
INSERT INTO `municipios` VALUES (2122, 30, 'Chocamán');
INSERT INTO `municipios` VALUES (2123, 30, 'Chontla');
INSERT INTO `municipios` VALUES (2124, 30, 'Chumatlán');
INSERT INTO `municipios` VALUES (2125, 30, 'Citlaltépetl');
INSERT INTO `municipios` VALUES (2126, 30, 'Coacoatzintla');
INSERT INTO `municipios` VALUES (2127, 30, 'Coahuitlán');
INSERT INTO `municipios` VALUES (2128, 30, 'Coatepec');
INSERT INTO `municipios` VALUES (2129, 30, 'Coatzacoalcos');
INSERT INTO `municipios` VALUES (2130, 30, 'Coatzintla');
INSERT INTO `municipios` VALUES (2131, 30, 'Coetzala');
INSERT INTO `municipios` VALUES (2132, 30, 'Colipa');
INSERT INTO `municipios` VALUES (2133, 30, 'Comapa');
INSERT INTO `municipios` VALUES (2134, 30, 'Córdoba');
INSERT INTO `municipios` VALUES (2135, 30, 'Cosamaloapan de Carpio');
INSERT INTO `municipios` VALUES (2136, 30, 'Consautlán de Carvajal');
INSERT INTO `municipios` VALUES (2137, 30, 'Coscomatepec');
INSERT INTO `municipios` VALUES (2138, 30, 'Cosoleacaque');
INSERT INTO `municipios` VALUES (2139, 30, 'Cotaxtla');
INSERT INTO `municipios` VALUES (2140, 30, 'Coxquihui');
INSERT INTO `municipios` VALUES (2141, 30, 'Coyutla');
INSERT INTO `municipios` VALUES (2142, 30, 'Cuichapa');
INSERT INTO `municipios` VALUES (2143, 30, 'Cuitláhuac');
INSERT INTO `municipios` VALUES (2144, 30, 'El Higo');
INSERT INTO `municipios` VALUES (2145, 30, 'Emiliano Zapata');
INSERT INTO `municipios` VALUES (2146, 30, 'Espinal');
INSERT INTO `municipios` VALUES (2147, 30, 'Filomeno Mata');
INSERT INTO `municipios` VALUES (2148, 30, 'Fortín');
INSERT INTO `municipios` VALUES (2149, 30, 'Gutiérrez Zamora');
INSERT INTO `municipios` VALUES (2150, 30, 'Hidalgotitlán');
INSERT INTO `municipios` VALUES (2151, 30, 'Huayacocotla');
INSERT INTO `municipios` VALUES (2152, 30, 'Hueyapan de Ocampo');
INSERT INTO `municipios` VALUES (2153, 30, 'Huiloapan de Cuauhtémoc');
INSERT INTO `municipios` VALUES (2154, 30, 'Ignacio de la Llave');
INSERT INTO `municipios` VALUES (2155, 30, 'Ilamatlán');
INSERT INTO `municipios` VALUES (2156, 30, 'Isla');
INSERT INTO `municipios` VALUES (2157, 30, 'Ixcatepec');
INSERT INTO `municipios` VALUES (2158, 30, 'Ixhuacán de los Reyes');
INSERT INTO `municipios` VALUES (2159, 30, 'Ixhuatlancillo');
INSERT INTO `municipios` VALUES (2160, 30, 'Ixhuatlán del Café');
INSERT INTO `municipios` VALUES (2161, 30, 'Ixhuatlán de Madero');
INSERT INTO `municipios` VALUES (2162, 30, 'Ixhuatlán del Sureste');
INSERT INTO `municipios` VALUES (2163, 30, 'Ixmatlahuacan');
INSERT INTO `municipios` VALUES (2164, 30, 'Ixtaczoquitlán');
INSERT INTO `municipios` VALUES (2165, 30, 'Jalacingo');
INSERT INTO `municipios` VALUES (2166, 30, 'Jalcomulco');
INSERT INTO `municipios` VALUES (2167, 30, 'Jáltipan');
INSERT INTO `municipios` VALUES (2168, 30, 'Jamapa');
INSERT INTO `municipios` VALUES (2169, 30, 'Jesús Carranza');
INSERT INTO `municipios` VALUES (2170, 30, 'Jilotepec');
INSERT INTO `municipios` VALUES (2171, 30, 'José Azueta');
INSERT INTO `municipios` VALUES (2172, 30, 'Juan Rodríguez Clara');
INSERT INTO `municipios` VALUES (2173, 30, 'Juchique de Ferrer');
INSERT INTO `municipios` VALUES (2174, 30, 'La Antigua');
INSERT INTO `municipios` VALUES (2175, 30, 'Landero y Coss');
INSERT INTO `municipios` VALUES (2176, 30, 'La Perla');
INSERT INTO `municipios` VALUES (2177, 30, 'Las Choapas');
INSERT INTO `municipios` VALUES (2178, 30, 'Las Minas');
INSERT INTO `municipios` VALUES (2179, 30, 'Las Vigas de Ramírez');
INSERT INTO `municipios` VALUES (2180, 30, 'Lerdo de Tejada');
INSERT INTO `municipios` VALUES (2181, 30, 'Los Reyes');
INSERT INTO `municipios` VALUES (2182, 30, 'Magdalena');
INSERT INTO `municipios` VALUES (2183, 30, 'Maltrata');
INSERT INTO `municipios` VALUES (2184, 30, 'Manlio Fabio Altamirano');
INSERT INTO `municipios` VALUES (2185, 30, 'Mariano Escobedo');
INSERT INTO `municipios` VALUES (2186, 30, 'Martínez de la Torre');
INSERT INTO `municipios` VALUES (2187, 30, 'Mecatlán');
INSERT INTO `municipios` VALUES (2188, 30, 'Mecayapan');
INSERT INTO `municipios` VALUES (2189, 30, 'Medellín');
INSERT INTO `municipios` VALUES (2190, 30, 'Miahuatlán');
INSERT INTO `municipios` VALUES (2191, 30, 'Minatitlán');
INSERT INTO `municipios` VALUES (2192, 30, 'Misantla');
INSERT INTO `municipios` VALUES (2193, 30, 'Mixtla de Altamirano');
INSERT INTO `municipios` VALUES (2194, 30, 'Moloacán');
INSERT INTO `municipios` VALUES (2195, 30, 'Nanchital de Lázaro Cárdenas del Río');
INSERT INTO `municipios` VALUES (2196, 30, 'Naolinco');
INSERT INTO `municipios` VALUES (2197, 30, 'Naranjal');
INSERT INTO `municipios` VALUES (2198, 30, 'Naranjos Amatlán');
INSERT INTO `municipios` VALUES (2199, 30, 'Nautla');
INSERT INTO `municipios` VALUES (2200, 30, 'Nogales');
INSERT INTO `municipios` VALUES (2201, 30, 'Oluta');
INSERT INTO `municipios` VALUES (2202, 30, 'Omealca');
INSERT INTO `municipios` VALUES (2203, 30, 'Orizaba');
INSERT INTO `municipios` VALUES (2204, 30, 'Otatitlán');
INSERT INTO `municipios` VALUES (2205, 30, 'Oteapan');
INSERT INTO `municipios` VALUES (2206, 30, 'Ozuluama de Mascañeras');
INSERT INTO `municipios` VALUES (2207, 30, 'Pajapan');
INSERT INTO `municipios` VALUES (2208, 30, 'Pánuco');
INSERT INTO `municipios` VALUES (2209, 30, 'Papantla');
INSERT INTO `municipios` VALUES (2210, 30, 'Paso del Macho');
INSERT INTO `municipios` VALUES (2211, 30, 'Paso de Ovejas');
INSERT INTO `municipios` VALUES (2212, 30, 'Perote');
INSERT INTO `municipios` VALUES (2213, 30, 'Platón Sánchez');
INSERT INTO `municipios` VALUES (2214, 30, 'Playa Vicente');
INSERT INTO `municipios` VALUES (2215, 30, 'Poza Rica de Hidalgo');
INSERT INTO `municipios` VALUES (2216, 30, 'Pueblo Viejo');
INSERT INTO `municipios` VALUES (2217, 30, 'Puente Nacional');
INSERT INTO `municipios` VALUES (2218, 30, 'Rafael Delgado');
INSERT INTO `municipios` VALUES (2219, 30, 'Rafael Lucio');
INSERT INTO `municipios` VALUES (2220, 30, 'Río Blanco');
INSERT INTO `municipios` VALUES (2221, 30, 'Saltabarranca');
INSERT INTO `municipios` VALUES (2222, 30, 'San Andrés Tenejapan');
INSERT INTO `municipios` VALUES (2223, 30, 'San Andrés Tuxtla');
INSERT INTO `municipios` VALUES (2224, 30, 'San Juan Evangelista');
INSERT INTO `municipios` VALUES (2225, 30, 'San Rafael');
INSERT INTO `municipios` VALUES (2226, 30, 'Santiago Sochiapan');
INSERT INTO `municipios` VALUES (2227, 30, 'Santiago Tuxtla');
INSERT INTO `municipios` VALUES (2228, 30, 'Sayula de Alemán');
INSERT INTO `municipios` VALUES (2229, 30, 'Soconusco');
INSERT INTO `municipios` VALUES (2230, 30, 'Sochiapa');
INSERT INTO `municipios` VALUES (2231, 30, 'Soledad Atzompa');
INSERT INTO `municipios` VALUES (2232, 30, 'Soledad de Doblado');
INSERT INTO `municipios` VALUES (2233, 30, 'Soteapan');
INSERT INTO `municipios` VALUES (2234, 30, 'Tamalín');
INSERT INTO `municipios` VALUES (2235, 30, 'Tamiahua');
INSERT INTO `municipios` VALUES (2236, 30, 'Tampico Alto');
INSERT INTO `municipios` VALUES (2237, 30, 'Tancoco');
INSERT INTO `municipios` VALUES (2238, 30, 'Tantima');
INSERT INTO `municipios` VALUES (2239, 30, 'Tantoyuca');
INSERT INTO `municipios` VALUES (2240, 30, 'Tatatila');
INSERT INTO `municipios` VALUES (2241, 30, 'Tatahuicapan de Juárez');
INSERT INTO `municipios` VALUES (2242, 30, 'Tecolutla');
INSERT INTO `municipios` VALUES (2243, 30, 'Tehuipango');
INSERT INTO `municipios` VALUES (2244, 30, 'Tempoal');
INSERT INTO `municipios` VALUES (2245, 30, 'Tenampa');
INSERT INTO `municipios` VALUES (2246, 30, 'Tenochtitlán');
INSERT INTO `municipios` VALUES (2247, 30, 'Teocelo');
INSERT INTO `municipios` VALUES (2248, 30, 'Tepatlaxco');
INSERT INTO `municipios` VALUES (2249, 30, 'Tepetlán');
INSERT INTO `municipios` VALUES (2250, 30, 'Tepetzintla');
INSERT INTO `municipios` VALUES (2251, 30, 'Tequila');
INSERT INTO `municipios` VALUES (2252, 30, 'Texcatepec');
INSERT INTO `municipios` VALUES (2253, 30, 'Texhuacán');
INSERT INTO `municipios` VALUES (2254, 30, 'Texistepec');
INSERT INTO `municipios` VALUES (2255, 30, 'Tezonapa');
INSERT INTO `municipios` VALUES (2256, 30, 'Tihuatlán');
INSERT INTO `municipios` VALUES (2257, 30, 'Tierra Blanca');
INSERT INTO `municipios` VALUES (2258, 30, 'Tlacojalpan');
INSERT INTO `municipios` VALUES (2259, 30, 'Tlacolulan');
INSERT INTO `municipios` VALUES (2260, 30, 'Tlacotalpan');
INSERT INTO `municipios` VALUES (2261, 30, 'Tlacotepec de Mejía');
INSERT INTO `municipios` VALUES (2262, 30, 'Tlachichilco');
INSERT INTO `municipios` VALUES (2263, 30, 'Tlalixcoyan');
INSERT INTO `municipios` VALUES (2264, 30, 'Tlalnelhuayocan');
INSERT INTO `municipios` VALUES (2265, 30, 'Tlaltetela');
INSERT INTO `municipios` VALUES (2266, 30, 'Tlapacoyan');
INSERT INTO `municipios` VALUES (2267, 30, 'Tlaquilpa');
INSERT INTO `municipios` VALUES (2268, 30, 'Tlilapan');
INSERT INTO `municipios` VALUES (2269, 30, 'Tomatlán');
INSERT INTO `municipios` VALUES (2270, 30, 'Tonayán');
INSERT INTO `municipios` VALUES (2271, 30, 'Totutla');
INSERT INTO `municipios` VALUES (2272, 30, 'Tres Valles');
INSERT INTO `municipios` VALUES (2273, 30, 'Tuxpan');
INSERT INTO `municipios` VALUES (2274, 30, 'Tuxtilla');
INSERT INTO `municipios` VALUES (2275, 30, 'Úrsulo Galván');
INSERT INTO `municipios` VALUES (2276, 30, 'Uxpanapa');
INSERT INTO `municipios` VALUES (2277, 30, 'Vega de Alatorre');
INSERT INTO `municipios` VALUES (2278, 30, 'Veracruz');
INSERT INTO `municipios` VALUES (2279, 30, 'Villa Aldama');
INSERT INTO `municipios` VALUES (2280, 30, 'Xalapa');
INSERT INTO `municipios` VALUES (2281, 30, 'Xico');
INSERT INTO `municipios` VALUES (2282, 30, 'Xoxocotla');
INSERT INTO `municipios` VALUES (2283, 30, 'Yanga');
INSERT INTO `municipios` VALUES (2284, 30, 'Yecuatla');
INSERT INTO `municipios` VALUES (2285, 30, 'Zacualpan');
INSERT INTO `municipios` VALUES (2286, 30, 'Zaragoza');
INSERT INTO `municipios` VALUES (2287, 30, 'Zentla');
INSERT INTO `municipios` VALUES (2288, 30, 'Zongolica');
INSERT INTO `municipios` VALUES (2289, 30, 'Zontecomatlán');
INSERT INTO `municipios` VALUES (2290, 30, 'Zozocolco de Hidalgo');
INSERT INTO `municipios` VALUES (2291, 31, 'Abalá');
INSERT INTO `municipios` VALUES (2292, 31, 'Acanceh');
INSERT INTO `municipios` VALUES (2293, 31, 'Akil');
INSERT INTO `municipios` VALUES (2294, 31, 'Baca');
INSERT INTO `municipios` VALUES (2295, 31, 'Bokobá');
INSERT INTO `municipios` VALUES (2296, 31, 'Buctzotz');
INSERT INTO `municipios` VALUES (2297, 31, 'Cacalchén');
INSERT INTO `municipios` VALUES (2298, 31, 'Calotmul');
INSERT INTO `municipios` VALUES (2299, 31, 'Cansahcab');
INSERT INTO `municipios` VALUES (2300, 31, 'Cantamayec');
INSERT INTO `municipios` VALUES (2301, 31, 'Calestún');
INSERT INTO `municipios` VALUES (2302, 31, 'Cenotillo');
INSERT INTO `municipios` VALUES (2303, 31, 'Conkal');
INSERT INTO `municipios` VALUES (2304, 31, 'Cuncunul');
INSERT INTO `municipios` VALUES (2305, 31, 'Cuzamá');
INSERT INTO `municipios` VALUES (2306, 31, 'Chacsinkín');
INSERT INTO `municipios` VALUES (2307, 31, 'Chankom');
INSERT INTO `municipios` VALUES (2308, 31, 'Chapab');
INSERT INTO `municipios` VALUES (2309, 31, 'Chemax');
INSERT INTO `municipios` VALUES (2310, 31, 'Chicxulub Pueblo');
INSERT INTO `municipios` VALUES (2311, 31, 'Chichimilá');
INSERT INTO `municipios` VALUES (2312, 31, 'Chikindzonot');
INSERT INTO `municipios` VALUES (2313, 31, 'Chocholá');
INSERT INTO `municipios` VALUES (2314, 31, 'Chumayel');
INSERT INTO `municipios` VALUES (2315, 31, 'Dzán');
INSERT INTO `municipios` VALUES (2316, 31, 'Dzemul');
INSERT INTO `municipios` VALUES (2317, 31, 'Dzidzantún');
INSERT INTO `municipios` VALUES (2318, 31, 'Dzilam de Bravo');
INSERT INTO `municipios` VALUES (2319, 31, 'Dzilam González');
INSERT INTO `municipios` VALUES (2320, 31, 'Dzitás');
INSERT INTO `municipios` VALUES (2321, 31, 'Dzoncauich');
INSERT INTO `municipios` VALUES (2322, 31, 'Espita');
INSERT INTO `municipios` VALUES (2323, 31, 'Halachó');
INSERT INTO `municipios` VALUES (2324, 31, 'Hocabá');
INSERT INTO `municipios` VALUES (2325, 31, 'Hoctún');
INSERT INTO `municipios` VALUES (2326, 31, 'Homún');
INSERT INTO `municipios` VALUES (2327, 31, 'Huhí');
INSERT INTO `municipios` VALUES (2328, 31, 'Hunucmá');
INSERT INTO `municipios` VALUES (2329, 31, 'Ixtil');
INSERT INTO `municipios` VALUES (2330, 31, 'Izamal');
INSERT INTO `municipios` VALUES (2331, 31, 'Kanasín');
INSERT INTO `municipios` VALUES (2332, 31, 'Kantunil');
INSERT INTO `municipios` VALUES (2333, 31, 'Kaua');
INSERT INTO `municipios` VALUES (2334, 31, 'Kinchil');
INSERT INTO `municipios` VALUES (2335, 31, 'Kopomá');
INSERT INTO `municipios` VALUES (2336, 31, 'Mama');
INSERT INTO `municipios` VALUES (2337, 31, 'Maní');
INSERT INTO `municipios` VALUES (2338, 31, 'Maxcanú');
INSERT INTO `municipios` VALUES (2339, 31, 'Mayapán');
INSERT INTO `municipios` VALUES (2340, 31, 'Mérida');
INSERT INTO `municipios` VALUES (2341, 31, 'Mocochá');
INSERT INTO `municipios` VALUES (2342, 31, 'Motul');
INSERT INTO `municipios` VALUES (2343, 31, 'Muna');
INSERT INTO `municipios` VALUES (2344, 31, 'Muxupip');
INSERT INTO `municipios` VALUES (2345, 31, 'Opichén');
INSERT INTO `municipios` VALUES (2346, 31, 'Oxkutzcab');
INSERT INTO `municipios` VALUES (2347, 31, 'Panabá');
INSERT INTO `municipios` VALUES (2348, 31, 'Peto');
INSERT INTO `municipios` VALUES (2349, 31, 'Progreso');
INSERT INTO `municipios` VALUES (2350, 31, 'Quintana Roo');
INSERT INTO `municipios` VALUES (2351, 31, 'Río Lagartos');
INSERT INTO `municipios` VALUES (2352, 31, 'Sacalum');
INSERT INTO `municipios` VALUES (2353, 31, 'Samahil');
INSERT INTO `municipios` VALUES (2354, 31, 'Sanahcat');
INSERT INTO `municipios` VALUES (2355, 31, 'San Felipe');
INSERT INTO `municipios` VALUES (2356, 31, 'Santa Elena');
INSERT INTO `municipios` VALUES (2357, 31, 'Seyé');
INSERT INTO `municipios` VALUES (2358, 31, 'Sinanché');
INSERT INTO `municipios` VALUES (2359, 31, 'Sotuta');
INSERT INTO `municipios` VALUES (2360, 31, 'Sucilá');
INSERT INTO `municipios` VALUES (2361, 31, 'Sudzal');
INSERT INTO `municipios` VALUES (2362, 31, 'Suma de Hidalgo');
INSERT INTO `municipios` VALUES (2363, 31, 'Tahdziú');
INSERT INTO `municipios` VALUES (2364, 31, 'Tahmek');
INSERT INTO `municipios` VALUES (2365, 31, 'Teabo');
INSERT INTO `municipios` VALUES (2366, 31, 'Tecoh');
INSERT INTO `municipios` VALUES (2367, 31, 'Tekal de Venegas');
INSERT INTO `municipios` VALUES (2368, 31, 'Tekantó');
INSERT INTO `municipios` VALUES (2369, 31, 'Tekax');
INSERT INTO `municipios` VALUES (2370, 31, 'Tekit');
INSERT INTO `municipios` VALUES (2371, 31, 'Tekom');
INSERT INTO `municipios` VALUES (2372, 31, 'Telchac Pueblo');
INSERT INTO `municipios` VALUES (2373, 31, 'Telchac Puerto');
INSERT INTO `municipios` VALUES (2374, 31, 'Temax');
INSERT INTO `municipios` VALUES (2375, 31, 'Temozón');
INSERT INTO `municipios` VALUES (2376, 31, 'Tepakán');
INSERT INTO `municipios` VALUES (2377, 31, 'Tetiz');
INSERT INTO `municipios` VALUES (2378, 31, 'Teya');
INSERT INTO `municipios` VALUES (2379, 31, 'Ticul');
INSERT INTO `municipios` VALUES (2380, 31, 'Timucuy');
INSERT INTO `municipios` VALUES (2381, 31, 'Tinúm');
INSERT INTO `municipios` VALUES (2382, 31, 'Tixcacalcupul');
INSERT INTO `municipios` VALUES (2383, 31, 'Tixkokob');
INSERT INTO `municipios` VALUES (2384, 31, 'Tixméhuac');
INSERT INTO `municipios` VALUES (2385, 31, 'Tixpéhual');
INSERT INTO `municipios` VALUES (2386, 31, 'Tizimín');
INSERT INTO `municipios` VALUES (2387, 31, 'Tunkás');
INSERT INTO `municipios` VALUES (2388, 31, 'Tzucacab');
INSERT INTO `municipios` VALUES (2389, 31, 'Uayma');
INSERT INTO `municipios` VALUES (2390, 31, 'Ucú');
INSERT INTO `municipios` VALUES (2391, 31, 'Umán');
INSERT INTO `municipios` VALUES (2392, 31, 'Valladolid');
INSERT INTO `municipios` VALUES (2393, 31, 'Xocchel');
INSERT INTO `municipios` VALUES (2394, 31, 'Yaxcabá');
INSERT INTO `municipios` VALUES (2395, 31, 'Yaxkukul');
INSERT INTO `municipios` VALUES (2396, 31, 'Yobaín');
INSERT INTO `municipios` VALUES (2397, 32, 'Apozol');
INSERT INTO `municipios` VALUES (2398, 32, 'Apulco');
INSERT INTO `municipios` VALUES (2399, 32, 'Atolinga');
INSERT INTO `municipios` VALUES (2400, 32, 'Benito Juárez');
INSERT INTO `municipios` VALUES (2401, 32, 'Calera');
INSERT INTO `municipios` VALUES (2402, 32, 'Cañitas de Felipe Pescador');
INSERT INTO `municipios` VALUES (2403, 32, 'Concepción del Oro');
INSERT INTO `municipios` VALUES (2404, 32, 'Cuauhtémoc');
INSERT INTO `municipios` VALUES (2405, 32, 'Chalchihuites');
INSERT INTO `municipios` VALUES (2406, 32, 'Fresnillo');
INSERT INTO `municipios` VALUES (2407, 32, 'Trinidad García de la Cadena');
INSERT INTO `municipios` VALUES (2408, 32, 'Genaro Codina');
INSERT INTO `municipios` VALUES (2409, 32, 'General Enrique Estrada');
INSERT INTO `municipios` VALUES (2410, 32, 'General Francisco R. Murguía');
INSERT INTO `municipios` VALUES (2411, 32, 'El Plateado de Joaquín Amaro');
INSERT INTO `municipios` VALUES (2412, 32, 'El Salvador');
INSERT INTO `municipios` VALUES (2413, 32, 'General Pánfilo Natera');
INSERT INTO `municipios` VALUES (2414, 32, 'Guadalupe');
INSERT INTO `municipios` VALUES (2415, 32, 'Huanusco');
INSERT INTO `municipios` VALUES (2416, 32, 'Jalpa');
INSERT INTO `municipios` VALUES (2417, 32, 'Jerez');
INSERT INTO `municipios` VALUES (2418, 32, 'Jiménez del Teul');
INSERT INTO `municipios` VALUES (2419, 32, 'Juan Aldama');
INSERT INTO `municipios` VALUES (2420, 32, 'Juchipila');
INSERT INTO `municipios` VALUES (2421, 32, 'Loreto');
INSERT INTO `municipios` VALUES (2422, 32, 'Luis Moya');
INSERT INTO `municipios` VALUES (2423, 32, 'Mazapil');
INSERT INTO `municipios` VALUES (2424, 32, 'Melchor Ocampo');
INSERT INTO `municipios` VALUES (2425, 32, 'Mezquital del Oro');
INSERT INTO `municipios` VALUES (2426, 32, 'Miguel Auza');
INSERT INTO `municipios` VALUES (2427, 32, 'Momax');
INSERT INTO `municipios` VALUES (2428, 32, 'Monte Escobedo');
INSERT INTO `municipios` VALUES (2429, 32, 'Morelos');
INSERT INTO `municipios` VALUES (2430, 32, 'Moyahua de Estrada');
INSERT INTO `municipios` VALUES (2431, 32, 'Nochistlán de Mejía');
INSERT INTO `municipios` VALUES (2432, 32, 'Noria de Ángeles');
INSERT INTO `municipios` VALUES (2433, 32, 'Ojocaliente');
INSERT INTO `municipios` VALUES (2434, 32, 'Pánuco');
INSERT INTO `municipios` VALUES (2435, 32, 'Pinos');
INSERT INTO `municipios` VALUES (2436, 32, 'Río Grande');
INSERT INTO `municipios` VALUES (2437, 32, 'Sain Alto');
INSERT INTO `municipios` VALUES (2438, 32, 'Santa María de la Paz');
INSERT INTO `municipios` VALUES (2439, 32, 'Sombrerete');
INSERT INTO `municipios` VALUES (2440, 32, 'Susticacán');
INSERT INTO `municipios` VALUES (2441, 32, 'Tabasco');
INSERT INTO `municipios` VALUES (2442, 32, 'Tepechitlán');
INSERT INTO `municipios` VALUES (2443, 32, 'Tepetongo');
INSERT INTO `municipios` VALUES (2444, 32, 'Teul de González Ortega');
INSERT INTO `municipios` VALUES (2445, 32, 'Tlaltenango de Sánchez Román');
INSERT INTO `municipios` VALUES (2446, 32, 'Trancoso');
INSERT INTO `municipios` VALUES (2447, 32, 'Valparaíso');
INSERT INTO `municipios` VALUES (2448, 32, 'Vetagrande');
INSERT INTO `municipios` VALUES (2449, 32, 'Villa de Cos');
INSERT INTO `municipios` VALUES (2450, 32, 'Villa García');
INSERT INTO `municipios` VALUES (2451, 32, 'Villa González Ortega');
INSERT INTO `municipios` VALUES (2452, 32, 'Villa Hidalgo');
INSERT INTO `municipios` VALUES (2453, 32, 'Villanueva');
INSERT INTO `municipios` VALUES (2454, 32, 'Zacatecas');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `padres`
-- 

CREATE TABLE `padres` (
  `ID_PADRE` int(11) NOT NULL auto_increment,
  `ESTUDIO` varchar(40) collate utf8_spanish_ci default NULL,
  `TRABAJA` tinyint(1) default NULL,
  `HRS` int(11) default NULL,
  `GENERO` tinyint(1) default NULL,
  PRIMARY KEY  (`ID_PADRE`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `padres`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `parentesco`
-- 

CREATE TABLE `parentesco` (
  `ID_PARENT` int(11) NOT NULL,
  `PARENTESCO` varchar(15) collate utf8_spanish_ci default NULL,
  PRIMARY KEY  (`ID_PARENT`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- 
-- Volcar la base de datos para la tabla `parentesco`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `participacion_social`
-- 

CREATE TABLE `participacion_social` (
  `ID_PARTICIPACION` int(11) NOT NULL auto_increment,
  `PARTICIPA` tinyint(1) default NULL,
  `ORGANIZACION` varchar(50) collate utf8_spanish_ci default NULL,
  PRIMARY KEY  (`ID_PARTICIPACION`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `participacion_social`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `personas`
-- 

CREATE TABLE `personas` (
  `ID_PERSONA` int(11) NOT NULL,
  `ID_DOMICILIO` int(11) default NULL,
  `NOMBRE` varchar(20) collate utf8_spanish_ci default NULL,
  `AP_PATERNO` varchar(15) collate utf8_spanish_ci default NULL,
  `AP_MATERNO` varchar(15) collate utf8_spanish_ci default NULL,
  `GENERO` varchar(10) collate utf8_spanish_ci default NULL,
  `NACIONALIDAD` varchar(10) collate utf8_spanish_ci default NULL,
  `LUGAR_NAC` varchar(20) collate utf8_spanish_ci default NULL,
  `FECHA_NAC` date default NULL,
  `CURP` varchar(20) collate utf8_spanish_ci default NULL,
  PRIMARY KEY  (`ID_PERSONA`),
  KEY `FK_REFERENCE_3` (`ID_DOMICILIO`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- 
-- Volcar la base de datos para la tabla `personas`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `salud`
-- 

CREATE TABLE `salud` (
  `ID_SALUD` int(11) NOT NULL auto_increment,
  `ID_TRATAMIENTO` int(11) default NULL,
  `CUERPO` varchar(15) collate utf8_spanish_ci default NULL,
  `ESTATURA` double default NULL,
  `PESO` double default NULL,
  `PROBLEM_SALUD` varchar(40) collate utf8_spanish_ci default NULL,
  `SEGURO` varchar(20) collate utf8_spanish_ci default NULL,
  `FREC_MEDICO` varchar(30) collate utf8_spanish_ci default NULL,
  `FREC_DENTISTA` varchar(30) collate utf8_spanish_ci default NULL,
  `ANTEOJOS` tinyint(1) default NULL,
  `TRATAMIENTO` varchar(45) collate utf8_spanish_ci default NULL,
  `DISCAPACIDAD` varchar(50) collate utf8_spanish_ci default NULL,
  PRIMARY KEY  (`ID_SALUD`),
  KEY `FK_REFERENCE_16` (`ID_TRATAMIENTO`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `salud`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `status`
-- 

CREATE TABLE `status` (
  `ID_STATUS` int(11) NOT NULL auto_increment,
  `ALERTA` varchar(10) collate utf8_spanish_ci default NULL,
  `SITUACION` varchar(20) collate utf8_spanish_ci default NULL,
  `REFERENCIA` varchar(50) collate utf8_spanish_ci default NULL,
  PRIMARY KEY  (`ID_STATUS`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `status`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tiempo_libre`
-- 

CREATE TABLE `tiempo_libre` (
  `ID_TIEMPOLIBRE` int(11) NOT NULL auto_increment,
  `FOLIO` int(11) default NULL,
  `ACTIVIDADES` varchar(100) collate utf8_spanish_ci default NULL,
  PRIMARY KEY  (`ID_TIEMPOLIBRE`),
  KEY `FK_REFERENCE_31` (`FOLIO`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `tiempo_libre`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tratamientos`
-- 

CREATE TABLE `tratamientos` (
  `ID_TRATAMIENTO` int(11) NOT NULL auto_increment,
  `FECHA_INICIO` datetime default NULL,
  `FECHA_FINAL` datetime default NULL,
  `LUGAR` varchar(30) collate utf8_spanish_ci default NULL,
  PRIMARY KEY  (`ID_TRATAMIENTO`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `tratamientos`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `usuarios`
-- 

CREATE TABLE `usuarios` (
  `ID_USUARIO` int(11) NOT NULL auto_increment,
  `ID_GRUPO` int(11) default NULL,
  `USUARIO` varchar(10) collate utf8_spanish_ci default NULL,
  `PASSWORD` varchar(8) collate utf8_spanish_ci default NULL,
  `CATEGORIA` varchar(30) collate utf8_spanish_ci default NULL,
  `TUTOR` varchar(100) collate utf8_spanish_ci default NULL,
  PRIMARY KEY  (`ID_USUARIO`),
  KEY `FK_REFERENCE_30` (`ID_GRUPO`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `usuarios`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `viviendas`
-- 

CREATE TABLE `viviendas` (
  `ID_VIVIENDA` int(11) NOT NULL auto_increment,
  `TIPO` varchar(20) collate utf8_spanish_ci default NULL,
  `PARED` varchar(15) collate utf8_spanish_ci default NULL,
  `PISO` varchar(15) collate utf8_spanish_ci default NULL,
  `TECHO` varchar(15) collate utf8_spanish_ci default NULL,
  PRIMARY KEY  (`ID_VIVIENDA`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `viviendas`
-- 

